#let _to-int(s, ctx) = {
  let t = s.trim()
  assert(t.match(regex("^-?[0-9]+$")) != none,
    message: "quan: invalid number \"" + t + "\" in range string \"" + ctx + "\"")
  int(t)
}

#let _parse-int-ranges(s) = {
  let result = ()
  for part in s.split(",") {
    let p = part.trim()
    if p == "" { continue }

    let body = if p.starts-with("-") { p.slice(1) } else { p }
    let dash = body.position("-")
    if dash != none {
      let cut = dash + (p.len() - body.len())
      let a = _to-int(p.slice(0, cut), s)
      let b = _to-int(p.slice(cut + 1), s)
      assert(a <= b, message: "quan: invalid range \"" + p + "\" (start > end)")
      for i in range(a, b + 1) { result.push(i) }
    } else {
      result.push(_to-int(p, s))
    }
  }
  result
}

#let _u(n) = calc.rem(n, 10)
#let _t(n) = calc.floor(n / 10)

#let _weight-num(w) = {
  if type(w) == int { w } else {
    (thin: 100, extralight: 200, light: 300, regular: 400, medium: 500,
     semibold: 600, bold: 700, extrabold: 800, black: 900).at(w, default: 400)
  }
}

#let _quan-state = state("quan", (
  digits: range(1, 11),
))

#let _FONT-CLASS = (

  "simsun": "song", "nsimsun": "song", "simhei": "song", "kaiti": "song", "fangsong": "song",
  "songti sc": "song", "stsong": "song", "stsongti": "song", "kaiti sc": "song", "stfangsong": "song",
  "fandolsong": "song", "fandolhei": "song", "fandolkai": "song", "fandolfang": "song",
  "fzshusong-z01": "song", "fzhei-b01": "song", "fzkai-z03": "song", "fzfangsong-z02": "song",
  "宋体": "song", "黑体": "song", "楷体": "song", "仿宋": "song",

  "noto serif cjk sc": "wide", "noto serif cjk tc": "wide", "noto serif cjk jp": "wide", "noto serif cjk kr": "wide",
  "noto sans cjk sc": "wide", "noto sans cjk tc": "wide", "noto sans cjk jp": "wide", "noto sans cjk kr": "wide",
  "source han serif sc": "wide", "source han sans sc": "wide", "source han serif": "wide", "source han sans": "wide",
  "heiti sc": "wide", "hiragino sans gb": "wide",

  "noto serif": "wide", "noto sans": "wide", "source serif": "wide", "source sans": "wide",
  "source serif 4": "wide", "source sans 3": "wide", "source serif pro": "wide", "source sans pro": "wide",

  "times new roman": "latin", "times": "latin", "tex gyre termes": "latin", "libertinus serif": "latin",
  "new computer modern": "latin", "stix two text": "latin",
)

#let _RULE-SINGLE = (values: range(0, 10), style: (inset: (x: 0.25em, y: 0.015em)))

#let _RULES = (

  song: (

    (values: range(0, 10),
     style:  (inset: (x: 0.25em, y: 0.015em))),

    (values: (11,),
     style:  (inset: (x: 0.09em, y: 0.015em), kern: -0.15em)),

    (values: (12, 21),
     style:  (inset: (x: 0.09em, y: 0.015em), kern: -0.125em)),

    (values: range(10, 20).filter(n => _u(n) != 1 and _u(n) != 2) + range(20, 100).filter(n => _u(n) == 1 and _t(n) >= 3),
     style:  (inset: (x: 0.08em, y: 0.015em), kern: -0.125em)),

    (values: range(20, 100).filter(n => _u(n) != 1),
     style:  (inset: (x: 0.07em, y: 0.015em), kern: -0.1em)),
  ),

  wide: (
    _RULE-SINGLE,
    (values: range(10, 100),
     style:  (size: 0.72em, kern: 0em, inset: (x: 0.05em, y: 0.04em))),
  ),

  "latin-song": (
    _RULE-SINGLE,
    (values: (11,),
     style:  (kern: -0.06em, inset: (x: 0.05em, y: 0.025em))),
    (values: range(10, 100).filter(n => n != 11),
     style:  (kern: -0.05em, inset: (x: 0.05em, y: 0.025em))),
  ),

  "latin-wide": (
    _RULE-SINGLE,
    (values: range(10, 100),
     style:  (size: 0.78em, kern: -0.06em, inset: (x: 0.05em, y: 0.04em))),
  ),
)

#let _covers-char(entry, ch) = {
  if type(entry) != dictionary { return true }
  let c = entry.at("covers", default: none)
  if c == none { return true }
  if c == "latin-in-cjk" { return ch.match(regex("[\u{0}-\u{2FF}]")) != none }
  ch.match(c) != none
}

#let _class-of(entry) = {
  let name = if type(entry) == dictionary { entry.at("name", default: "") } else { entry }
  _FONT-CLASS.at(lower(str(name)), default: none)
}

#let _pick-rules(font) = {
  let stack = if type(font) == array { font } else { (font,) }
  let digit-entry = stack.find(f => _covers-char(f, "0"))
  let digit = if digit-entry == none { none } else { _class-of(digit-entry) }
  let circle = stack.filter(f => _covers-char(f, "①")).map(_class-of).find(c => c == "song" or c == "wide")

  let digit = if digit == none and circle != none { "latin" } else { digit }
  if digit == "song" { (cap: 0.684, rules: _RULES.song) }
  else if digit == "wide" { (cap: 0.733, rules: _RULES.wide) }
  else if digit == "latin" and circle == "wide" { (cap: 0.662, rules: _RULES.at("latin-wide")) }
  else if digit == "latin" { (cap: 0.662, rules: _RULES.at("latin-song")) }
  else { (cap: 0.684, rules: _RULES.song) }
}

#let _quan-draw-state = state("quan-draw", (
  default: (
    stroke:   0.0315em,
    radius:   50%,

    inset:    (x: 0.28em, y: 0.015em),
    outset:   (y: 0.15em),
    baseline: -0.06em,
    size:     0.825em,

    height:   auto,
    kern:     -0.075em,
    gap:      0.1em,
  ),

  rules: _RULES.song,

  user-rules: (),
  user-keys: (),
))

#let quan-init(digits: none) = {
  let parsed = if digits != none { _parse-int-ranges(digits) } else { () }
  _quan-state.update(_ => (digits: parsed))
}

#let quan-style(
  stroke:   none,
  radius:   none,
  inset:    none,
  outset:   none,
  baseline: none,
  size:     none,
  height:   none,
  kern:     none,
  gap:      none,
  ..rules,
) = {

  let parsed = rules.pos().map(rule => {
    assert(
      type(rule) == array and rule.len() == 2
        and type(rule.at(0)) == str and type(rule.at(1)) == dictionary,
      message: "quan-style: positional args must be (range-str, style-dict) tuples",
    )
    (values: _parse-int-ranges(rule.at(0)), style: rule.at(1))
  })
  let named = (stroke: stroke, radius: radius, inset: inset, outset: outset,
               baseline: baseline, size: size, height: height, kern: kern, gap: gap)
  _quan-draw-state.update(prev => {
    let d = prev.default
    let keys = prev.user-keys
    for (k, v) in named.pairs() {
      if v != none {
        d.insert(k, v)
        if k not in keys { keys.push(k) }
      }
    }
    (default: d, rules: prev.rules,
     user-rules: prev.user-rules + parsed, user-keys: keys)
  })
}

#let _circled-digit(n) = {
  if      n == 0               { str.from-unicode(0x24EA) }
  else if n >= 1  and n <= 20  { str.from-unicode(0x245F + n) }
  else if n >= 21 and n <= 35  { str.from-unicode(0x3251 + (n - 21)) }
  else if n >= 36 and n <= 50  { str.from-unicode(0x32B1 + (n - 36)) }
  else { none }
}

#let _resolve-style(value, draw-cfg, picked: none) = {
  let s = draw-cfg.default
  let rules = if picked == none { draw-cfg.rules } else { picked.rules }
  s.insert("cap", if picked == none { 0.684 } else { picked.cap })
  if type(value) == int {
    for rule in rules {
      if value in rule.values {
        for (k, v) in rule.style.pairs() { s.insert(k, v) }
        break
      }
    }

    for k in draw-cfg.user-keys {
      s.insert(k, draw-cfg.default.at(k))
    }
    for rule in draw-cfg.user-rules {
      if value in rule.values {
        for (k, v) in rule.style.pairs() { s.insert(k, v) }
      }
    }
  }
  s
}

#let _drawn(body, value: none) = context {
  let s = _resolve-style(value, _quan-draw-state.get(), picked: _pick-rules(text.font))
  let sk = stroke(s.stroke)
  if sk.paint == auto {
    let factor = calc.max(1.0, 1.0 + (_weight-num(text.weight) - 400) / 400 * 0.6)
    let th = if sk.thickness == auto { 0.0315em } else { sk.thickness }
    sk = stroke((paint: text.fill, thickness: th * factor,
                 cap: sk.cap, join: sk.join, dash: sk.dash, miter-limit: sk.miter-limit))
  }
  let half = s.gap / 2

  let inset-y = if type(s.inset) == dictionary { s.inset.at("y", default: 0pt) } else { s.inset }
  let inset-x = if type(s.inset) == dictionary { s.inset.at("x", default: 0pt) } else { s.inset }
  let height = if s.height == auto { s.size * s.cap + 2 * inset-y } else { s.height }

  let outset-y = if type(s.outset) == dictionary { s.outset.at("y", default: 0pt) } else { s.outset }
  let outset-x = if type(s.outset) == dictionary { s.outset.at("x", default: 0pt) } else { s.outset }
  let digits = text(size: s.size, tracking: s.kern, body)

  let square = (height + 2 * (outset-y - outset-x)).to-absolute()
  let width = calc.max(square, measure(digits).width + 2 * inset-x.to-absolute())
  h(half)
  box(
    stroke:   sk,
    radius:   s.radius,
    inset:    s.inset,
    outset:   s.outset,
    baseline: s.baseline,
    width:    width,
    height:   height,
    align(center + horizon, digits),
  )

  "\u{200C}"
  h(half)
}

#let quan(value) = {
  assert(type(value) == int, message: "quan: expected int, got " + str(type(value)))
  context {
    let cfg = _quan-state.get()
    let g = _circled-digit(value)
    if g == none or value not in cfg.digits {
      _drawn(str(value), value: value)
    } else {
      g
    }
  }
}

#let quan-super(body, size: 0.6em, shift: -0.5em) = box(text(size: size, move(dy: shift, body)))

#let _quan-marker(n) = context {
  let cfg = _quan-state.get()
  let g = _circled-digit(n)
  if g == none or n not in cfg.digits {
    _drawn(str(n), value: n)
  } else {
    g
  }
}

#let quan-footnote(body, entry: "inline") = {
  assert(entry in ("inline", "super"),
    message: "quan-footnote: `entry` must be \"inline\" or \"super\", got " + repr(entry))

  show footnote: it => context {

    let loc = if type(it.body) == label {
      let hits = query(it.body)
      assert(hits.len() > 0,
        message: "quan: footnote label " + repr(it.body) + " not found")
      hits.first().location()
    } else {
      it.location()
    }
    let n = counter(footnote).at(loc).first()

    let entries = query(footnote.entry).filter(e => e.note.location() == loc)
    let dest = if entries.len() > 0 { entries.first().location() } else { loc }
    h(0pt, weak: true)
    link(dest, box(text(size: 0.7em, move(dy: -0.4em, _quan-marker(n)))))
  }

  show footnote.entry: it => context {
    let n = counter(footnote).at(it.note.location()).first()
    h(it.indent)
    if entry == "super" {

      link(it.note.location(), box(text(size: 0.7em, move(dy: -0.4em, _quan-marker(n)))))
      h(0.05em)
    } else {
      link(it.note.location(), _quan-marker(n))
      h(0.5em)
    }
    it.note.body
  }
  body
}
