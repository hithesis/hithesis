// 西文的「换行和分页」卡：断字（Word 默认关；开关是原生的 text.hyphenate）与长到一行放不下的单词（Word 在单词内部按字符断行把行填满，Typst 不会；插零宽空格造断点）。

#import "../runs/regex.typ": latin-run

// 光开 hyphenate 没用，必须连 lang 一起给：Typst 按 text.lang 选断字规则表，中文没有那张表。
/// 西文断字：`text.hyphenate` 为 `true` 时给西文片段同时设置 `lang: "en"`，否则不断字。
/// -> content
#let hyphenate-rules(doc) = {
  show latin-run: it => context {
    if text.hyphenate == true { set text(lang: "en"); it } else { it }
  }
  doc
}

// 一个西文单词长到一行都放不下时，Word 会在单词内部按字符断行把行填满（拿范例改一处英文题目、由 Word 导出实测）。
#let long-word-min = 22

// Typst 0.15 的分组深度上限为 256；预留其他嵌套后，每段最多插入 249 个断点。
#let _long-word-pieces = 250

#let long-word-chunks(cs) = {
  let k = calc.max(1, calc.ceil(cs.len() / _long-word-pieces))
  if k == 1 { return cs }
  range(0, cs.len(), step: k).map(i => cs.slice(i, calc.min(i + k, cs.len())).join())
}
