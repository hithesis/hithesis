// 将 Word 的节属性解析为页面设置记录，包括页边距、文档网格、页眉和页脚。

#import "../fonts/presets.typ": zihao
#import "../units.typ": twip, twips
#import "../styles/sheet.typ" as sheet
#import "../errors.typ" as _errors

// 页面设置以 Word 的“节”为边界；局部字典逐层合并，完整解析结果则直接替换。
#import "./state.typ": page-setup-state

// 名称与尺寸照 Typst 0.15.1 的 `page.paper`；其它尺寸写 `(width:, height:)`。
// 这里保存物理长度，Word 单位的换算留给读写 OOXML 的工具。
#let _papers = (
  "a0": (841mm, 1189mm), "a1": (594mm, 841mm), "a2": (420mm, 594mm),
  "a3": (297mm, 420mm), "a4": (210mm, 297mm), "a5": (148mm, 210mm),
  "a6": (105mm, 148mm), "a7": (74mm, 105mm), "a8": (52mm, 74mm),
  "a9": (37mm, 52mm), "a10": (26mm, 37mm), "a11": (18mm, 26mm),

  "iso-b1": (707mm, 1000mm), "iso-b2": (500mm, 707mm),
  "iso-b3": (353mm, 500mm), "iso-b4": (250mm, 353mm),
  "iso-b5": (176mm, 250mm), "iso-b6": (125mm, 176mm),
  "iso-b7": (88mm, 125mm), "iso-b8": (62mm, 88mm),
  "iso-c3": (324mm, 458mm), "iso-c4": (229mm, 324mm),
  "iso-c5": (162mm, 229mm), "iso-c6": (114mm, 162mm),
  "iso-c7": (81mm, 114mm), "iso-c8": (57mm, 81mm),
  "din-d3": (272mm, 385mm), "din-d4": (192mm, 272mm),
  "din-d5": (136mm, 192mm), "din-d6": (96mm, 136mm),
  "din-d7": (68mm, 96mm), "din-d8": (48mm, 68mm),
  "sis-g5": (169mm, 239mm), "sis-e5": (115mm, 220mm),

  "ansi-a": (216mm, 279mm), "ansi-b": (279mm, 432mm),
  "ansi-c": (432mm, 559mm), "ansi-d": (559mm, 864mm),
  "ansi-e": (864mm, 1118mm),
  "arch-a": (229mm, 305mm), "arch-b": (305mm, 457mm),
  "arch-c": (457mm, 610mm), "arch-d": (610mm, 914mm),
  "arch-e1": (762mm, 1067mm), "arch-e": (914mm, 1219mm),

  "jis-b0": (1030mm, 1456mm), "jis-b1": (728mm, 1030mm),
  "jis-b2": (515mm, 728mm), "jis-b3": (364mm, 515mm),
  "jis-b4": (257mm, 364mm), "jis-b5": (182mm, 257mm),
  "jis-b6": (128mm, 182mm), "jis-b7": (91mm, 128mm),
  "jis-b8": (64mm, 91mm), "jis-b9": (45mm, 64mm),
  "jis-b10": (32mm, 45mm), "jis-b11": (22mm, 32mm),
  "sac-d0": (764mm, 1064mm), "sac-d1": (532mm, 760mm),
  "sac-d2": (380mm, 528mm), "sac-d3": (264mm, 376mm),
  "sac-d4": (188mm, 260mm), "sac-d5": (130mm, 184mm),
  "sac-d6": (92mm, 126mm),

  "iso-id-1": (85.6mm, 53.98mm), "iso-id-2": (74mm, 105mm),
  "iso-id-3": (88mm, 125mm), "asia-f4": (210mm, 330mm),
  "jp-shiroku-ban-4": (264mm, 379mm), "jp-shiroku-ban-5": (189mm, 262mm),
  "jp-shiroku-ban-6": (127mm, 188mm), "jp-kiku-4": (227mm, 306mm),
  "jp-kiku-5": (151mm, 227mm), "jp-business-card": (91mm, 55mm),
  "cn-business-card": (90mm, 54mm), "eu-business-card": (85mm, 55mm),

  "fr-tellière": (340mm, 440mm),
  "fr-couronne-écriture": (360mm, 460mm),
  "fr-couronne-édition": (370mm, 470mm),
  "fr-raisin": (500mm, 650mm), "fr-carré": (450mm, 560mm),
  "fr-jésus": (560mm, 760mm),
  "uk-brief": (406.4mm, 342.9mm), "uk-draft": (254mm, 406.4mm),
  "uk-foolscap": (203.2mm, 330.2mm), "uk-quarto": (203.2mm, 254mm),
  "uk-crown": (508mm, 381mm), "uk-book-a": (111mm, 178mm),
  "uk-book-b": (129mm, 198mm),

  "us-letter": (215.9mm, 279.4mm), "us-legal": (215.9mm, 355.6mm),
  "us-tabloid": (279.4mm, 431.8mm), "us-executive": (184.15mm, 266.7mm),
  "us-foolscap-folio": (215.9mm, 342.9mm), "us-statement": (139.7mm, 215.9mm),
  "us-ledger": (431.8mm, 279.4mm), "us-oficio": (215.9mm, 340.36mm),
  "us-gov-letter": (203.2mm, 266.7mm), "us-gov-legal": (215.9mm, 330.2mm),
  "us-business-card": (88.9mm, 50.8mm), "us-digest": (139.7mm, 215.9mm),
  "us-trade": (152.4mm, 228.6mm),
  "newspaper-compact": (280mm, 430mm),
  "newspaper-berliner": (315mm, 470mm),
  "newspaper-broadsheet": (381mm, 578mm),
  "presentation-16-9": (297mm, 167.0625mm),
  "presentation-4-3": (280mm, 210mm),
)


// 页面设置里的长度落缇：换算在 units.typ 的 twips（磅按 20、厘米按 Word 的 567），这里只把报错指到字段名上。
#let _twips(value, key) = {
  if type(value) != length or value.em != 0 {
    panic(key + ": expected absolute length (pt or cm), found " + repr(value))
  }
  twips(value)
}

#let _absolute(value, key) = {
  if type(value) != length or value.em != 0 {
    panic(key + ": expected absolute length, found " + repr(value))
  }
  value
}

#let _positive-absolute(value, key) = {
  let value = _absolute(value, key)
  if value <= 0pt {
    panic(key + ": expected a positive absolute length, found " + repr(value))
  }
  value
}

#let _paper(value) = {
  if type(value) == str {
    if value not in _papers {
      panic("paper: unknown paper " + repr(value) + "; " + _errors.expected-one-of(_papers.keys(), value)
        + ", or write (width: …, height: …)")
    }
    let (w, h) = _papers.at(value)
    (name: value, width: w, height: h)
  } else if type(value) == dictionary and value.keys().sorted() == ("height", "width") {
    (
      name: none,
      width: _positive-absolute(value.width, "paper.width"),
      height: _positive-absolute(value.height, "paper.height"),
    )
  } else {
    panic("paper: expected a paper name such as \"a4\" or (width: …, height: …), found " + repr(value))
  }
}

// 字距那一格落在 1/4096 磅上：docGrid 的 w:charSpace 就是这个单位，范例写着1861，1861/4096 = 0.4543pt。
#let _quarter-k(value, key) = {
  let v = _absolute(value, key)
  calc.round(v.pt() * 4096) / 4096 * 1pt
}

// 给行数时 Word 拿版心的缇数除以行数，往下截而不是四舍五入。
#let _pitch-from-count(span, count, key) = {
  if type(count) != int or count <= 0 {
    panic(key + ": expected a positive integer, found " + repr(count))
  }
  calc.floor(span / twip / count) * twip
}

// 字数推字距不截缇：charSpace 的精度是 1/4096 磅，比缇细得多。
#let _char-pitch-from-count(span, count, key) = {
  if type(count) != int or count <= 0 {
    panic(key + ": expected a positive integer, found " + repr(count))
  }
  calc.round(span.pt() / count * 4096) / 4096 * 1pt
}

// 页边距。收 Word 对话框的四格，外加三个简写：x（左右）、y（上下）、rest（没单写的那几边）。
#let _margin-keys = ("top", "bottom", "left", "right", "x", "y", "rest")

#let _margin(value) = {
  if type(value) != dictionary {
    panic("margin: expected dictionary, found " + repr(value))
  }
  for k in value.keys() {
    if k not in _margin-keys {
      panic("margin: unknown key " + repr(k) + "; " + _errors.expected-one-of(_margin-keys, k))
    }
  }
  let side(name, axis) = {
    let v = value.at(name, default: value.at(axis, default: value.at("rest", default: none)))
    if v == none {
      panic("margin: missing " + name + " (write " + name + ", " + axis + ", or rest)")
    }
    _twips(v, "margin." + name)
  }
  (
    top: side("top", "y"), bottom: side("bottom", "y"),
    left: side("left", "x"), right: side("right", "x"),
  )
}

// 页眉与页脚使用同一组字段。
#let _record-keys = ("shown", "from-edge", "style", "border")
#let _shown-values = (auto, true, false)

// 段落下边框的线型，Word「边框和底纹」对话框「样式」栏里的名字：单线、细＋粗双线（小间距）。
#let border-styles = ("single", "thin-thick-small-gap")

// 距边界为 0 表示未指定。默认照中文 Word 的「页眉」「页脚」样式：小五、单倍行距、不对齐网格；页眉下边框
// 0.75 磅单线（w:bottom w:val="single" w:sz="6" w:space="1"），页脚无边框。
#let _header-defaults = (
  shown: auto, from-edge: 0pt,
  style: (asian-font: "songti", size: zihao.xiaowu, line-spacing: "single", snap-to-grid: false),
  border: (style: "single", thickness: 0.75pt, from-text: 1pt),
)
#let _footer-defaults = (
  shown: auto, from-edge: 0pt,
  style: (size: zihao.xiaowu, line-spacing: "single", snap-to-grid: false),
  border: none,
)

#let _fold-record(value, name) = {
  if type(value) != dictionary {
    panic(name + ": expected dictionary, found " + repr(value))
  }
  for k in value.keys() {
    if k not in _record-keys {
      panic(name + ": unknown key " + repr(k) + "; " + _errors.expected-one-of(_record-keys, k))
    }
  }
  let shown = value.at("shown")
  if shown not in _shown-values {
    panic(name + ".shown: expected auto, true, or false, found " + repr(shown))
  }
  let style = value.at("style")
  sheet.validate-style(style, name + ".style")
  let border = value.at("border")
  let border = if border == none { none } else {
    if type(border) != dictionary {
      panic(name + ".border: expected none or dictionary with \"style\", \"thickness\", and \"from-text\", found " + repr(border))
    }
    for k in border.keys() {
      if k not in ("style", "thickness", "from-text") {
        panic(name + ".border: unknown key " + repr(k) + "; expected \"style\", \"thickness\", or \"from-text\"")
      }
    }
    for k in ("thickness", "from-text") {
      if k not in border { panic(name + ".border: missing " + k) }
    }
    let style = border.at("style", default: "single")
    if style not in border-styles {
      panic(name + ".border.style: " + _errors.expected-one-of(border-styles, style))
    }
    (
      style: style,
      thickness: _twips(border.thickness, name + ".border.thickness"),
      from-text: _twips(border.from-text, name + ".border.from-text"),
    )
  }
  (
    shown: shown,
    from-edge: _twips(value.at("from-edge"), name + ".from-edge"),
    style: style,
    border: border,
  )
}

// 页眉和页脚记录需要深合并；局部修改 `shown` 时保留距离、样式和边框。
#let _deep-keys = ("header", "footer")

#let _merge-dict(base, local) = {
  let out = base
  for (k, v) in local {
    if type(v) == dictionary and type(out.at(k, default: none)) == dictionary {
      out.insert(k, _merge-dict(out.at(k), v))
    } else {
      out.insert(k, v)
    }
  }
  out
}

// 页边距那张表逐键并；用户写 (margin: (top: 3cm)) 是「上边距改成 3cm」，不是「页边距只剩上边距」。
#let _margin-clears = (
  x: ("left", "right"),
  y: ("top", "bottom"),
  rest: ("top", "bottom", "left", "right", "x", "y"),
)

#let _merge-margin(base, local) = {
  let cleared = ()
  for (k, sides) in _margin-clears {
    if k in local { cleared += sides }
  }
  let out = base.pairs().filter(((k, _)) => k not in cleared).to-dict()
  for (k, v) in local { out.insert(k, v) }
  out
}

/// 合并两份尚未解析的页面设置输入。普通字段由 `local` 覆盖；`margin`、`header` 和
/// `footer` 逐键合并，因此 `(header: (shown: false))` 不会清掉原有字号和距边界。
/// 模板代码一般使用更高层的 `merge-page-setup`。
/// -> dictionary
#let merge(base, local) = {
  if type(local) != dictionary {
    panic("layout: expected dictionary, found " + repr(local))
  }
  let out = base
  for (k, v) in local {
    if k == "margin" and type(v) == dictionary and type(out.at(k, default: none)) == dictionary {
      out.insert(k, _merge-margin(out.at(k), v))
    } else if k in _deep-keys and type(v) == dictionary and type(out.at(k, default: none)) == dictionary {
      out.insert(k, _merge-dict(out.at(k), v))
    } else {
      out.insert(k, v)
    }
  }
  out
}

#let _keys = (
  "paper", "margin", "line-pitch", "lines-per-page", "char-pitch", "chars-per-line",
  "font-size", "grid", "header", "footer", "linebreaks", "section-start",
)
// 文档网格那张卡的「网格」：无网格／只指定行网格／指定行和字符网格／文字对齐字符网格
// （w:docGrid 的 default / lines / linesAndChars / snapToChars）。最后一档没有做。
#let grids = (none, "lines", "lines-and-chars", "snap-to-chars")
// 页面设置 → 版式 → 节的起始位置。Word 新建节默认“下一页”；这里默认“连续”——文档级那一次
// 也走 section，开头不该翻页，段与段之间要不要翻由模板写
#let _section-starts = ("continuous", "new-page", "odd-page", "even-page")

// 字符网格可由本包用 `text.tracking` 模拟，也可由带 `msword` 断行模式的 Typst 分支处理。
#let engine-linebreaks = {
  let v = sys.inputs.at("linebreaks", default: none)
  if v == none { none } else if v.trim().starts-with("{") { json(bytes(v)) } else { (mode: v) }
}
/// 判断该页面设置下是否由模板模拟字符网格：`docgrid.linebreaks` 为 `none` 时模拟，
/// 否则交给断行引擎。
/// -> bool
#let emulated(layout) = layout.docgrid.at("linebreaks", default: none) == none
// 引擎模式下，每次切换页面设置都重设 `par.linebreaks`；恢复原版式时使用 `auto`。
/// 为断行引擎发出 `set par(linebreaks:)`。未通过 `--input linebreaks` 启用引擎时原样返回。
/// -> content
#let linebreaks-sets(layout, doc) = if engine-linebreaks == none { doc } else {
  let lb = layout.docgrid.at("linebreaks", default: none)
  set par(linebreaks: if lb == none { auto } else { lb })
  doc
}

#let _fold(inputs) = {
  if type(inputs) != dictionary {
    panic("layout: expected dictionary, found " + repr(inputs))
  }
  for k in inputs.keys() {
    if k not in _keys {
      panic("layout: unknown key " + repr(k) + "; " + _errors.expected-one-of(_keys, k))
    }
  }
  let paper = _paper(inputs.at("paper", default: "a4"))
  let margin = _margin(inputs.at("margin", default: (:)))
  let text-width = paper.width - margin.left - margin.right
  let text-height = paper.height - margin.top - margin.bottom

  let font-size = inputs.at("font-size", default: zihao.xiaosi)
  if type(font-size) != length or font-size.em != 0 {
    panic("font-size: expected absolute length such as zihao.xiaosi or 12pt, found " + repr(font-size))
  }

  let given-pitch = inputs.at("line-pitch", default: none)
  let given-lines = inputs.at("lines-per-page", default: none)
  if given-pitch == none and given-lines == none {
    panic("layout: expected line-pitch or lines-per-page")
  }
  let line-pitch = if given-pitch != none {
    _twips(given-pitch, "line-pitch")
  } else {
    _pitch-from-count(text-height, given-lines, "lines-per-page")
  }
  if given-pitch != none and given-lines != none {
    let shown = calc.floor(text-height / line-pitch)
    if shown != given-lines {
      panic(
        "layout: line-pitch " + repr(given-pitch) + " gives " + str(shown)
          + " lines per page, but lines-per-page says " + str(given-lines)
          + "; write one of them, or make them agree",
      )
    }
  }

  let given-char = inputs.at("char-pitch", default: none)
  let given-chars = inputs.at("chars-per-line", default: none)
  let char-pitch = if given-char != none {
    _quarter-k(given-char, "char-pitch")
  } else if given-chars != none {
    _char-pitch-from-count(text-width, given-chars, "chars-per-line")
  } else {
    0pt
  }
  if given-char != none and given-chars != none {
    let shown = calc.floor(text-width / char-pitch)
    if shown != given-chars {
      panic(
        "layout: char-pitch " + repr(given-char) + " gives " + str(shown)
          + " characters per line, but chars-per-line says " + str(given-chars)
          + "; write one of them, or make them agree",
      )
    }
  }

  // 网格四档。auto 按写了什么定：给了字符跨度就是「行和字符」，只给行跨度就是「只指定行」
  let grid = inputs.at("grid", default: auto)
  if grid not in (auto, ..grids) {
    panic("grid: " + _errors.expected-one-of(grids, grid) + " (or auto)")
  }
  if grid == "snap-to-chars" {
    panic("grid: \"snap-to-chars\" (Word's \"Text snaps to character grid\") is not supported; use \"lines-and-chars\"")
  }
  let grid = if grid != auto { grid } else if char-pitch != 0pt { "lines-and-chars" } else { "lines" }
  // 字符网格的增量只在「行和字符」那一档有；「只指定行」时 Word 也不管字符跨度
  let tracking = if grid == "lines-and-chars" and char-pitch != 0pt { char-pitch - font-size } else { 0pt }
  let cells = if char-pitch == 0pt { 0 } else { calc.floor(text-width / char-pitch) }
  let grid = grid != none

  let section-start = inputs.at("section-start", default: "continuous")
  if section-start not in _section-starts {
    panic("section-start: " + _errors.expected-one-of(_section-starts, section-start))
  }

  for (k, defaults) in (header: _header-defaults, footer: _footer-defaults) {
    let v = inputs.at(k, default: (:))
    if type(v) != dictionary {
      panic(
        k + ": expected dictionary (" + _record-keys.map(x => x + ":").join(", ")
          + "), found " + repr(v) + "; to drop it write (shown: false)",
      )
    }
  }
  let linebreaks = inputs.at("linebreaks", default: auto)
  let linebreaks = if linebreaks == auto { engine-linebreaks } else if type(linebreaks) == str {
    (mode: linebreaks)
  } else { linebreaks }
  if linebreaks != none and (type(linebreaks) != dictionary or "mode" not in linebreaks) {
    panic(
      "linebreaks: expected none, a mode name such as \"msword\", or a dictionary with mode:, found "
        + repr(linebreaks),
    )
  }
  let linebreaks = if linebreaks == none or "char-excess" in linebreaks or "char-pitch" in linebreaks {
    linebreaks
  } else { linebreaks + (char-excess: tracking) }

  let header = _fold-record(
    _merge-dict(_header-defaults, inputs.at("header", default: (:))), "header",
  )
  let footer = _fold-record(
    _merge-dict(_footer-defaults, inputs.at("footer", default: (:))), "footer",
  )

  (
    paper: paper.name,
    paper-width: paper.width,
    paper-height: paper.height,
    margin: margin,
    text-width: text-width,
    text-height: text-height,
    docgrid: (
      line-pitch: line-pitch,
      char-pitch: char-pitch,
      tracking: tracking,
      grid: grid,
      line-unit: if grid { line-pitch } else { font-size },
      linebreaks: linebreaks,
    ),
    font-size: font-size,
    cells: cells,
    section-start: section-start,
    header: header,
    footer: footer,
    inputs: inputs,
  )
}

/// 将 Word“页面设置”对话框中的值解析为节级页面设置。可传一个字典，或全部使用具名
/// 参数；两种写法不能混用。
///
/// - `paper`：Typst 的官方纸张名，如 `"a4"`；自定义尺寸写 `(width:, height:)`。
/// - `margin`：四边页边距，可用 `x`、`y`、`rest` 简写。
/// - `line-pitch` / `lines-per-page`：行跨度或每页行数，二选一。
/// - `char-pitch` / `chars-per-line`：字符跨度或每行字符数，二选一。
/// - `font-size`：文档网格那张卡「字体设置」里的字号（Normal 样式的字号），不等同于正文样式字号。
/// - `grid`：那张卡的「网格」：`none`（无网格）、`"lines"`（只指定行网格）、`"lines-and-chars"`（指定行和
///   字符网格）；`auto` 按给没给字符跨度定。段落是否贴纵向网格另由样式的 `snap-to-grid` 控制。
/// - `header`、`footer`：`shown`、`from-edge`、`style`、`border` 组成的记录。`border` 是那一段的下边框，
///   照 Word「边框和底纹」对话框：`style`（`"single"` 或 `"thin-thick-small-gap"`）、`thickness`、`from-text`；
///   `none` 不画。默认照中文 Word 的「页眉」「页脚」样式：页眉 0.75 磅单线，页脚没有。
///
/// 厘米值可以原样填写，内部会按 Word 规则量化。字符跨度保留 `w:charSpace` 的
/// 1/4096pt 精度。
///
/// ```typ
/// #let layout = page-setup(
///   paper: "a4",
///   margin: (top: 3.8cm, rest: 3cm),
///   lines-per-page: 33,
///   chars-per-line: 34,
///   font-size: 12pt,
///   header: (shown: true, from-edge: 3cm),
/// )
/// ```
/// -> dictionary
#let page-setup(..args) = {
  if args.pos().len() > 1 or (args.pos().len() == 1 and args.named().len() > 0) {
    panic("page-setup: expected either named fields or one input dictionary")
  }
  if args.pos().len() == 1 { return _fold(args.pos().first()) }
  _fold(args.named().pairs().filter(((k, v)) => if k == "linebreaks" { v != auto } else { v != none }).to-dict())
}

/// 判断值是否为 `page-setup` 解析后的记录，而非输入字典。
/// -> bool
#let is-page-setup(value) = type(value) == dictionary and "docgrid" in value

/// 在基准页面设置上应用一份局部修改。`local` 为输入字典时深合并并重新解析；若已经是
/// `page-setup` 的完整结果，则直接替换；`auto` 返回 `base`。
///
/// ```typ
/// #let landscape = merge-page-setup(base, (
///   paper: (width: 297mm, height: 210mm),
///   margin: (x: 2.5cm),
/// ))
/// ```
/// -> dictionary
#let merge-page-setup(base, local) = {
  if local == auto { return base }
  if is-page-setup(local) { return local }
  _fold(merge(base.inputs, local))
}

/// 读取当前节的完整页面设置。必须在 `context` 中调用；尚未安装 `document` 或 `section`
/// 时返回 `default`，省略 `default` 则报错。模板规则需要当前版心或网格时使用。
/// -> dictionary
#let current-page-setup(default: none) = {
  let s = page-setup-state.get()
  if s != none { s } else if default != none { _fold(default) } else {
    panic("no page setup in effect: the document-level page-setup-state has not been set")
  }
}
