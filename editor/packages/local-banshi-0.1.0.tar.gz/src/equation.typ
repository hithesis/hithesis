// 公式：国标字形、块级公式按 Word 的行高算法补行距、数学字体。都由 document 装，不导出。

#import "paragraph/spacing.typ": spacing
#import "./layout/resolve.typ" as _layout


// GB/T 3102.11—1993 要求偏微分、实部、虚部使用正体，并采用倾斜的“小于等于”与
// “大于等于”字形。Typst 默认已正确处理大小写希腊字母和微分符号。
#let _gb-shapes(doc) = {
  show sym.partial: math.upright
  show sym.Re: math.op("Re")
  show sym.Im: math.op("Im")
  show sym.lt.eq: sym.lt.eq.slant
  show sym.gt.eq: sym.gt.eq.slant
  doc
}

// 块级公式的上方不另补空白：分式所在行的“上一行基线到公式基线”量得 26.93pt，
// 正好等于正文行深 7.275pt 加公式上升部 19.65pt，验证了 Word 按实际内容高度
// 计算这一侧。额外行距只补在公式下方。
// 按 Word 的算法给块级公式补行高：行距倍数乘公式自然高度，或贴网格时取整数个网格行，多出的部分
// 补在公式下方。style 是正文那一条；document 装在段的规则里。
#let line-height-rules(style, doc) = {
  show math.equation.where(block: true): it => context {
    let metrics = spacing(style, layout: _layout.current-page-setup())
    let nat = measure(text(top-edge: "ascender", bottom-edge: "descender", it)).height
    let want = if metrics.snap {
      let g = metrics.docgrid.line-pitch
      calc.ceil(nat / g) * g
    } else {
      metrics.line-height / metrics.single * nat
    }
    let extra = want - measure(it).height
    if extra <= 0pt { it } else { block(below: extra, it) }
  }
  doc
}

// 数学字体（字体表的 math 角色）与 GB/T 3102.11 的字形替换。document 装在字的规则里。
#let math-rules(font, cjk: none, gb: true, doc) = {
  show math.equation: set text(
    font: if cjk == none { font } else {
      ((name: cjk, covers: regex("∥")), font, cjk)
    },
  )
  show math.equation: it => if gb { _gb-shapes(it) } else { it }
  doc
}
