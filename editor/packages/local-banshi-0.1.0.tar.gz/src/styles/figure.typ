// 图表块的三段空当：above（块前）、gap（图与题注之间）、below（块后），Word 里是图表前后
// 各空一行、装图段多倍行距多出来的那一截。数从样式表的 figure.image / figure.table 解出来，
// 落成 set figure(gap:) 与 set block(above:, below:) 两条 show-set——它们给不了 context，
// 按文档级的版面算一次。

#import "../paragraph/spacing.typ": spacing, amount
#import "../layout/resolve.typ" as _layout
#import "../fonts/resolve.typ": fontset-state

/// 把 figure.image / figure.table 的三段空当解成长度：`(image: (above:, gap:, below:), table: (…))`。
/// above / below 收长度或 `(lines: n)`，写 auto 当场报错；gap 写 auto 按 Word 算：网格开着时
/// 装图行占整数个网格行、图在里面居中，多出来的已在余量里，gap 就是题注的段前；关着是
/// (倍数 − 1) × 单倍行高再加题注段前。表的 gap 是题注那一段的段后。
/// -> dictionary
#let figure-spacing(styles, layout, metrics) = {
  let sides = ("above", "gap", "below")
  // 样式表没写 figure 的那几条就按空表：三段都是 0
  let fig = styles.at("figure", default: (:))
  let cap = spacing(fig.at("caption", default: (:)), layout: layout, metrics: metrics)
  // 装图段自己的行高：三段空当不是段属性，剥掉再折。段里只有图和段落标记，行高按标记的
  // 西文字体算（与空段同一条规则，见 paragraph/enter.typ）
  let m = spacing(
    fig.at("image", default: (:)).pairs().filter(((k, v)) => k not in sides).to-dict(),
    layout: layout, metrics: metrics, latin: true,
  )
  let side(which, key) = {
    let v = fig.at(which, default: (:)).at(key, default: 0pt)
    if v == auto { panic("figure." + which + "." + key + ": auto reached figure-spacing unresolved") }
    amount(v, layout.docgrid)
  }
  let of(which, gap-auto) = (
    above: side(which, "above"),
    gap: if fig.at(which, default: (:)).at("gap", default: auto) == auto { gap-auto } else { side(which, "gap") },
    below: side(which, "below"),
  )
  let snapped = layout.docgrid.grid and layout.docgrid.line-pitch != 0pt
  (
    image: of("image", (if snapped { 0pt } else { m.line-height - m.single }) + cap.above),
    table: of("table", cap.below),
  )
}

/// 三段空当落到 figure 上。装在模板的规则之前：单个图表要不一样走原生
/// `block(above:, below:, figure(…))`，模板的分图那条 0 也要压得过这两条。
/// -> content
#let figure-rules(styles, layout: auto, metrics: auto, doc) = {
  let layout = if layout == auto { _layout.current-page-setup() } else { layout }
  let metrics = if metrics == auto { fontset-state.get().metrics } else { metrics }
  let sp = figure-spacing(styles, layout, metrics)
  set figure(gap: sp.image.gap)
  show figure.where(kind: table): set figure(gap: sp.table.gap)
  show figure: set block(above: sp.image.above, below: sp.image.below)
  show figure.where(kind: table): set block(above: sp.table.above, below: sp.table.below)
  doc
}
