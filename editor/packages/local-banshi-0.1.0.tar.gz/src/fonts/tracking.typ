#import "../content.typ": plain-text
#import "../runs.typ": has-cjk
#import "./resolve.typ": boundary-loss
// 要治的毛病。 字符网格靠 text(tracking:) 给每个汉字补一段字距增量撑满一格，而 Typst 在切换 text run 时会丢掉该 run 最后一个字形的 tracking。

// 一处 run 边界，丢的同样是一段 tracking。
#let tracking-pad(it, probe: auto) = context {
  if not has-cjk(plain-text(if probe == auto { it } else { probe })) { return it }
  h(text.tracking * boundary-loss(), weak: true)
  it
  h(text.tracking * boundary-loss(), weak: true)
}

/// 在一处文本片段边界丢掉的字距：`tracking` 乘以入口探得的丢失份数。模板自己排西文
/// 片段（目录条目的编号那类）时用它补回。必须在 context 中调用。
/// -> length
#let boundary-pad(tracking) = tracking * boundary-loss()

#let tracking-rules(doc) = {
  show strong: tracking-pad
  show emph: tracking-pad
  show highlight: tracking-pad
  show strike: tracking-pad
  show link: tracking-pad
  show math.equation.where(block: false): tracking-pad
  doc
}
