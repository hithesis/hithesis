// 上下标按 Word 排：字号住在半磅格上，汉字与西文各一档。
#import "./resolve.typ": cjk-scripts

// Word 的字号都住在半磅格上。
#let _half(x) = calc.round(x / 0.5pt) * 0.5pt

#let latin-size(s) = _half(0.65 * s)
#let super-raise(s) = s - latin-size(s)
#let sub-sink(s) = 0.08 * s

#let cjk-size(s) = _half(0.5 * s)
#let cjk-super-raise(s) = cjk-size(s)
#let cjk-sub-sink(s) = _half(0.0625 * s)

// 裹一层：西文按 shift(s) 抬／沉，汉字按 cjk-shift(s)。
#let _scripted(it, shift, cjk-shift) = context {
  let s = text.size
  show cjk-scripts: c => {
    set text(size: cjk-size(s), baseline: cjk-shift(s))
    c
  }
  text(size: latin-size(s), baseline: shift(s), it)
}

#let super-sub-rules(doc) = {
  set super(typographic: false, size: 1em, baseline: 0pt)
  set sub(typographic: false, size: 1em, baseline: 0pt)
  show super: it => _scripted(it, s => -super-raise(s), s => -cjk-super-raise(s))
  show sub: it => _scripted(it, sub-sink, cjk-sub-sink)
  doc
}
