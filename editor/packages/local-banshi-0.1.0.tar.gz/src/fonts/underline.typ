// Word 对混合字体的同一 run 绘制连续下划线；线位与线宽取自 Word 导出的测量结果。
#import "./presets.typ": underline-offset, underline-stroke, underlines
#import "./tracking.typ": tracking-pad
#import "./resolve.typ": boundary-loss

#let _line(body, offset: underline-offset, stroke: underline-stroke) = context underline(
  offset: offset, stroke: stroke, evade: false, extent: text.tracking / 2 * boundary-loss(), body,
)

/// Word 给这一档字画下划线的位置与线宽（em）：西文照字体的 post 表，中文照 Word 实测。
/// `latin: true` 是全西文的那一档。
/// -> dictionary
#let underline-of(style, latin: false) = if latin { underlines.latin } else { underlines.cjk }

#let underline-rules(doc) = {
  show underline.where(evade: true): it => tracking-pad(_line(it.body), probe: it.body)
  doc
}
