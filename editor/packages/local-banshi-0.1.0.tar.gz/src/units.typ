// Typst 的 pt 与 Word 界面中的磅相同，均为 1/72 英寸。

/// 一个缇（twip），即 1/20 磅。
/// -> length
#let twip = 0.05pt

/// 按 Word 的存储规则将绝对长度量化为整缇。
///
/// 厘米按 567 twips/cm 换算；以磅输入的数按 20 twips/pt 换算。`floor: true`
/// 用于 Word 会截断而非四舍五入的“行数”计算。
/// -> length
#let twips(value, floor: false) = {
  if type(value) != length {
    panic("twips: expected absolute length (pt or cm), found " + repr(value))
  }
  if value.em != 0 {
    panic("twips: expected absolute length (pt or cm), found " + repr(value) + " (em is relative)")
  }
  if floor { return calc.floor(value / twip + 0.0001) * twip }
  let near(a, b) = calc.abs(a - b) < 1e-6
  let pt = value.pt()
  let cm = value.cm()
  let n = if near(pt, calc.round(pt, digits: 2)) {
    calc.round(pt, digits: 2) * 20
  } else if near(cm, calc.round(cm, digits: 2)) {
    calc.round(cm, digits: 2) * 567
  } else {
    pt * 20
  }
  calc.round(n) * twip
}

/// 一个 English Metric Unit（EMU）。OOXML 使用 EMU 记录绘图尺寸。
/// -> length
#let emu = 1pt / 12700

/// 将 OOXML `w:rPr/w:spacing` 的值换算为长度。
///
/// ECMA-376 将它定义为 `ST_SignedTwipsMeasure`，照规范 `w:val="40"` 应为 2pt。
/// 实际上，两份互相独立的 Word 输出都按 1/10 磅排：macOS Word 导出的报告与
/// 学校在 Windows Word 生成的 PDF 中，18pt 文字的步进为 22.07/21.94pt，即约
/// `18 + 4.00pt`；另一处 `w:val="12"` 量得 1.20pt。两组结果都是规范 twip
/// 值的两倍，因此这里有意采用实测的 1/10 磅。
/// -> length
#let run-spacing(units) = units / 10 * 1pt

/// 将 OOXML `w:docGrid/@w:charSpace` 换算为字符间距增量。
/// -> length
#let char-space(units) = units / 4096 * 1pt
