#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing, amount, families-of
#import "./axes.typ": report-stages as _report-stages
#import "./axes.typ": final-body as _final-body
#import banshi.fonts as _fonts
#import "./heading/rules.typ" as _heading
#import "./heading/heading.typ" as _heading-mod
#import banshi.layout as _layout
#import banshi.layout: chars
#import "./layout/parts.typ": default-inputs as _default-inputs
#import "./math/equation.typ" as _equation
#import "./math/theorem.typ" as _theorem
#import "./vendor/quan/lib.typ": quan as _quan
#import "./terms/lang.typ" as _lang
#import "./figure/caption.typ" as _captions
#import "./figure/split.typ" as _split
#import "./figure/kinds/table.typ" as _three-line
#import "./figure/kinds.typ": algorithm-kind as _algorithm-kind
#import "./figure/kinds/raw.typ" as _listing
#import "./references/abbreviations.typ" as _abbreviations
#import "./pages/references.typ": _omni, references-title as _references-title
#import "./references/bibliography.typ": gb7714-for as _gb7714-for
#import "@local/omni-gb7714:0.1.0": bibliography
#import "./heading/numbering.typ": nonumber-rules as _nonumber-rules
#import "./case.typ" as _case
#import banshi.fonts: songti, kaishu
#import banshi.fonts: zihao

#import "./info.typ" as _info
#import "./settings/resolve.typ" as _settings
#import "./terms/lookup.typ" as _terms
#import "./axes.typ" as _axes
#import banshi.errors as _errors
#import "./layout/matter.typ" as _matter
#import banshi.styles as sheet
#import banshi.styles as _figure-spacing
#import "./styles/lookup.typ" as _lookup
#import "./styles/presets.typ" as _config-styles
#import "./settings/defaults.typ" as _config-settings
#import "./info.typ": info-defaults as _info-defaults

#import "./heading/numbering.typ" as _numbering

#let iota-hit(
  layout: auto,
  styles: (:),
  fontset: auto,
  metrics: (:),
  fake-bold: auto,
  fake-italic: auto,
  category: auto,
  page-numbering: auto,
  lang: "zh",
  title-case: auto,
  two-hanzi: auto,
  gb7714: (:),
  degree-level: auto,
  degree-type: auto,
  form: auto,
  stage: auto,
  campus: auto,
  title: auto,
  title-en-xiaoer: auto,
  subtitle: auto,
  author: auto,
  institution: auto,
  date: auto,
  student-id: auto,
  supervisor: auto,
  co-supervisor: auto,
  industry-supervisor: auto,
  degree-applied: auto,
  speciality: auto,
  practice-type: auto,
  affiliation: auto,
  defense-date: auto,
  secrecy: auto,
  classified-index: auto,
  udc: auto,
  school-code: auto,
  overrides: (:),
  heading-1-pagebreak: auto,
  openright: auto,
  caption-bilingual: auto,
  caption-numbering-by-chapter: auto,
  equation-numbering-by-chapter: auto,
  equation-numbering-fullwidth: auto,
  theorem-numbering-by-chapter: auto,
  theorem-body-indent: auto,
  note-width: auto,
  abbreviation-indexed: auto,
  enum-hanging: auto,
  list-hanging: auto,
  abbreviation-fullwidth: auto,
  abbreviation-links: auto,
  subcaption-numbering: auto,
  subcaption-separator: auto,
  subcaption-bilingual: auto,
  subcaption-gap: auto,
  heading-body-indent: auto,
  algorithm-style: auto,
  raw-style: auto,
  em-dash: auto,
  appendix-numbering: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  doc,
) = context {
// lang: auto 必须在本函数安装文本规则前读取外层 text.lang。
  let resolve-axis(axis, value, fallback) = {
    let v = _axes.normalize(((axis): if value == auto { fallback } else { value })).at(axis)
    if v not in _axes.axes.at(axis) {
      panic(_errors.expected-one-of(_axes.axes.at(axis), v) + " (axis: " + axis + ")")
    }
    v
  }
  let category = resolve-axis("category", category, "stem")
  let form = resolve-axis("form", form, "dissertation")
  let stage = resolve-axis("stage", stage, "final")
  let campus = resolve-axis("campus", campus, "harbin")
  let is-report = stage in _report-stages
  let this-degree = if degree-level == auto { _info-defaults.degree-level } else { degree-level }
  let report-body = is-report and not _final-body(campus, this-degree, stage)
  let body-stage = if report-body { stage } else { "final" }
  let numbered-references = report-body and campus != "shenzhen"
  let layout = _layout.merge-page-setup(
    _layout.page-setup(_default-inputs(
      degree-level: this-degree, stage: stage, campus: campus,
    )),
    layout,
  )
  let page-numbering = if page-numbering != auto {
    page-numbering
  } else if report-body { none } else { "1" }
  let doc-lang = _lang.normalize(if lang == auto { text.lang } else { lang })
  _info.info(lang: doc-lang, ..(
    ("degree-level", degree-level),
    ("degree-type", degree-type),
    ("category", category),
    ("form", form),
    ("stage", stage),
    ("campus", campus),
    ("title", title),
    ("title-en-xiaoer", title-en-xiaoer),
    ("subtitle", subtitle),
    ("author", author),
    ("institution", institution),
    ("date", date),
    ("student-id", student-id),
    ("supervisor", supervisor),
    ("co-supervisor", co-supervisor),
    ("industry-supervisor", industry-supervisor),
    ("degree-applied", degree-applied),
    ("speciality", speciality),
    ("practice-type", practice-type),
    ("affiliation", affiliation),
    ("defense-date", defense-date),
    ("secrecy", secrecy),
    ("classified-index", classified-index),
    ("udc", udc),
    ("school-code", school-code),
  ).filter(((k, v)) => v != auto).to-dict())
  let em-dash = _settings.resolve-em-dash(
    local: em-dash, campus: campus, degree-level: this-degree, stage: stage,
  )
  let f = _fonts.fontset(value: fontset, em-dash: em-dash, metrics: metrics)
  let variant-style(name) = _lookup.variant-style(
    name, lang: doc-lang, degree-level: this-degree, stage: stage, campus: campus,
  )
  let body-line-spacing = variant-style("body-line-spacing")
  let bold-upto = variant-style("heading-bold")
  let bold(level) = if level <= bold-upto { (latin-bold: true) } else { (:) }
  let body-indent = {
    let v = variant-style("body-indent")
    if v == auto { (:) } else { (first-line-indent: v) }
  }
  let body-spacing = if body-line-spacing == auto { (:) } else {
    (line-spacing: body-line-spacing)
  }
  let chapter = variant-style("chapter")
  let figure-style = variant-style("figure")
  let styles = sheet.styles(_config-styles.default-styles, styles, preset: if is-report and not report-body {
    (
      body: (snap-to-grid: false) + body-spacing + body-indent,
      figure: figure-style,
      theorem: variant-style("theorem"),
      chapter: bold(1) + chapter, section: bold(2),
      subsection: bold(3), subsubsection: bold(4),
    )
  } else if not report-body { (theorem: variant-style("theorem")) } else {
    let gap = variant-style("heading-spacing")
    (
      body: body-spacing + body-indent,
      figure: figure-style,
      theorem: variant-style("theorem"),
      chapter: bold(1) + chapter,
      section: (above: gap, below: gap) + bold(2),
      subsection: (above: gap, below: gap) + bold(3),
      subsubsection: bold(4),
    )
  })
  let chapter-pagebreak = if heading-1-pagebreak != auto { heading-1-pagebreak } else { not report-body }
  let heading-levels = if report-body { _heading.report-levels } else { _heading.levels }
  let styles = styles + ("chapter", heading-levels.first()).dedup().map(name => (
    name, styles.at(name) + (page-break-before: chapter-pagebreak),
  )).to-dict()
  for key in styles.theorem.head.keys() {
    if key not in _theorem.head-keys {
      panic("styles.theorem.head: unknown key \"" + key + "\"; " + _errors.expected-one-of(_theorem.head-keys, key)
        + " (the head is a run inside the paragraph; size and spacing come from styles.theorem.body)")
    }
  }
  let styles = styles + (theorem: (
    head: (asian-font: styles.body.asian-font, latin-font: styles.body.at("latin-font", default: "serif")) + styles.theorem.head,
    body: styles.body + (above: 0pt, below: 0pt) + styles.theorem.body,
  ))
  // 图注、表注与题注同一档：字号行距跟题注走，只是左起、不缩进
  let styles = styles + (figure: styles.figure + (
    note: styles.figure.caption + (align: left, first-line-indent: (chars: 0)) + styles.figure.note,
  ))
  let body = styles.body
  let family = families-of(body, f)
  let body-metrics = spacing(body, layout: layout, metrics: f.metrics)
  if overrides != (:) { _terms.terms-overrides(overrides, lang: doc-lang) }
  _settings.settings-overrides(
    (
      openright: openright,
      fake-bold: fake-bold,
      fake-italic: fake-italic,
      caption-bilingual: caption-bilingual,
      em-dash: em-dash,
      algorithm-style: algorithm-style,
      raw-style: raw-style,
      equation-numbering-fullwidth: equation-numbering-fullwidth,
      abbreviation-indexed: abbreviation-indexed,
      enum-hanging: enum-hanging,
      list-hanging: list-hanging,
      subcaption-numbering: subcaption-numbering,
      subcaption-separator: subcaption-separator,
      subcaption-bilingual: subcaption-bilingual,
      subcaption-gap: subcaption-gap,
      theorem-body-indent: theorem-body-indent,
      note-width: note-width,
      heading-body-indent: if heading-body-indent != auto { heading-body-indent } else {
        let value = _config-settings.report-heading-body-indent
          .at(campus, default: (:))
          .at(this-degree, default: none)
        if is-report and value != none { value } else { auto }
      },
      appendix-numbering: appendix-numbering,
      outline-entry-right-margin: outline-entry-right-margin,
      outline-entry-number-align: outline-entry-number-align,
    )
      .pairs()
      .filter(((k, v)) => v != auto)
      .to-dict(),
  )
  let caption-by-chapter = _settings.resolve-caption-numbering-by-chapter(
    local: caption-numbering-by-chapter, stage: body-stage,
    campus: campus, degree-level: this-degree,
  )
  let rules(doc) = {
    set page(numbering: page-numbering)
    set heading(supplement: none)
    _lang.doc-lang.update(doc-lang)
    _case.check-title-case(title-case)
    _case.title-case-state.update(if title-case == auto { none } else { title-case })
    _heading-mod.check-two-hanzi(two-hanzi)
    _heading-mod.two-hanzi-state.update(two-hanzi)
    let numbering = _numbering.resolve-numbering(
      auto, lang: doc-lang, category: category, stage: stage,
    )
    show footnote.entry: set text(size: zihao.xiaowu)
    show: _heading.heading-checks.with(numbering: numbering, chapter-pagebreak: chapter-pagebreak)
    _settings.caption-by-chapter.update(caption-by-chapter)
    _settings.equation-by-chapter.update(
      _settings.resolve-equation-numbering-by-chapter(
        local: equation-numbering-by-chapter, stage: body-stage,
      ),
    )
    let figure-spacing = _figure-spacing.figure-spacing(
      styles + (figure: styles.figure + ("image", "table").map(which => (which, {
        let st = styles.figure.at(which)
        for key in ("above", "below") {
          if st.at(key, default: auto) == auto { st.insert(key, _config-styles.default-styles.figure.image.above) }
        }
        st
      })).to-dict()),
      layout, f.metrics,
    )
    set figure.caption(separator: context h(chars(_config-settings.caption-separator-auto.at(doc-lang, default: _config-settings.caption-separator-auto.zh).chars)))
    show: _listing.listing-rules
    show: _split.split-rules.with(style: styles.figure.caption, by-chapter: caption-by-chapter, body-metrics: body-metrics)
    show: _captions.caption-rules.with(
      style: styles.figure.caption,
      note-style: styles.figure.note,
      body-metrics: body-metrics,
      by-chapter: caption-by-chapter,
      equation-by-chapter: _settings.resolve-equation-numbering-by-chapter(
        local: equation-numbering-by-chapter, stage: body-stage,
      ),
    )
    show: _three-line.table-rules.with(by-chapter: caption-by-chapter)
    show figure.where(kind: _algorithm-kind): set figure(gap: if (
      _settings.resolve-algorithm-style(from: algorithm-style).frame == "boxed"
    ) { figure-spacing.image.gap } else { 0pt })
    show figure.where(kind: raw): set figure(gap: if (
      _settings.resolve-raw-style(from: raw-style).frame in ("boxed", none)
    ) { figure-spacing.image.gap } else { 0pt })
    set enum(numbering: if doc-lang == "en" { "(1)" } else { "（1）" })
    show: _equation.equation-rules.with(
      by-chapter: _settings.resolve-equation-numbering-by-chapter(
        local: equation-numbering-by-chapter, stage: body-stage,
      ),
      supplement: _terms.term-of(doc-lang, "caption", "equation"),
    )
    show: _theorem.theorem-rules.with(
      by-chapter: _settings.resolve-theorem-numbering-by-chapter(
        local: theorem-numbering-by-chapter, stage: body-stage,
      ),
      style: styles.theorem,
    )
    show: _omni.gb7714.with(
      .._gb7714-for(category)
        + (title: if numbered-references { none } else { _references-title(doc-lang, centered: styles.chapter.align == center) })
        + gb7714,
    )
    // 脚注编号画圈（omni 装的 quan）：圈里的数字用宋体，与 ①–⑩ 的字形同一副；正文里的数字不受影响
    set footnote(numbering: n => text(font: f.families.songti, _quan(n)))
    // 标记不走 super：Typst 的 super 只抬字形不抬盒子，quan 画的圈会留在原处、数字冒到圈顶。
    // 整个标记装进一个盒子一起抬，字号与抬升量照 super 的默认（0.6em、0.5em）
    show footnote: it => context {
      let loc = it.location()
      link(loc, box(baseline: -0.5em, text(size: 0.6em, std.numbering(it.numbering, ..counter(footnote).at(loc)))))
    }
    let report-bibliography(doc) = {
      show std.bibliography: it => {
        heading(level: 1, numbering: numbering, _references-title(doc-lang))
        it
      }
      doc
    }
    show: if numbered-references { report-bibliography } else { doc => doc }
    show: _nonumber-rules
    show: _abbreviations.rules
    _abbreviations.configure(fullwidth: abbreviation-fullwidth, links: abbreviation-links)
    doc
  }
  banshi.document(
    layout, styles, f,
    lang: doc-lang,
    options: banshi.options(
      fake-bold: fake-bold, fake-italic: fake-italic,
      enum-hanging: enum-hanging, list-hanging: list-hanging,
    ),
    .._matter.header-footer(layout, stage),
    headings: _heading.heading-relation(levels: heading-levels),
    captions: _captions.caption-relation(by-chapter: caption-by-chapter),
    rules: rules,
    doc,
  )
}
