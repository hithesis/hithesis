#import "@local/banshi:0.1.0" as banshi
#import banshi.errors as _errors

#let axes = (
  degree-level: ("bachelor", "master", "doctor"),
  degree-type: ("academic", "professional"),
  category: ("stem", "hass"),
  form: ("dissertation", "practice"),
  stage: ("final", "proposal", "interim"),
  campus: ("harbin", "shenzhen"),
)
#let _campus-forms = (shenzhen: ("bachelor", "master", "doctor"))

#let campus-for(campus, degree-level) = if degree-level in _campus-forms.at(
  campus, default: (),
) { campus } else { "harbin" }
#let aliases = (
  category: (hss: "hass"),
  form: (design: "practice", practical-results: "practice", thesis: "dissertation"),
  stage: (opening: "proposal", mid-term: "interim", midterm: "interim"),
  campus: (weihai: "harbin"),
)
#let normalize(variant) = {
  let out = (:)
  for (axis, value) in variant {
    let by-axis = aliases.at(axis, default: (:))
    out.insert(axis, by-axis.at(value, default: value))
  }
  out
}
#let variant-candidates(variant) = {
  let variant = normalize(variant)
  for axis in variant.keys() {
    if axis not in axes {
      panic("unknown axis: " + axis)
    }
  }
  let out = ((segments: (), specificity: 0),)
  for (axis, values) in axes {
    if axis not in variant { continue }
    let value = variant.at(axis)
    if value not in values {
      panic(_errors.expected-one-of(values, value) + " (axis: " + axis + ")")
    }
    let next = ()
    for base in out {
      next.push((segments: base.segments + (value,), specificity: base.specificity + 2))
      for other in values.filter(v => v != value) {
        next.push((segments: base.segments + ("not-" + other,), specificity: base.specificity + 1))
      }
      next.push(base)
    }
    out = next
  }
  out
}
#let degree-type-for(degree-level, degree-type, form) = {
  if degree-level == "bachelor" { return none }
  if degree-type == auto {
    return if form == "practice" { "professional" } else { "academic" }
  }
  if form == "practice" and degree-type == "academic" {
    panic(
      "degree-type: \"academic\" has no meaning with form: \"practice\" "
        + "(a practice outcome is submitted for a professional degree only; "
        + "write degree-type: \"professional\", or drop it and let auto pick)",
    )
  }
  degree-type
}
#let report-stages = ("proposal", "interim")
#let final-body(campus, degree-level, stage) = (
  stage in report-stages and campus == "shenzhen" and degree-level == "bachelor"
)
