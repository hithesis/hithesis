#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts: zihao
// 数值取自原始 DOCX，换算结果由 PDF 回归测试固定。
#let final-layout = (
  margin: (top: 3.8cm, rest: 3cm),
  line-pitch: 19.55pt,
  char-pitch: 12.4543pt,
  font-size: zihao.xiaosi,
  header: (
    shown: auto,
    from-edge: 3cm,
    style: (asian-font: "songti", size: zihao.xiaowu, line-spacing: "single", snap-to-grid: false),
    border: (style: "thin-thick-small-gap", thickness: 2.25pt, from-text: 1pt),
  ),
  footer: (
    shown: auto,
    from-edge: 2.3cm,
    style: (size: zihao.xiaowu),
    border: none,
  ),
)
#let _report-footer = (
  shown: true,
  from-edge: 1.75cm,
)

#let _bachelor-report = (
  margin: (rest: 2.3cm),
  line-pitch: 15.6pt,
  font-size: zihao.xiaosi,
  header: (shown: false, from-edge: 0cm),
  footer: _report-footer,
)
#let _graduate-report(bottom) = (
  margin: (top: 2.5cm, x: 2.5cm, bottom: bottom),
  line-pitch: 15.6pt,
  font-size: zihao.xiaosi,
  header: (shown: false, from-edge: 1.5cm),
  footer: _report-footer,
)
#let _shenzhen-header = (
  shown: true,
  border: (style: "thin-thick-small-gap", thickness: 3pt, from-text: 1pt),
)

#let _shenzhen-proposal = (
  margin: (top: 3.2cm, left: 3cm, right: 2.8cm, bottom: 3cm),
  line-pitch: 19.55pt,
  char-pitch: 12.6499pt,
  font-size: zihao.xiaosi,
  header: _shenzhen-header + (from-edge: 3cm),
  footer: _report-footer + (from-edge: 2.3cm + 11.88pt),
)

#let _shenzhen-interim = (
  margin: (top: 2.5cm, x: 2.5cm, bottom: 2.3cm),
  line-pitch: 15.6pt,
  font-size: zihao.xiaosi,
  header: _shenzhen-header + (from-edge: 1.8cm),
  footer: _report-footer,
)
#let _shenzhen-bachelor = final-layout + (
  grid: none,
  char-pitch: 12pt,
  header: final-layout.header + (
    shown: true,
    from-edge: 2.4cm + 12pt,
    border: (style: "thin-thick-small-gap", thickness: 3pt, from-text: 4pt),
  ),
  footer: final-layout.footer + (shown: true),
)

#let report-layouts = (
  harbin: (
    bachelor: (proposal: _bachelor-report, interim: _bachelor-report),
    master: (proposal: _graduate-report(2.2cm), interim: _graduate-report(2.3cm)),
    doctor: (proposal: _graduate-report(2.5cm), interim: _graduate-report(2.5cm)),
  ),
  shenzhen: (
    bachelor: (proposal: _shenzhen-bachelor, interim: _shenzhen-bachelor),
    master: (proposal: _shenzhen-proposal, interim: _shenzhen-interim),
    doctor: (proposal: _shenzhen-proposal, interim: _shenzhen-interim),
  ),
)
#let report-toc-headerless = (
  shenzhen: (master: ("interim",), doctor: ("interim",)),
)
#let _shenzhen-bachelor-cover = (
  margin: (top: 72pt, x: 90pt, bottom: 72pt),
  line-pitch: 19.75pt,
  char-pitch: 12pt,
)

#let report-cover-layouts = (
  shenzhen: (
    master: (
      proposal: (
        margin: (top: 1.92cm, x: 1.8cm, bottom: 2cm),
        line-pitch: 15.6pt,
        char-pitch: 12pt,
      ),
    ),
    bachelor: (
      proposal: _shenzhen-bachelor-cover,
      interim: _shenzhen-bachelor-cover,
    ),
  ),
)

#let part-layouts = (
  cover: (line-pitch: 19.75pt, header: (shown: false), footer: (shown: false)),
  titlepage: (line-pitch: 19.75pt, header: (shown: false), footer: (shown: false)),
  achievements: (char-pitch: 12.672pt),
  declarations-graduate: (char-pitch: 12.672pt),
)
