#import "@local/banshi:0.1.0" as banshi
#import "../info.typ": info-get
#import "../settings/resolve.typ": resolve-openright
#import "../references/abbreviations.typ": reset as reset-abbreviations
#import banshi.layout as _layout
#import "./parts.typ": standalone-layout
#import "./header.typ": header-line
#import "../axes.typ": report-stages
#import "../heading/numbering.typ" as _numbering
#import "../settings/resolve.typ" as _settings
#import "../terms/lookup.typ": term-table
#import "../terms/lang.typ": doc-lang
#let clear-page(to: none) = {
  if to == none {
    pagebreak(weak: true)
  } else {
    set page(header: none, footer: none, numbering: none)
    pagebreak(weak: true, to: to)
  }
}
#let matter-openright = state("iota-hit-matter-openright", false)
#let frontmatter-openright = state("iota-hit-frontmatter-openright", auto)
#let mainmatter-openright = state("iota-hit-mainmatter-openright", auto)
#let decorated-number(n, separator: 4.5pt) = {
  if n == none or n == [] { return }
  [-]
  h(separator)
  n
  h(separator)
  [-]
}
#let front-page-numbering = "I"
#let main-page-numbering = "1"
#let header-footer(layout, stage) = {
  let is-report = stage in report-stages
  let shown(record) = if record.shown == auto { not is-report } else { record.shown }
  (
    header: if not shown(layout.header) { none } else {
      (odd: () => header-line("odd", auto), even: () => header-line("even", auto))
    },
    footer: if shown(layout.footer) {
      () => context if page.numbering != none {
        if is-report and page.numbering == front-page-numbering {
          counter(page).display()
        } else {
          decorated-number(counter(page).display())
        }
      }
    } else { none },
  )
}
#let section(layout, styles: auto, fontset: auto, stage: auto, doc) = {
  let stage = if stage == auto { info-get().stage } else { stage }
  _layout.section(layout, styles: styles, fontset: fontset, ..header-footer(layout, stage), doc)
}

// 段级不能开关字符网格：西文 run 那两条 show 规则装不装是按文档级的版面定的（字距不为零才装），
// 段里把网格加上或去掉，规则跟不上，西文的半份字距就错——当场拦下，报错说清是哪一处、哪个键、
// 文档现在开着还是关着；换阶段（终稿→报告，预设没有网格）撞上这一条的居多
#let _open(old, layout, where: "new-layout") = {
  let old = if old == none { standalone-layout(none) } else { old }
  if "linebreaks" in layout {
    panic(
      "layout: a section cannot switch the line breaker (linebreaks:); it comes from "
        + "--input linebreaks=… for the whole document, a page may write layout: (linebreaks: none)",
    )
  }
  let merged = _layout.merge-page-setup(old, layout)
  if (merged.docgrid.tracking == 0pt) != (old.docgrid.tracking == 0pt) {
    let keys = ("char-pitch", "chars-per-line", "grid").filter(k => k in layout)
    let was = if old.docgrid.tracking == 0pt { "off" } else {
      "on (char-pitch " + repr(old.docgrid.char-pitch) + ")"
    }
    let now = if merged.docgrid.tracking == 0pt { "off" } else {
      "on (char-pitch " + repr(merged.docgrid.char-pitch) + ")"
    }
    panic(
      where + " at page " + str(here().page()) + ": a section cannot switch the character grid "
        + "(document: " + was + "; this section: " + now + "; given: " + keys.map(k => k + ": " + repr(layout.at(k))).join(", ")
        + "). The grid is a document-wide choice—set it at iota-hit(layout:) or drop it here; "
        + "report stages (proposal, interim) have no character grid, so a per-section char-pitch "
        + "written for the final thesis cannot apply there",
    )
  }
  merged
}
#let _merge-layout(layout, where: "new-layout") = if layout == auto { none } else {
  _open(_layout.page-setup-state.get(), layout, where: where)
}
#let _section(layout, doc) = if layout == none { doc } else {
  _layout.page-setup-state.update(layout)
  section(layout, doc)
}
#let _bottom(s) = { let m = s; while "previous" in m { m = m.previous }; m }
#let _current(s) = { let m = s; m.remove("previous", default: none); m.remove("was", default: none); m }
#let restore-layout(doc) = {
  _layout.page-setup-state.update(s => if s == none or "previous" not in s { s } else {
    _bottom(s) + (previous: s.previous, was: _current(s))
  })
  context {
    let s = _layout.page-setup-state.get()
    if s == none or "was" not in s or s.was == _current(s) { doc } else { section(_current(s), doc) }
  }
}
#let new-layout(layout, doc) = if layout == auto { restore-layout(doc) } else {
  context { let _ = _open(_layout.page-setup-state.get(), layout, where: "new-layout") }
  _layout.page-setup-state.update(s => {
    let base = if s == none { standalone-layout(none) } else { _current(s) }
    _layout.merge-page-setup(base, layout) + (previous: s)
  })
  context section(_current(_layout.page-setup-state.get()), doc)
  _layout.page-setup-state.update(s => s.previous)
}
#let frontmatter(openright: auto, layout: auto, doc) = context {
  let layout = _merge-layout(layout, where: "frontmatter(layout:)")
  frontmatter-openright.update(openright)
  matter-openright.update(resolve-openright(
    "frontmatter", degree-level: info-get().degree-level, local: openright,
  ))
  set page(numbering: front-page-numbering)
  _section(layout, doc)
}
#let cover-exit-odd = state("iota-hit-cover-exit-odd", false)
// 多个前置页会请求同一分页；计数器保证只执行一次。
#let cover-exit-count = counter("iota-hit-cover-exit")

#let cover-exit() = {
  cover-exit-count.step()
  context {
    if cover-exit-count.get().first() == 1 {
      clear-page(to: if cover-exit-odd.get() { "odd" } else { none })
    }
  }
}

#let mainmatter-started = state("iota-hit-mainmatter-started", false)
#let front-numbering-count = counter("iota-hit-front-numbering")

#let front-numbering-enter(openright: auto) = {
  front-numbering-count.step()
  context {
    if mainmatter-started.get() { return }
    if front-numbering-count.get().first() == 1 {
      let odd = if openright != auto { openright } else { matter-openright.get() }
      clear-page(to: if odd { "odd" } else { none })
      counter(page).update(1)
    }
  }
}
#let mainmatter(openright: auto, layout: auto, doc) = context {
  let layout = _merge-layout(layout, where: "mainmatter(layout:)")
  let odd = resolve-openright(
    "mainmatter", degree-level: info-get().degree-level, local: openright,
  )
  matter-openright.update(odd)
  mainmatter-openright.update(odd)
  clear-page(to: if odd { "odd" } else { none })
  mainmatter-started.update(true)
  set page(numbering: main-page-numbering)
  counter(page).update(1)
  reset-abbreviations()
  _section(layout, doc)
}
#let backmatter(openright: auto, layout: auto, doc) = context {
  let layout = _merge-layout(layout, where: "backmatter(layout:)")
  let odd = resolve-openright(
    "backmatter",
    degree-level: info-get().degree-level,
    local: openright,
    matter: mainmatter-openright.get(),
  )
  matter-openright.update(odd)
  clear-page(to: if odd { "odd" } else { none })
  _section(layout, doc)
}

#let appendix(
  appendix-numbering: auto,
  lang: auto,
  overrides: (:),
  doc,
) = context {
  let l = if lang == auto { doc-lang.get() } else { lang }
  let pat = _settings.resolve-appendix-numbering(
    local: appendix-numbering,
    degree-level: info-get().degree-level,
    category: info-get().category,
    lang: l,
  )
  let t = term-table(l, "appendix", overrides: overrides)
  let gap = if l == "en" { " " } else { "" }
  counter(heading).update(0)
  _numbering.appendix-numbering.update(pat)
  let single = query(heading.where(level: 1))
    .filter(h => h.numbering != none and _numbering.appendix-numbering.at(h.location()) != none)
    .len() <= 1
  _numbering.appendix-single.update(single)
  set heading(numbering: (..nums) => {
    let n = nums.pos()
    if n.len() == 1 {
      if single { return t.title }
      return t.title + gap + _numbering.appendix-mark(pat, n.at(0))
    }
    // 节号按学科走，不按章号的写法：人文照正文的「一、」；理工的数字类编号（含只有一章）
    // 名前加「附」——光「1.1」认不出是附录的节还是正文的
    if info-get().category == "hass" {
      return if l == "en" { _numbering.hit-numbering-hass-en(..n) } else { _numbering.hit-numbering-hass(..n) }
    }
    let rest = n.slice(1).map(str).join(".")
    if l != "en" and (single or _numbering.appendix-numeric(pat)) {
      return _numbering.appendix-word(l) + (if single { "" } else { str(n.at(0)) + "." }) + rest
    }
    numbering(pat, n.at(0)) + "." + rest
  })
  doc
}
