#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts as fonts
#import "./kaishu.typ": kaishu-outline, kaishu-outline-chars
#import "../glyphs.typ": family-usable as _family-usable
#import banshi.content: plain-text
#let usable() = {
  let family = fonts.fontset-state.get().families.kaishu
  not fonts.is-hant-only(family) and _family-usable(family)
}
#let cover-kaishu(body) = {
  if usable() { return body }
  let s = plain-text(body)
  if s.clusters().all(c => c in kaishu-outline-chars) {
    return {
      set text(font: fonts.fontset-state.get().families.songti)
      kaishu-outline(body)
    }
  }
  let family = fonts.fontset-state.get().families.kaishu
  if _family-usable(family) { body } else { text(style: "oblique", body) }
}
