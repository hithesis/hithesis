
#import "@local/banshi:0.1.0" as banshi
#import banshi.errors as _errors
#import "../axes.typ": report-stages
#import "./defaults.typ": (
  appendix-numbering-auto, appendix-patterns, caption-bilingual-auto, caption-numbering-by-chapter-auto,
  algorithm-style-auto, raw-style-auto, em-dash-auto, equation-numbering-by-chapter-auto, heading-body-indent-auto, openright-auto,
  report-caption-by-section,
  setting-defaults, setting-homes, theorem-numbering-by-chapter-auto, theorem-body-indent-auto,
)

#let settings-state = state("iota-hit-settings", none)
#let settings-overrides(value) = {
  for (key, v) in value {
    if key not in setting-defaults {
      panic(
        "unknown setting: " + key + " (" + _errors.one-of(
          setting-defaults.keys().map(k => repr(k)),
        ) + ")",
      )
    }
  }
  settings-state.update(old => (
    if old == none { setting-defaults } else { old }
  ) + value)
}
#let setting-of(key) = {
  let v = settings-state.get()
  let all = if v == none { setting-defaults } else { v }
  if key not in all { panic("unknown setting: " + key) }
  all.at(key)
}
#let lookup-key(flat) = if flat in setting-defaults { flat } else { none }
#let not-a-term(key, page: none) = {
  let homes = setting-homes.at(key, default: ())
  key + " is a setting, not a term (" + (
    if page == none {
      "settings are named arguments: iota-hit(" + key + ": ...)"
    } else if page in homes {
      "write " + page + "(" + key + ": ...)"
    } else {
      "the " + repr(page) + " page does not take it; write iota-hit("
        + key + ": ...)"
    }
  ) + ")"
}
#let resolve-caption-numbering-by-chapter(
  local: auto, stage: "final", campus: "harbin", degree-level: "doctor",
) = {
  if local != auto { return local }
  if stage in report-caption-by-section
    .at(campus, default: (:))
    .at(degree-level, default: ()) { return true }
  caption-numbering-by-chapter-auto.at(stage, default: caption-numbering-by-chapter-auto.final)
}
#let caption-by-chapter = state("iota-hit-caption-by-chapter", caption-numbering-by-chapter-auto)
#let equation-by-chapter = state("iota-hit-equation-by-chapter", equation-numbering-by-chapter-auto)

#let resolve-equation-numbering-by-chapter(local: auto, stage: "final") = {
  if local != auto { return local }
  equation-numbering-by-chapter-auto.at(stage, default: equation-numbering-by-chapter-auto.final)
}
#let resolve-theorem-numbering-by-chapter(local: auto, stage: "final") = {
  if local != auto { return local }
  theorem-numbering-by-chapter-auto.at(stage, default: theorem-numbering-by-chapter-auto.final)
}
#let resolve-theorem-body-indent() = {
  let value = setting-of("theorem-body-indent")
  if value == auto { theorem-body-indent-auto } else { value }
}
#let resolve-heading-body-indent(local: auto, lang: "zh", category: "stem", level: 1) = {
  let value = if local != auto { local } else { setting-of("heading-body-indent") }
  if value != auto { return value }
  let by-lang = heading-body-indent-auto.at(lang, default: heading-body-indent-auto.zh)
  let by-category = by-lang.at(category, default: by-lang.stem)
  by-category.at(calc.min(level, by-category.len()) - 1)
}
#let resolve-abbreviation-indexed(entry: auto, local: auto) = {
  if entry != auto { return entry }
  if local != auto { return local }
  let gate = setting-of("abbreviation-indexed")
  if gate != auto { return gate }
  false
}
#let resolve-appendix-numbering(local: auto, degree-level: "doctor", category: "stem", lang: "zh") = {
  let value = if local != auto { local } else { setting-of("appendix-numbering") }
  if value != auto {
    if value not in appendix-patterns {
      panic(_errors.expected-one-of(appendix-patterns, value) + " (appendix-numbering)")
    }
    return value
  }
  let by-lang = appendix-numbering-auto.at(lang, default: appendix-numbering-auto.zh)
  let by-category = by-lang.at(category, default: by-lang.stem)
  by-category.at(degree-level, default: by-category.bachelor)
}
#let resolve-openright(point, degree-level: "doctor", local: auto, matter: auto) = {
  if local != auto { return local }
  if matter != auto { return matter }
  let gate = setting-of("openright")
  if gate != auto { return gate }
  openright-auto.at(degree-level, default: openright-auto.bachelor).at(point)
}
#let resolve-algorithm-style(from: none) = {
  let given = if from == none { setting-of("algorithm-style") } else { from }
  let given = if given == auto { (:) } else { given }
  if type(given) != dictionary {
    panic("algorithm-style: expected auto or dictionary, found " + repr(given))
  }
  let allowed = (
    frame: ("tabular", "ruled", "boxed"),
    keyword-case: ("upper", "lower", "title"),
    indent-guide: ("bar", "hook", none),
  )
  for (k, v) in given {
    if k == "line-numbering" {
      if v != auto and v != none and type(v) not in (str, function) {
        panic("algorithm-style.line-numbering: expected numbering pattern (string), a function, or none, found " + repr(v))
      }
      continue
    }
    if k not in allowed {
      panic("algorithm-style: unknown key " + repr(k) + " (" + _errors.one-of((allowed.keys() + ("line-numbering",)).map(repr)) + ")")
    }
    if v != auto and v not in allowed.at(k) {
      panic("algorithm-style." + k + ": " + _errors.expected-one-of(allowed.at(k), v))
    }
  }
  let out = algorithm-style-auto
  for (k, v) in given { if v != auto { out.insert(k, v) } }
  out
}
#let resolve-raw-style(from: none) = {
  let given = if from == none { setting-of("raw-style") } else { from }
  let given = if given == auto { (:) } else { given }
  if type(given) != dictionary {
    panic("raw-style: expected auto or dictionary, found " + repr(given))
  }
  let frames = ("tabular", "ruled", "boxed", none)
  for (k, v) in given {
    if k == "line-numbering" {
      if v != auto and v != none and type(v) not in (str, function) {
        panic("raw-style.line-numbering: expected numbering pattern (string), a function, or none, found " + repr(v))
      }
    } else if k == "frame" {
      if v != auto and v not in frames {
        panic("raw-style.frame: " + _errors.expected-one-of(frames, v))
      }
    } else {
      panic("raw-style: unknown key " + repr(k) + " (" + _errors.one-of(("frame", "line-numbering").map(repr)) + ")")
    }
  }
  let out = raw-style-auto
  for (k, v) in given { if v != auto { out.insert(k, v) } }
  out
}
#let resolve-em-dash(local: auto, campus: "harbin", degree-level: "doctor", stage: "final") = {
  if local != auto {
    if local not in ("cjk", "latin") {
      panic(_errors.expected-one-of(("cjk", "latin"), local) + " (em-dash)")
    }
    return local
  }
  if stage in em-dash-auto.at(campus, default: (:)).at(degree-level, default: ()) { "latin" }
  else { "cjk" }
}
#let resolve-caption-bilingual(degree-level: "doctor", stage: "final", local: auto) = {
  if local != auto { return local }
  let gate = setting-of("caption-bilingual")
  if gate != auto { return gate }
  let by-stage = caption-bilingual-auto.at(stage, default: caption-bilingual-auto.final)
  by-stage.at(degree-level, default: by-stage.bachelor)
}
#let resolve-subcaption-bilingual(local: auto) = {
  if local != auto { return local }
  let gate = setting-of("subcaption-bilingual")
  if gate != auto { return gate }
  false
}
#let resolve-subcaption-gap(local: auto) = {
  let value = if local != auto { local } else { setting-of("subcaption-gap") }
  if value == auto or value == none { return none }
  if type(value) == length { return v(value, weak: false) }
  value
}

