#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts as fonts
#import banshi.content: plain-text
#let _bold-coef = 1 / 35
#let _is-bold(wgt) = {
  if type(wgt) == int { wgt >= 600 } else { wgt in ("semibold", "bold", "extrabold", "black") }
}
#let _render-run(font, s, bold) = context {
  let em = text.size
  let upm = font.upm
  let h = (font.asc - font.desc) / upm * em
  let tr = text.tracking
  let tracking = tr.abs + tr.em * em
  let chs = s.clusters()
  let total = chs.map(c => font.glyphs.at(c).adv / upm * em + tracking).sum()
  let f = text.fill
  let hex = if type(f) == color { f.to-hex() } else { "#000000" }
  let stroke-attrs = if bold or _is-bold(text.weight) {
    (
      " stroke=\"" + hex + "\" stroke-width=\"" + str(upm * _bold-coef)
        + "\" stroke-linejoin=\"miter\" stroke-miterlimit=\"10\""
    )
  } else { "" }
// 透明文本负责基线度量，也让轮廓字能在 PDF 中检索。
  let hidden = text(fill: rgb(0, 0, 0, 0), s)
  let nat = measure(hidden).width
  if nat > 0pt {
    hidden = scale(x: 100% * (total / nat), origin: left, reflow: false, box(width: nat, hidden))
  }
  let top-edge = text.top-edge
  let glyph-top = if type(top-edge) == length {
    top-edge.abs + top-edge.em * em - font.asc / upm * em
  } else { 0pt }
  let glyphs = box(width: total, height: h, {
    let x = 0pt
    for c in chs {
      let g = font.glyphs.at(c)
      let w = g.adv / upm * em
      if g.d != "" {
        let svg = (
          "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 "
            + str(g.adv) + " " + str(font.asc - font.desc)
            + "\"><g transform=\"translate(0," + str(font.asc)
            + ") scale(1,-1)\"><path fill=\"" + hex + "\"" + stroke-attrs
            + " d=\"" + g.d + "\"/></g></svg>"
        )
        place(top + left, dx: x, image(bytes(svg), width: w, height: h))
      }
      x += w + tracking
    }
  })
  box(width: total, {
    place(top + left, dy: glyph-top, glyphs)
    hidden
  })
}
#let _segments(it, bold) = {
  if type(it) == str {
    if it == "" { () } else { ((text: it, bold: bold),) }
  } else if type(it) == content {
    if it.func() == strong { _segments(it.body, true) }
    else if it.has("text") { ((text: it.text, bold: bold),) }
    else if it.has("children") { it.children.map(c => _segments(c, bold)).sum(default: ()) }
    else if it.has("body") { _segments(it.body, bold) }
    else if it == [ ] { ((text: " ", bold: bold),) }
    else { () }
  } else { ((text: str(it), bold: bold),) }
}
#let outline-text(font, body) = {
  let merged = ()
  for s in _segments(body, false) {
    if merged.len() > 0 and merged.last().bold == s.bold {
      let l = merged.pop()
      merged.push((text: l.text + s.text, bold: s.bold))
    } else { merged.push(s) }
  }
  for seg in merged {
    let run = ""
    for ch in seg.text.clusters() {
      if ch in font.glyphs { run += ch }
      else if ch.trim() == "" {
        if run != "" { _render-run(font, run, seg.bold); run = "" }
        ch
      } else {
        panic(font.name + "-outline: 未收录字符「" + ch + "」，已收录: " + font.glyphs.keys().join())
      }
    }
    if run != "" { _render-run(font, run, seg.bold) }
  }
}
#let covered(font, s) = s.clusters().all(c => c in font.glyphs or c.trim() == "")
#let family-usable(family) = {
  measure(text(font: family, fallback: false, size: 100pt)[一二]).width > 0pt
}
#let outlined(role, font, body) = {
  if family-usable(fonts.fontset-state.get().families.at(role)) { return body }
  if covered(font, plain-text(body)) { outline-text(font, body) } else { body }
}
