#import "@local/banshi:0.1.0" as banshi
#import "./presets.typ": default-styles, toc-line-spacing-auto, variant-styles
#import "../terms/lookup.typ": term-for
#import banshi.styles as _state
#let current-styles() = _state.current-styles(default: default-styles)
#let variant-style(name, lang: "zh", ..variant) = term-for(
  variant-styles.base + variant-styles.at(lang), name, variant.named(),
)
#let resolve-toc-line-spacing(
  local: auto, degree-level: "doctor", category: "stem",
  stage: "final", lang: "zh",
) = {
  if local != auto { return local }
  let v = variant-style("toc-line-spacing", lang: lang, degree-level: degree-level, stage: stage)
  if v != auto { return v }
  let by-degree = toc-line-spacing-auto.at(category, default: toc-line-spacing-auto.stem)
  by-degree.at(degree-level, default: by-degree.bachelor)
}
