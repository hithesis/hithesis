#let gb7714-defaults = (
  version: 2015,
  bib-numbering-style: "fullwidth-bracket",
  mark-medium-bracket-style: "full",
  bib-punct-style: "full",
  back-ref: true,
  hyperlink: true,
  hyperlink-title: true,
  correct-punct: true,
  hyphenate: true,
  note-numbering-style: (circled: "quan"),
  date-fallback: "urldate",
  number-gutter: 0pt,
)
#let gb7714-for(category) = if category == "hass" {
  gb7714-defaults + (
    bib-numbering-style: "bracket",
    mark-medium-bracket-style: "half",
    number-gutter: 0.25em,
  )
} else {
  gb7714-defaults
}
