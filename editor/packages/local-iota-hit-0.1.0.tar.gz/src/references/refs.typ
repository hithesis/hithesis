
#import "@local/banshi:0.1.0" as banshi
#import banshi.content: plain-text
#import banshi.runs: has-cj
#import "../heading/numbering.typ" as _numbering
#import "../terms/lang.typ": doc-lang
#import "../terms/lookup.typ": term-table, term-for, term-apply, info-variant
#import "../info.typ": info-get
#import "../axes.typ": campus-for
#import "../settings/resolve.typ": setting-of
#import "../figure/kinds.typ" as kinds
#let number(el, fig-by-chapter, eq-by-chapter, running: true) = {
  let loc = el.location()
  let (cnt, chap, open, close) = if el.func() == figure {
    (counter(figure.where(kind: el.kind)), fig-by-chapter, "", "")
  } else if el.func() == math.equation {
    (
      counter(math.equation),
      eq-by-chapter,
      ..(if (running and doc-lang.get() == "zh") or setting-of("equation-numbering-fullwidth") == true {
        ("（", "）")
      } else { ("(", ")") }),
    )
  } else {
    return none
  }
  let n = cnt.at(loc)
  if chap {
    _numbering.chapter-numbered(
      loc, n, open: open, close: close,
      prefix: if el.func() == math.equation {
        _numbering.appendix-prefix(loc, doc-lang.get(), by-chapter: chap)
      },
    )
  } else {
    numbering(open + "1" + close, ..n)
  }
}
#let MARK = "\u{E7A1}\u{E3D2}\u{EB09}"
#let NAME-SEP = "\u{E4B6}\u{EA25}\u{ED73}"

#let SEP-RE = "[ \u{00A0}\t]*[、，,；;]?[ \u{00A0}\t]*"
#let space-func = [ ].func()

#let text-only(c) = {
  if type(c) == str { return true }
  if type(c) != content { return false }
  if c.func() == text or c.func() == space-func { return true }
  if c.has("children") { return c.children.all(text-only) }
  false
}
#let word(lang, key) = term-for(term-table(lang, "caption"), key, info-variant())
#let typst-supplements = (
  image: (zh: "图", en: "Figure"), table: (zh: "表", en: "Table"), raw: (zh: "代码", en: "Listing"),
)

#let given-supplement(fields, kind, lang) = {
  let k = kinds.kinds.find(k => k.kind == kind)
  if k == none { return auto }
  let v = fields.at("supplement", default: auto)
  if v == auto { return auto }
  if v == none { return [] }
  if k.term not in typst-supplements { return if plain-text(v) == plain-text(word(lang, k.term)) { auto } else { v } }
  let dflt = typst-supplements.at(k.term).at(lang, default: typst-supplements.at(k.term).zh)
  if plain-text(v) == dflt { auto } else { v }
}
#let continued-mark(lang, name) = {
  let i = info-get()
  term-apply(
    term-table(lang, "caption"), "continued",
    (degree-level: i.degree-level, campus: campus-for(i.campus, i.degree-level)),
    name,
  )
}
#let supplement(el, by-chapter) = {
  let lang = doc-lang.get()
  let prefix = if el.func() == math.equation { none } else {
    _numbering.appendix-prefix(el.location(), lang, by-chapter: by-chapter)
  }
  if el.func() == math.equation { return word(lang, "equation") }
  let k = kinds.kinds.find(k => k.kind == el.kind)
  let given = given-supplement(el.fields(), el.kind, lang)
  prefix + (if k == none { el.supplement } else if given != auto { given } else { word(lang, k.term) })
}
#let gap(sup, num) = {
  let n = plain-text(num)
  if n.starts-with("（") { [] }
  else if not has-cj(plain-text(sup)) or n.starts-with("(") { sym.space.nobreak }
  else { [] }
}
#let continued-gap(mark) = if plain-text(mark).starts-with("（") { [] } else {
  sym.space.nobreak
}
#let single(it, fig-by-chapter, eq-by-chapter) = {
  let el = kinds.resolve(it.element)
  if el == none { return it }
  if number(el, fig-by-chapter, eq-by-chapter) == none { return it }
  let given = it.fields().at("supplement", default: auto)
  if given == none { return link(el.location(), number(el, fig-by-chapter, eq-by-chapter)) }
  if given != auto and not text-only(given) {
    let num = number(el, fig-by-chapter, eq-by-chapter)
    return link(el.location(), given + gap(given, num) + num)
  }
  MARK + str(it.target) + (if given == auto { "" } else { NAME-SEP + plain-text(given) }) + MARK
}
#let class(el) = if el.func() == math.equation { "equation" } else {
  repr(el.at("kind", default: none))
}

#let group(text, fig-by-chapter, eq-by-chapter) = {
  let parts = text.split(MARK)
  let loads = ()
  let seps = ()
  for (i, p) in parts.enumerate() {
    if calc.odd(i) { loads.push(p) } else if i > 0 and i < parts.len() - 1 { seps.push(p) }
  }
  let out = ()
  let cls = none          // 当前这一组的类
  let name = none         // 当前这一组的名（纯文本，用来判后面有没有换名）
  let custom = false      // 本组的名是不是引用上显式写的（是就管住整组）
  for (i, load) in loads.enumerate() {
    let bits = load.split(NAME-SEP)
    let key = bits.first()
    let given = if bits.len() > 1 { bits.at(1) } else { none }
    let found = query(label(key))
    if found.len() == 0 { return text }
    let el = kinds.resolve(found.first())
    let num = number(el, fig-by-chapter, eq-by-chapter)
    if num == none { return text }
    if i > 0 { out.push(seps.at(i - 1)) }
    let k = class(el)
    let own = supplement(el, fig-by-chapter)
    if k != cls or (given != none and given != name) or (given == none and not custom and plain-text(own) != name) {
      cls = k
      custom = given != none
      let sup = if given != none { given } else { own }
      name = plain-text(sup)
      out.push(link(el.location(), if sup == none { num } else {
        sup + gap(sup, num) + num
      }))
    } else {
      out.push(link(el.location(), num))
    }
  }
  out.join()
}
