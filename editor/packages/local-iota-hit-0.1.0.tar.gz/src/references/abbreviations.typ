#import "@local/banshi:0.1.0" as banshi
#import "@preview/glossy:0.9.2" as _glossy
#import "../terms/lang.typ": effective-lang
#import banshi.errors as _errors
#import banshi.runs: has-han
#import "../settings/resolve.typ" as _settings
#import "./index.typ" as _index
#let entries = state("iota-hit-abbreviations", (:))
#let config = state(
  "iota-hit-abbreviations-config",
  (fullwidth: auto, links: auto, indexed: auto, printed: false),
)
#let _fields = ("long", "long-en", "short", "plural", "long-plural", "indexed")

#let _bad(key, what) = panic("abbreviations: entry " + repr(key) + ": " + what)
#let normalize(value) = {
  if type(value) != dictionary {
    panic("abbreviations: expected dictionary, found " + str(type(value)))
  }
  let out = (:)
  for (key, given) in value {
    if key.contains(":") {
      _bad(key, "key must not contain \":\" (that is the modifier separator, as in @SCNA:pl)")
    }
    let e = if type(given) == str {
      if has-han(given) { (long: given) } else { (long-en: given) }
    } else if type(given) == dictionary {
      given
    } else {
      _bad(key, "expected string or dictionary, found " + str(type(given)))
    }
    for (field, v) in e {
      if field not in _fields {
        _bad(key, "unknown field " + repr(field) + "; expected " + _errors.one-of(_fields.map(repr)))
      }
      if field != "indexed" and v != auto and type(v) != str {
        _bad(key, "field " + repr(field) + ": expected string or auto, found " + str(type(v)))
      }
    }
    let pick(field) = {
      let v = e.at(field, default: auto)
      if v == auto { none } else { v }
    }
    let long = pick("long")
    let long-en = pick("long-en")
    if long == none and long-en == none {
      _bad(key, "needs long or long-en")
    }
    let short = if pick("short") == none { key } else { pick("short") }
    let plural = if pick("plural") == none { short + "s" } else { pick("plural") }
    let indexed = e.at("indexed", default: auto)
    if indexed not in (auto, true, false) {
      _bad(key, "field \"indexed\": expected boolean or auto, found " + repr(indexed))
    }
    out.insert(key, (
      short: short, plural: plural, long: long, long-en: long-en,
      long-plural: e.at("long-plural", default: auto),
      indexed: indexed,
    ))
  }
  out
}

#let _tristate(name, value) = {
  if value not in (auto, true, false) {
    panic("abbreviations: " + name + ": expected boolean or auto, found " + repr(value))
  }
}
#let configure(fullwidth: auto, links: auto, indexed: auto) = {
  _tristate("fullwidth", fullwidth)
  _tristate("links", links)
  _tristate("indexed", indexed)
  config.update(c => (
    fullwidth: if fullwidth == auto { c.fullwidth } else { fullwidth },
    links: if links == auto { c.links } else { links },
    indexed: if indexed == auto { c.at("indexed", default: auto) } else { indexed },
    printed: c.at("printed", default: false),
  ))
}
#let declare(value, fullwidth: auto, links: auto, indexed: auto, printed: false) = {
  _tristate("fullwidth", fullwidth)
  _tristate("links", links)
  _tristate("indexed", indexed)
  let pieces = if type(value) == array { value } else { (value,) }
  let normalized = (:)
  let seen = (:)
  for (i, piece) in pieces.enumerate() {
    for (k, e) in normalize(piece) {
      if k in seen {
        panic(
          "abbreviations: " + repr(k) + " is declared twice (in piece "
            + str(seen.at(k) + 1) + " and piece " + str(i + 1) + " of the array)",
        )
      }
      seen.insert(k, i)
      normalized.insert(k, e)
    }
  }
  entries.update(e => e + normalized)
  config.update(c => (
    fullwidth: if fullwidth == auto { c.fullwidth } else { fullwidth },
    links: if links == auto { c.links } else { links },
    indexed: if indexed == auto { c.at("indexed", default: auto) } else { indexed },
    printed: c.at("printed", default: false) or printed,
  ))
}
#let table-label = label("iota-hit-abbreviations")
#let mark-printed() = config.update(c => c + (printed: true))
#let anchor() = [#metadata(none)#table-label]
#let _sep = "\u{1}"
#let _machine(mode, short, long) = mode + _sep + long + _sep + short
#let _long-plural(e, picked) = {
  if e.long-plural != auto { e.long-plural } else if has-han(picked) { picked } else { picked + "s" }
}
#let compose(mode, e, short, plural, lang, fullwidth) = {
  if mode == "short" { return short }
  let (open, close, comma) = if fullwidth { ("（", "）", "，") } else { (" (", ")", ", ") }
  if lang == "en" {
    let picked = if e.long-en != none { e.long-en } else { e.long }
    let full = if plural { _long-plural(e, picked) } else { picked }
    if mode == "long" { return full }
    return full + open + short + close
  }
  if mode == "long" {
    return if e.long != none { e.long } else if plural { _long-plural(e, e.long-en) } else { e.long-en }
  }
  if e.long != none and e.long-en != none {
    e.long + open + e.long-en + comma + short + close
  } else if e.long != none {
    e.long + open + short + close
  } else {
    short + open + e.long-en + close
  }
}
#let render(body) = context {
  if type(body) != str { return body }
  let parts = body.split(_sep)
  if parts.len() != 3 { return body }
  let (mode, key, short) = parts
  let cap = mode != lower(mode)
  let e = entries.final().at(key)
  let lang = effective-lang()
  let c = config.final()
  let fullwidth = if c.fullwidth == auto { lang == "zh" } else { c.fullwidth }
  let out = compose(lower(mode), e, short, short != e.short, lang, fullwidth)
  if cap { out = upper(out.first()) + out.slice(out.first().len()) }
  let marks = if _settings.resolve-abbreviation-indexed(
    entry: e.at("indexed", default: auto), local: c.at("indexed", default: auto),
  ) {
    (if e.long != none { _index.mark(e.long) } else { none },
     if e.long-en != none { _index.mark(e.long-en) } else { none }).join()
  }
  let links = if c.links == auto { true } else { c.links }
  (if links and c.at("printed", default: false) { link(table-label, out) } else { out }) + marks
}
#let rules(body) = context {
  let all = entries.final()
  if all.len() == 0 { return body }
  let g = (:)
  for (key, e) in all {
    g.insert(key, (short: e.short, plural: e.plural, long: key, longplural: key))
  }
  show: _glossy.init-glossary.with(
    g, format-term: _machine, show-term: render, term-links: false,
  )
  body
}
#let reset() = context {
  for key in entries.final().keys() { ref(label(key + ":reset")) }
}
