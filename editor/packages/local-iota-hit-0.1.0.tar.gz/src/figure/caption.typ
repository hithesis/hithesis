
#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing
#import banshi.paragraph as hyphenate
#import banshi.layout: resolve-chars
#import banshi.content: label-of, plain-text, trim-tail, metadata-of
#import banshi.runs: has-cjk, has-cj
#import banshi.styles as style-rules
#import banshi.layout as _layout
#import "../heading/numbering.typ" as _numbering
#import "../terms/lang.typ": find-en, title-of, doc-lang
#import "./kinds.typ": find-algorithm, in-listing
#import "../case.typ": english-title
#import "../info.typ": info-get
#import "../settings/resolve.typ": resolve-caption-bilingual, resolve-subcaption-bilingual, resolve-subcaption-gap, resolve-algorithm-style, resolve-raw-style, setting-of
#import "../settings/defaults.typ": caption-separator-auto
#import "../styles/presets.typ": default-styles
#import "./kinds.typ" as kinds
#import "./continued.typ": find-continued, continued-source, continued-step, continued-head
#import "./kinds/image.typ": find-subs, find-subs-gap, subs-refs, subs-rows, subfigure-kind, subs-offset, sub-caption, subs-line
#import "../references/refs.typ" as refs
#import "./note.typ" as _note
#import banshi.styles as _table

#let _separator(layout) = {
  if figure.caption.separator != auto { return figure.caption.separator }
  h(resolve-chars(
    caption-separator-auto.at(doc-lang.get(), default: caption-separator-auto.zh),
    layout,
  ))
}
#let _caption-line(it, lang, term, layout, style, continued: false, by-chapter: true, first: true, source: none, width: auto) = {
  let supplement = (
    _numbering.appendix-prefix(here(), lang, by-chapter: by-chapter)
  ) + (if type(term) == str { refs.word(lang, term) } else { term })
  let numbered = it.numbering != none
  let num = if not numbered {
    none
  } else if continued {
    context {
      let sel = figure.where(kind: it.kind)
      if source == none { it.counter.update(v => v - 1) }
      let src = if source != none { source } else { continued-head(sel, find-continued(it.body)) }
      if src != none {
        let seq = counter(sel).at(src.location())
        if by-chapter {
          _numbering.chapter-numbered(src.location(), seq)
        } else {
          numbering("1", ..seq)
        }
      }
    }
  } else {
    std.numbering(it.numbering, ..it.counter.get())
  }
  let body = if lang == "en" { english-title(title-of(it.body, "en"), slot: "caption") } else { title-of(it.body, "zh") }
  let latin = lang == "en" and not has-cjk(plain-text(body))
  let ruled = (
    (it.kind == kinds.algorithm-kind and resolve-algorithm-style().frame == "ruled")
      or (it.kind == raw and resolve-raw-style().frame == "ruled")
  )
  let ts = _table.table-style()
  let st = if ruled {
    _table.cell-style(ts, style.size)
  } else if not latin {
    style
  } else {
    style + (snap-to-grid: false)
  }
  block(above: 0pt, below: 0pt, width: 100%, sticky: figure.caption.position == top,
    inset: (bottom: if ruled { ts.stroke.header / 2 } else { 0pt }), {
    show: style-rules.rules.with(st, layout: layout, set-font: true, latin: latin and not ruled)
    show: hyphenate.hyphenate-rules
    let ruled-algorithm = ruled
    set align(if continued and (term == "table" or figure.caption.position == top) { right } else if ruled-algorithm { left } else { center })
    show par: p => p
    let head = if numbered {
      supplement + (if lang == "en" { " " }) + num + _separator(layout)
    } else { [] }
    if ruled-algorithm {
      if first {
        block(width: 100%, above: 0pt, below: 0pt, sticky: true, stroke: (top: ts.stroke.top), height: ts.stroke.top / 2)
      }
      h(ts.inset.x)
    }
    if continued {
      let mark = refs.continued-mark(lang, if type(term) == str { refs.word(lang, term) } else { term })
      let line = {
        if numbered { supplement + (if lang == "en" { " " }) + num + refs.continued-gap(mark) }
        mark
        sym.zws
      }
      if width == auto { line } else {
        context {
          if measure(line).width >= width { align(center, line) } else {
            align(right, line + h((layout.text-width - width) / 2))
          }
        }
      }
    } else {
      context {
        let whole = head + body
        if measure(whole).width <= layout.text-width {
          whole
        } else {
          grid(columns: (auto, 1fr), align: left, head, par(justify: true, body))
        }
      }
    }
  })
}

#let _size-sentinel = 0.31415pt
#let _position-mark(pos) = metadata((iota-caption-position: pos))
#let width-mark(body, layout) = metadata((
  iota-body-width: calc.min(measure(body, width: layout.text-width).width, layout.text-width),
))
#let _position-of(f) = {
  let m = query(selector(metadata).after(f.location())).find(m => (
    type(m.value) == dictionary and "iota-caption-position" in m.value
  ))
  if m == none { none } else { m.value.iota-caption-position }
}
#let caption-lines(it) = {
  let lang = doc-lang.get()
  let given = refs.given-supplement(it.fields(), it.kind, lang)
  let k = kinds.kinds.find(k => k.kind == it.kind)
  let term = if given != auto { given } else if k != none { k.term } else { it.supplement }
  let supplement(l) = _numbering.appendix-prefix(here(), l, by-chapter: it.numbering != none) + (
    if type(term) == str { refs.word(l, term) } else { term }
  )
  let en-body = english-title(title-of(it.body, "en"), slot: "caption")
  if lang == "en" {
    ((supplement: supplement("en"), body: en-body, latin: not has-cjk(plain-text(en-body))),)
  } else {
    let zh = ((supplement: supplement("zh"), body: title-of(it.body, "zh")),)
    let bilingual = resolve-caption-bilingual(degree-level: info-get().degree-level, stage: info-get().stage)
    if bilingual and find-en(it.body) != none {
      zh + ((supplement: supplement("en"), body: en-body, latin: not has-cjk(plain-text(en-body))),)
    } else { zh }
  }
}
#let caption-relation(by-chapter: true) = (
  kinds: (image: (position: bottom), table: (position: top)),
  numbering: (
    format: "1",
    include-chapter-number: by-chapter,
    chapter-starts-with-style: "chapter",
    separator: "-",
    chapter-number: (loc, n) => _numbering.chapter-mark(loc),
  ),
  lines: caption-lines,
)

#let caption(it, layout, style, by-chapter, source: none, pieces: none) = {
  _position-mark(figure.caption.position)
  let kind = it.kind
  let lang = doc-lang.get()
  let given = refs.given-supplement(it.fields(), kind, lang)
  let k = kinds.kinds.find(k => k.kind == kind)
  let term = if given != auto { given } else if k != none { k.term } else { it.supplement }
  let manual = find-continued(it.body) != none
  let continued = manual or source != none
  if continued and kind == table {
  } else if continued {
    let width = if figure.caption.position != top { auto } else {
      let m = query(selector(metadata).before(here())).rev().find(m => (
        type(m.value) == dictionary and "iota-body-width" in m.value
      ))
      if m == none { auto } else { m.value.iota-body-width }
    }
    _caption-line(it, lang, term, layout, style, continued: true, by-chapter: by-chapter, source: source, width: width)
  } else if (
    (kind == kinds.algorithm-kind and resolve-algorithm-style().frame == "ruled")
      or (kind == raw and resolve-raw-style().frame == "ruled")
  ) {
    if lang == "en" {
      _caption-line(it, "en", term, layout, style)
    } else {
      _caption-line(it, "zh", term, layout, style)
      let bilingual = resolve-caption-bilingual(degree-level: info-get().degree-level, stage: info-get().stage)
      if bilingual and find-en(it.body) != none { _caption-line(it, "en", term, layout, style, first: false) }
    }
  } else {
    banshi.styles.caption-body(it)
  }
  let subs = find-subs(it.body)
  if subs != none and not (continued and kind == table) {
    let start = if not manual { 0 } else {
      let sel = figure.where(kind: image)
      let src = continued-source(sel, find-continued(it.body))
      if src == none { 0 } else { subs-offset(sel, src) }
    }
    let (subs, start) = if pieces == none { (subs, start) } else {
      (subs.slice(pieces.from, pieces.to), start + pieces.from)
    }
    if subs.len() > 0 {
      resolve-subcaption-gap(local: find-subs-gap(it.body))
      subs-line(subs, layout, style, start: start)
    }
  }
}

#let caption-rules(
  body-metrics: none,
  style: default-styles.figure.caption,
  note-style: default-styles.figure.caption,
  by-chapter: true,
  equation-by-chapter: true,
  header-rows: 1,
  doc,
) = {
  // 图注、表注排在写的位置，宽按图表自己的宽（量正身时记号还没排出来，量不到它）
  show figure: it => context {
    if not _note.has-note(it.body) { return it }
    let layout = _layout.current-page-setup()
    let widths = _note.widths-of(it.body, layout)
    _note.reset()
    show metadata: m => if _note.is-note(m) { _note.note-block(m.value.at(_note.mark), widths, note-style, layout) } else { m }
    // 注紧贴表（hithesis 是 \nointerlineskip）：figure 的段后是 set block(below:) 给的，正身里的表也
    // 会继承它，只把表自己的那份清零；图是段里的行内内容，段距本来就是 0
    show table: set block(below: 0pt)
    set par(spacing: 0pt)
    it
  }
  show figure: it => context {
    let cap = it.at("caption", default: none)
    let mark = if cap == none or it.kind in (image, table, kinds.algorithm-kind) { none } else if (
      it.kind == raw and resolve-raw-style().frame != none
    ) { none } else {
      find-continued(cap.body)
    }
    let inherited = if mark == none or "position" in cap.fields() { none } else {
      let src = continued-source(figure.where(kind: it.kind), mark)
      if src == none { none } else { _position-of(src) }
    }
    let width = if it.kind in (image, table, kinds.algorithm-kind) { none } else {
      width-mark(it.body, _layout.current-page-setup())
    }
    if inherited == none { width + it } else {
      set figure.caption(position: inherited)
      width + it
    }
  }
  show figure: it => {
    if it.kind != image or find-algorithm(it.body) == none { return it }
    context {
      let st = resolve-algorithm-style()
      set figure.caption(position: if st.frame == "boxed" { bottom } else { top })
      let f = it.fields()
      let given = refs.given-supplement(f, image, doc-lang.get())
      counter(figure.where(kind: image)).update(v => v - 1)
      let rebuilt = figure(
        it.body,
        kind: kinds.algorithm-kind,
        caption: if f.at("caption", default: none) == none { none } else { it.caption.body },
        placement: f.at("placement", default: none),
        outlined: f.at("outlined", default: true),
        supplement: if given != auto { given } else { refs.word(doc-lang.get(), "algorithm") },
      )
      rebuilt
    }
  }
  show figure.where(kind: kinds.algorithm-kind): set block(breakable: true)
  show figure.where(kind: raw): set block(breakable: true)
  show figure.where(kind: raw): it => context {
    let frame = resolve-raw-style().frame
    in-listing.update(true)
    if frame == none { it } else {
      set figure.caption(position: if frame == "boxed" { bottom } else { top })
      it
    }
    in-listing.update(false)
  }
  show figure.caption: set text(size: _size-sentinel)
  show figure.where(kind: table): set block(breakable: true)
  show figure: it => context {
    let g = _layout.current-page-setup().docgrid
    if not g.grid or g.line-pitch == 0pt or it.kind == table { return it }
    show image: img => context {
      if subs-rows.get() { return img }
      let h = measure(img).height
      let rows = calc.max(1, calc.ceil(h / g.line-pitch))
      block(height: rows * g.line-pitch, align(horizon, img))
    }
    it
  }
  show figure: it => context {
    if by-chapter and figure.numbering != none and type(figure.numbering) != function and it.kind != subfigure-kind {
      panic(
        "figure numbering has no effect (the template numbers figures by "
          + "chapter; write iota-hit(caption-numbering-by-chapter: false) "
          + "for continuous numbering)",
      )
    }
    let cap = it.at("caption", default: none)
    let continued = cap != none and find-continued(cap.body) != none
    if it.kind != subfigure-kind and not continued {
      counter(figure.where(kind: subfigure-kind)).update(0)
    }
    it
  }
  show figure.where(kind: subfigure-kind): set figure(
    numbering: (..n) => context numbering(setting-of("subcaption-numbering"), ..n.pos()),
  )
  show figure.where(kind: subfigure-kind): set block(above: 0pt, below: 0pt)
  show ref: it => context {
    let found = query(it.target)
    let native = if found.len() == 0 { none } else {
      let f = found.first()
      if f.func() == figure and f.at("kind", default: none) == subfigure-kind {
        (
          loc: f.location(),
          index: counter(figure.where(kind: subfigure-kind)).at(f.location()).first(),
        )
      }
    }
    let e = if native != none { native } else {
      subs-refs.final().at(str(it.target), default: none)
    }
    if e == none {
      refs.single(it, by-chapter, equation-by-chapter)
    } else {
      let n = counter(figure.where(kind: image)).at(e.loc)
      let parent = (
        _numbering.appendix-prefix(e.loc, doc-lang.get(), by-chapter: by-chapter)
      ) + refs.word(doc-lang.get(), "image") + (
        if not by-chapter {
          numbering("1", ..n)
        } else {
          _numbering.chapter-numbered(e.loc, n)
        }
      )
      let num = numbering(setting-of("subcaption-numbering"), e.index)
      let gap = if has-cj(plain-text(num)) { [] } else { sym.space.nobreak }
      link(e.loc, parent + gap + num)
    }
  }
  show regex(
    refs.MARK + "(?s:.+?)" + refs.MARK + "(?:" + refs.SEP-RE + refs.MARK + "(?s:.+?)" + refs.MARK + ")*",
  ): m => context refs.group(m.text, by-chapter, equation-by-chapter)
  show figure.caption: it => context {
    if text.size != _size-sentinel {
      panic(
        "figure captions ignore `show figure.caption: set text(...)` (the "
          + "template lays the caption out itself; write "
          + "iota-hit(styles: (figure: (caption: (size: ...)))) to change it)",
      )
    }
    let want = if it.kind == table { top } else { bottom }
    if it.kind in (table, image) and it.position != want {
      panic(
        "figure.caption position is fixed by the guidelines (table captions go "
          + "above the table, figure captions below the figure); remove the "
          + "set figure.caption(position: ...)",
      )
    }
    let layout = _layout.current-page-setup()
    set text(size: body-metrics.size)
    if it.kind == subfigure-kind {
      sub-caption(it, layout, style)
    } else {
      caption(it, layout, style, by-chapter)
    }
  }

  doc
}
