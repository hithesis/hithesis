#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing, indent
#import "@preview/lovelace:0.3.1": pseudocode, pseudocode-list, indent as _indent
#import "@preview/algorithmic:1.0.7" as _algorithmic
#import "../../vendor/quan/lib.typ": quan as _quan
#import "../kinds.typ": algorithm-mark, find-algorithm
#import "../../settings/resolve.typ" as _settings
#import "../../terms/lookup.typ": term-table

#import banshi.layout as _layout
#import banshi.styles as style-rules
#import banshi.content: plain-text
#import "../../terms/lang.typ": doc-lang
#import "../../heading/numbering.typ" as _numbering
#import banshi.styles as _cells
#import "../../references/refs.typ" as refs
#import "../continued.typ": continued-step, continued-head, find-continued
#let _guide(kind) = if kind == none { none } else { _cells.table-style().stroke.header / 2 + black }
#let _INDENT = 2em
#let _NUMBER-COLUMN = 1.5em
#let _NUMBER-GAP = 0.5em
#let _table(lang) = term-table(lang, "algorithm")
#let _render(word, case) = {
  if case == "upper" { upper(word) }
  else if case == "lower" { lower(word) }
  else if case == "title" {
    let t = plain-text(word)
    if t == "" { word } else { upper(t.slice(0, 1)) + t.slice(1) }
  }
  else { panic("algorithm-style.keyword-case: expected \"upper\", \"lower\" or \"title\", found " + repr(case)) }
}
#let _keyword-rules(lang, case, body) = {
  let table = _table(lang)
  let pattern = "(?i)\\b(" + table.keys().join("|") + ")\\b"
  show regex(pattern): it => {
    let key = lower(it.text)
    if key in table { strong(_render(table.at(key), case)) } else { it }
  }
  body
}
#let _line-offset() = {
  let sel = figure.where(kind: "algorithm")
  let mine = query(sel.before(here(), inclusive: true))
  if mine.len() == 0 { return 0 }
  let cur = mine.last()
  let n = 0
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    cur = continued-step(sel, cur)
    if cur == none { break }
    let m = find-algorithm(cur.body)
    if m != none { n += m.lines }
  }
  n
}
#let _tabular-title(head, s, x, width, gutter) = context {
  let sel = figure.where(kind: "algorithm")
  let mine = query(sel.before(here(), inclusive: true))
  let f = if mine.len() == 0 { none } else { mine.last() }
  let first = f == none or f.location().page() == here().page()
  let dx = -(gutter + x)
  let rule(where, stroke) = place(where + left, dx: dx, line(length: width, stroke: stroke))
  block(width: 100%, above: 0pt, below: 0pt, {
    if first {
      rule(top, s.top)
      if head != none {
        block(width: 100%, above: 0pt, below: 0pt, inset: (bottom: s.header / 2), head)
        rule(bottom, s.header)
      }
    } else {
      let lang = doc-lang.get()
      let name = refs.word(lang, "algorithm")
      let mark = refs.continued-mark(lang, name)
      let chain = find-continued(f.caption.body)
      let src = if chain == none { f } else { continued-head(sel, chain) }
      let src = if src == none { f } else { src }
      let num = numbering(f.numbering, ..counter(sel).at(src.location()))
      let name = _numbering.appendix-prefix(src.location(), lang, by-chapter: type(f.numbering) == function) + name
      block(width: 100%, above: 0pt, below: 0pt, box(width: width - gutter - 2 * x,
        h(1fr) + name + (if lang == "en" { " " }) + num + refs.continued-gap(mark) + mark + sym.zws))
      rule(bottom, s.top)
    }
  })
}
#let _CONTAINERS = ([].func(), enum, list)
#let _parts(body) = {
  let own = ()
  let items = ()
  for c in if body.has("children") { body.children } else { (body,) } {
    if c.func() in (enum.item, list.item) { items.push(c) }
    else if c.func() in _CONTAINERS { let (o, i) = _parts(c); own += o; items += i }
    else { own.push(c) }
  }
  (own, items)
}
#let _items(body) = _parts(body).at(1)
#let _flatten(items, level) = {
  let out = ()
  for c in items {
    if c.func() not in (enum.item, list.item) { continue }
    let (own, kids) = _parts(c.body)
    out.push((body: own.join(), level: level, numbered: c.func() == enum.item))
    out += _flatten(kids, level + 1)
  }
  out
}
#let _number-text(pattern, n) = text(
  size: 0.8em, top-edge: "ascender", bottom-edge: "descender", number-width: "tabular",
  if pattern == "①" { _quan(n) } else { numbering(pattern, n) },
)
#let _number(n, level, pattern, col) = box(width: 0pt, move(
  dx: -(level * _INDENT + _NUMBER-GAP + col),
  box(width: col, h(1fr) + _number-text(pattern, n)),
))
#let _column(pattern, from, to) = {
  if pattern == none { return 0pt }
  let w = _NUMBER-COLUMN.to-absolute()
  for n in range(from + 1, to + 1) { w = calc.max(w, measure(_number-text(pattern, n)).width) }
  w
}
#let _hook(depth-below) = place(bottom + left,
  dx: -(_INDENT / 2 + depth-below * _INDENT),
  line(length: 0.5em, stroke: _guide("hook")),
)
#let _render(flat, offset, m, st, lang, col) = {
  let pattern = st.line-numbering
  let ends(i) = {
    let next = if i + 1 < flat.len() { flat.at(i + 1).level } else { 0 }
    calc.max(0, flat.at(i).level - next)
  }
  let stack = ((),)
  let k = offset
  for (i, line) in flat.enumerate() {
    while stack.len() - 1 > line.level {
      let top = stack.pop()
      stack.last().push(_indent(..top))
    }
    while stack.len() - 1 < line.level { stack.push(()) }
    let head = if line.numbered and pattern != none { k += 1; _number(k, line.level, pattern, col) } else { none }
    let hooks = if st.indent-guide == "hook" { range(ends(i)).map(_hook).join() } else { none }
    stack.last().push(head + _keyword-rules(lang, st.keyword-case, line.body) + hooks)
  }
  while stack.len() > 1 {
    let top = stack.pop()
    stack.last().push(_indent(..top))
  }
  stack.first()
}
#let _lovelace-options(st, title: none) = (
  line-numbering: none,
  line-gap: 0pt,
  indentation: _INDENT,
  hooks: 0pt,
  stroke: _guide(st.indent-guide),
  title: title,
  title-inset: 0pt,
)
#let _lines(flat, st, m, lang, col, offset: 0, title: none) = pseudocode(
  .._lovelace-options(st, title: title), .._render(flat, offset, m, st, lang, col),
)
#let _frame(head, rest) = {
  let st = _settings.resolve-algorithm-style()
  let style = st.frame
  let lang = doc-lang.get()
  let layout = _layout.current-page-setup()
  let grid = layout.docgrid.grid
  let ts = _cells.table-style()
  let cell = _cells.cell-style(ts, ts.size)
  let s = ts.stroke
  let x = ts.inset.x
  let piece = block.with(width: 100%, above: 0pt, below: 0pt)
  let m = spacing(cell, layout: layout)
  show: style-rules.rules.with(cell, layout: layout, set-font: true)
  set align(left)
  context {
  let off = _line-offset()
  let col = _column(st.line-numbering, off, off + rest.filter(l => l.numbered).len())
  let gutter = if col == 0pt { 0pt } else { col + _NUMBER-GAP }
  let top = if head.len() == 0 { none } else { _lines(head, st, m, lang, col) }
  let title = if style == "tabular" {
    _tabular-title(if top == none { none } else { piece(top) }, s, x, layout.text-width, gutter)
  } else { none }
  let top = if top == none { none } else { piece(inset: (x: x), pad(left: gutter, top)) }
  let main = piece(inset: (x: x), pad(left: gutter,
    _lines(rest, st, m, lang, col, offset: off, title: title)))
  let rule(stroke) = piece(height: 0pt, stroke: (top: stroke))
  if style == "tabular" {
    piece(stroke: (bottom: s.bottom), inset: (top: s.header / 2, bottom: s.bottom / 2), main)
  } else if style == "ruled" {
    rule(s.header)
    piece(inset: (top: s.header / 2, bottom: s.bottom / 2), {
      top
      main
    })
    rule(s.bottom)
  } else {
    piece(stroke: s.header, inset: (y: s.header / 2), {
      top
      main
    })
  }
  }
}
#let _split(body) = {
  let items = _items(body)
  let n = 0
  for c in items { if c.func() == list.item { n += 1 } else { break } }
  (items.slice(0, n), items.slice(n))
}
#let lovelace(body) = {
  let (head, rest) = _split(body)
  let head = _flatten(head, 0)
  let rest = _flatten(rest, 0)
  context _frame(head, rest)
  algorithm-mark(rest.filter(l => l.numbered).len())
}
#let algorithmic(..bits) = {
  let flat = bits.pos().map(b => _algorithmic.ast-to-content-list(0, b)).flatten()
    .map(l => (body: l.line-content, level: calc.quo(l.line-indent, 2), numbered: true))
  context _frame((), flat)
  algorithm-mark(flat.len())
}
