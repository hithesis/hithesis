
#import "@local/banshi:0.1.0" as banshi
#import "../../heading/numbering.typ" as _numbering
#import "../continued.typ": find-continued
#import "../../terms/lang.typ": doc-lang
#import "../../references/refs.typ" as refs
#import banshi.styles as _table
#import banshi.styles: table-style, cell-style, verbatim-mark
#let continued-row(metrics, top-rule, by-chapter) = context {
  let page-now = here().page()
  let me = here().position()
  let owners = query(figure.where(kind: table)).filter(g => {
    let at = g.location().position()
    at.page < me.page or (at.page == me.page and at.y <= me.y)
  })
  if owners.len() == 0 { return }
  let f = owners.last()
  let mark = find-continued(f.caption.body)
  if f.location().page() == page-now and mark == none { return }
  if f.numbering == none { return }
  let lang = doc-lang.get()
  let src = if mark == none {
    f
  } else if mark.target != none {
    query(mark.target).first()
  } else {
    let before = query(figure.where(kind: table)).filter(
      g => g.location().position().page < f.location().position().page
        or (g.location().position().page == f.location().position().page
            and g.location().position().y < f.location().position().y),
    )
    if before.len() == 0 { return }
    before.last()
  }
  if mark != none and f.location().page() == page-now {
    counter(figure.where(kind: table)).update(v => v - 1)
  }
  let seq = counter(figure.where(kind: table)).at(src.location())
  let num = if by-chapter {
    _numbering.chapter-numbered(src.location(), seq)
  } else {
    numbering("1", ..seq)
  }
  let given = refs.given-supplement(src.fields(), table, doc-lang.get())
  let mark-text = {
    let name = if given != auto { given } else { refs.word(lang, "table") }
    let mark = refs.continued-mark(lang, name)
    let name = if given != auto { given } else {
      _numbering.appendix-prefix(src.location(), lang, by-chapter: by-chapter) + name
    }
    name + (if lang == "en" { " " }) + num + refs.continued-gap(mark)
    mark
    sym.zws
  }
  // 那一格左对齐、标注不占宽：放得下就推到表右缘，放不下就居中、两边各溢出一半
  context {
    let w = measure(mark-text).width
    layout(size => box(width: 0pt, move(
      dx: if w <= size.width { size.width - w } else { -(w - size.width) / 2 },
      box(width: w, mark-text),
    )))
  }
}
#let table-rules(by-chapter: true, header-rows: 1, doc) = _table.table-rules(
  header-rows: header-rows,
  header-above: (metrics, top-rule) => continued-row(metrics, top-rule, by-chapter),
  doc,
)
