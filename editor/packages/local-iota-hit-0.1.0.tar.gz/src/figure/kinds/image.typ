#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing
#import banshi.paragraph as hyphenate
#import banshi.layout: chars, resolve-chars
#import banshi.layout as _layout
#import banshi.fonts as fonts
#import banshi.styles as style-rules
#import "../../settings/resolve.typ": setting-of
#import banshi.fonts: zihao, roles
#import banshi.content: metadata-of, label-of, plain-text
#import banshi.runs: has-cj
#import "../../terms/lang.typ": doc-lang, find-en, title-of
#import "../../case.typ": english-title
#import "../continued.typ": continued-step
#import "../../settings/resolve.typ": resolve-subcaption-bilingual
#let _subs-mark(gap: auto, ..items) = metadata((iota-subs: items.pos(), iota-subs-gap: gap))

#let find-subs(c) = {
  let r = metadata-of(c, "iota-subs")
  if r.len() == 0 { none } else { r.first() }
}
#let find-subs-gap(c) = {
  let r = metadata-of(c, "iota-subs-gap")
  if r.len() == 0 { auto } else { r.first() }
}
#let _half-gap(layout) = h(chars(0.5, layout: layout))
#let subs-offset(sel, src) = {
  let n = 0
  let cur = src
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    let body = cur.at("caption", default: none)
    if body == none { break }
    let items = find-subs(body.body)
    if items != none { n += items.len() }
    cur = continued-step(sel, cur)
  }
  n
}
#let subs-refs = state("iota-subfigure-refs", (:))
#let subs-rows = state("iota-subs-rows", false)
#let subfigure-kind = "iota-subfigure"
#let _region = layout
#let _sub-separator(sep, layout) = context {
  sep
  if not has-cj(plain-text(sep)) { _half-gap(layout) }
}
#let _sub-piece(index, body, lang, layout) = (
  head: context {
    let num = numbering(setting-of("subcaption-numbering"), index)
    num
    if not has-cj(plain-text(num)) { _half-gap(layout) }
  },
  body: {
    let b = title-of(body, lang)
    if lang == "en" { context english-title(b, slot: "caption") } else { b }
  },
)
#let _sub-langs(bodies) = {
  let bilingual = resolve-subcaption-bilingual()
  if bilingual and bodies.len() > 0 and bodies.all(b => find-en(b) != none) {
    ("zh", "en")
  } else {
    (doc-lang.get(),)
  }
}
#let _sub-block(rows, layout, style, width: auto, hang: false) = block(
  above: 0pt, below: 0pt, width: width,
  {
    show: style-rules.rules.with(style + (justify: true), layout: layout, set-font: true)
    show: hyphenate.hyphenate-rules
    set align(center)
    show par: p => p
    for row in rows {
      block(above: 0pt, below: 0pt, if not hang {
        sym.zws + row.head + row.body
      } else {
        _region(size => context {
          let whole = sym.zws + row.head + row.body
          if measure(whole).width <= size.width {
            whole
          } else {
            grid(
              columns: (auto, 1fr), align: left,
              sym.zws + row.head + sym.zws,
              par(justify: true, row.body),
            )
          }
        })
      })
    }
  },
)
#let subfigure(body, caption: none) = figure(
  body,
  caption: caption,
  kind: subfigure-kind,
  supplement: none,
  outlined: false,
)
#let sub-caption(it, layout, style) = context {
  let index = it.counter.get().first()
  let l = label-of(it.body)
  if l != none {
    let loc = here()
    subs-refs.update(m => m + ((str(l)): (loc: loc, index: index)))
  }
  _sub-block(
    _sub-langs((it.body,)).map(lang => _sub-piece(index, it.body, lang, layout)),
    layout, style, hang: true,
  )
}
#let subs-line(items, layout, style, start: 0) = context {
  let entries = items
    .enumerate()
    .map(((i, body)) => {
      let l = label-of(body)
      if l == none { none } else { (str(l), (loc: here(), index: start + i + 1)) }
    })
    .filter(e => e != none)
  let anchors = if entries.len() == 0 { none } else {
    subs-refs.update(m => m + entries.to-dict())
  }
  let langs = _sub-langs(items)
  anchors
  _sub-block(
    langs.map(lang => (
      head: [],
      body: items
        .enumerate()
        .map(((i, body)) => {
          let p = _sub-piece(start + i + 1, body, lang, layout)
          p.head + p.body
        })
        .join(_sub-separator(setting-of("subcaption-separator"), layout)),
    )),
    layout, style, width: 100%,
  )
}
#let _layout-ish(c) = (
  type(c) == array
    or (type(c) == content and (
      c.func() in (image, stack, grid, box, block, rect, circle, polygon, curve)
        or (c.has("children") and c.children.any(_layout-ish))
        or (c.has("body") and _layout-ish(c.body))
    ))
)
// 嵌套后宽度仍是高度的一次函数，无需迭代测量。
#let _build(c, gutter) = {
  if type(c) == array { return _build(stack(dir: ttb, ..c), gutter) }
  if type(c) == content and c.func() == stack {
    let dir = c.at("dir", default: ttb)
    let kids = c.children.filter(k => not (type(k) == content and k.func() == [ ].func()))
    if kids.len() == 0 { panic("subs: empty stack") }
    let spacing = c.at("spacing", default: none)
    let g = if spacing == none { gutter } else { spacing }
    let horizontal = dir in (ltr, rtl)
    let kids = if dir in (rtl, btt) { kids.rev() } else { kids }
    let nodes = kids.map(k => _build(k, gutter))
    let nodes = nodes.map(n => if n.kind == (if horizontal { "row" } else { "col" }) { n.children } else { (n,) }).flatten()
    if nodes.len() == 1 { return nodes.first() }
    let gaps = (nodes.len() - 1) * g
    return if horizontal {
      let a = nodes.map(n => n.a).sum()
      let b = nodes.map(n => n.b).sum() + gaps
      let fixed-h = nodes.filter(n => n.a == 0).map(n => n.d).fold(0pt, calc.max)
      let cap = nodes.filter(n => n.a != 0).map(n => n.cap).fold(none, (m, v) => if m == none { v } else { calc.min(m, v) })
      (kind: "row", children: nodes, gap: g, a: a, b: b,
        c: if a == 0 { 0 } else { 1 / a }, d: if a == 0 { fixed-h } else { -b / a },
        cap: cap, cap-w: if cap == none { none } else { a * cap + b })
    } else {
      let c0 = nodes.map(n => n.c).sum()
      let d0 = nodes.map(n => n.d).sum() + gaps
      let fixed-w = nodes.filter(n => n.c == 0).map(n => n.b).fold(0pt, calc.max)
      let cap-w = nodes.filter(n => n.c != 0).map(n => n.cap-w).fold(none, (m, v) => if m == none { v } else { calc.min(m, v) })
      (kind: "col", children: nodes, gap: g,
        a: if c0 == 0 { 0 } else { 1 / c0 }, b: if c0 == 0 { fixed-w } else { -d0 / c0 },
        c: c0, d: d0,
        cap: if cap-w == none { none } else { c0 * cap-w + d0 },
        cap-w: cap-w)
    }
  }
  let is-image = type(c) == content and c.func() == image
  let pinned = not is-image or c.at("width", default: auto) != auto or c.at("height", default: auto) != auto
  if pinned {
    let nat = measure(c)
    return (kind: "leaf", body: c, image: is-image, pinned: true, a: 0, b: nat.width, c: 0, d: nat.height, cap: nat.height, cap-w: nat.width)
  }
  let nat-w = measure(c).width
  let r = measure(image(c.source, height: 100pt)).width / 100pt
  if nat-w == 0pt or r == 0 {
    return (kind: "leaf", body: c, image: true, pinned: true, a: 0, b: nat-w, c: 0, d: nat-w, cap: nat-w, cap-w: nat-w)
  }
  (kind: "leaf", body: c, image: true, pinned: false, a: r, b: 0pt, c: 1 / r, d: 0pt, cap: nat-w / r, cap-w: nat-w)
}
#let _place-number(k, spec, default-font, default-size) = {
  if spec == none or spec == auto { return none }
  let d = if type(spec) == dictionary { spec.pairs().filter(((k, v)) => v != auto).to-dict() } else { (:) }
  let pattern = if type(spec) == str { spec } else { d.at("pattern", default: setting-of("subcaption-numbering")) }
  let font = if "font" not in d { default-font }
    else if type(d.font) == str and d.font in roles { fonts.font(d.font, fonts.fontset-state.get().families) }
    else { d.font }
  let body = if type(spec) == function { spec(k) } else {
    text(
      font: font, size: d.at("size", default: default-size),
      ..(if "fill" in d { (fill: d.fill) } else { (:) }),
      ..(if "stroke" in d { (stroke: d.stroke) } else { (:) }),
      numbering(pattern, k),
    )
  }
  if type(body) == content and body.func() == place { return body }
  place(
    d.at("alignment", default: top + left),
    dx: d.at("dx", default: 0.5 * default-size), dy: d.at("dy", default: 0.5 * default-size),
    body,
  )
}
#let _render(node, w, h, ctx) = {
  if node.kind == "leaf" {
    let (w, h) = if node.pinned { (node.b, node.d) } else { (w, h) }
    let k = ctx.index.at(0)
    ctx.index.at(0) += 1
    let body = if node.pinned { node.body } else {
      scale(100% * (w / node.cap-w), reflow: true, node.body)
    }
    let spec = if type(ctx.numbering) == array { ctx.numbering.at(k - 1, default: auto) } else { ctx.numbering }
    let num = _place-number(k, spec, ctx.font, ctx.size)
    let body = if num == none { body } else { box(width: w, { body; num }) }
    let body = if ctx.captions.len() >= k {
      subfigure(body, caption: ctx.captions.at(k - 1))
    } else { body }
    (w: w, h: h, body: body, ctx: ctx)
  } else if node.kind == "row" {
    let cells = ()
    let ws = ()
    for n in node.children {
      let r = _render(n, if n.a == 0 { n.b } else { n.a * h + n.b }, h, ctx)
      ctx = r.ctx
      cells.push(r.body); ws.push(r.w)
    }
    let hh = calc.max(h, ..node.children.map(n => if n.a == 0 { n.d } else { 0pt }))
    (w: ws.sum() + (ws.len() - 1) * node.gap, h: hh,
      body: grid(columns: ws, column-gutter: node.gap, align: center + horizon, ..cells), ctx: ctx)
  } else {
    let cells = ()
    let hs = ()
    for n in node.children {
      let r = _render(n, w, if n.c == 0 { n.d } else { n.c * w + n.d }, ctx)
      ctx = r.ctx
      cells.push(r.body); hs.push(r.h)
    }
    (w: w, h: hs.sum() + (hs.len() - 1) * node.gap,
      body: grid(columns: 1, row-gutter: node.gap, align: center, ..cells), ctx: ctx)
  }
}
#let _row(items, W, g, ctx, scale: 1) = {
  let node = _build(stack(dir: ltr, ..items), g)
  let node = if node.kind == "row" { node } else {
    (kind: "row", children: (node,), gap: g, a: node.a, b: node.b, c: node.c, d: node.d, cap: node.cap)
  }
  let h = if node.a == 0 { node.d } else { (W - node.b) / node.a }
  let h = if node.cap == none { h } else { calc.min(h, node.cap) }
  let r = _render(node, node.a * h * scale + node.b, h * scale, ctx)
  (body: align(center, r.body), h: r.h, ctx: r.ctx)
}
#let _subs-layout(items, columns, width, gutter, captions, numbering) = {
  let items = items.filter(k => not (type(k) == content and k.func() == [ ].func()))
  if items.len() == 0 { panic("subs: nothing to lay out") }
  if type(captions) != array { panic("subs: captions: expected array, found " + str(type(captions))) }
  let rows = if columns == auto { (items,) } else if type(columns) == int {
    range(0, items.len(), step: columns).map(i => items.slice(i, calc.min(i + columns, items.len())))
  } else if type(columns) == array {
    let out = (); let i = 0
    for n in columns { out.push(items.slice(i, calc.min(i + n, items.len()))); i += n }
    if i < items.len() { out.push(items.slice(i)) }
    out
  } else { panic("subs: columns: expected auto, integer, or array, found " + repr(columns)) }
  layout(size => context {
    let lay = _layout.current-page-setup()
    let g = (if gutter == auto { chars(1) } else { resolve-chars(gutter, lay) }).to-absolute()
    let W = if type(width) == ratio { size.width * width } else { width.to-absolute() }
    let fresh = (index: (1,), captions: captions, numbering: numbering,
      font: fonts.font("sans", fonts.fontset-state.get().families), size: zihao.wuhao)
    let ctx = fresh
    let out = ()
    for row in rows {
      let r = _row(row, W, g, ctx)
      ctx = r.ctx
      out.push(r)
    }
    let room = lay.text-height - 3 * lay.docgrid.line-pitch
    if out.len() == 1 and out.first().h > room {
      out = (_row(rows.first(), W, g, fresh, scale: room / out.first().h),)
    }
    let snapped = lay.docgrid.grid and lay.docgrid.line-pitch != 0pt
    let row-block(r) = if snapped {
      let h = measure(block(width: size.width, r.body)).height
      let rows = calc.max(1, calc.ceil(h / lay.docgrid.line-pitch))
      block(width: 100%, height: rows * lay.docgrid.line-pitch, above: 0pt, below: 0pt, align(horizon, r.body))
    } else { block(width: 100%, above: 0pt, below: 0pt, r.body) }
    subs-rows.update(true)
    out.map(row-block).join(v(g))
    subs-rows.update(false)
  })
}
#let subs(gap: auto, columns: auto, width: auto, gutter: auto, captions: auto, numbering: auto, ..items) = {
  if items.pos().any(_layout-ish) {
    _subs-layout(
      items.pos(), columns,
      if width == auto { 90% } else { width },
      gutter,
      if captions == auto { () } else { captions },
      if numbering == auto { none } else { numbering },
    )
  } else {
    _subs-mark(gap: gap, ..items)
  }
}
