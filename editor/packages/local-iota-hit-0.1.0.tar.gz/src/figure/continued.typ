#import "@local/banshi:0.1.0" as banshi
#import banshi.content: metadata-of
#import "./kinds.typ" as kinds
#let continued(..args) = metadata((
  iota-continued: (target: args.pos().at(0, default: none)),
))

#let find-continued(c) = {
  let hits = metadata-of(c, "iota-continued")
  if hits.len() == 0 { none } else { hits.first() }
}
#let _prev-figure(sel, loc) = {
  let before = query(sel.before(loc)).filter(f => not kinds.original(f))
  if before.len() >= 2 { before.at(-2) } else { none }
}
#let continued-source(sel, mark) = {
  if mark != none and mark.target != none {
    return kinds.resolve(query(mark.target).first())
  }
  _prev-figure(sel, here())
}
#let continued-step(sel, cur) = {
  let cap = cur.at("caption", default: none)
  if cap == none { return none }
  let mark = find-continued(cap.body)
  if mark == none { return none }
  if mark.target != none {
    kinds.resolve(query(mark.target).first())
  } else {
    _prev-figure(sel, cur.location())
  }
}
#let continued-head(sel, mark) = {
  let cur = continued-source(sel, mark)
  let guard = 0
  while cur != none and guard < 32 {
    guard += 1
    let prev = continued-step(sel, cur)
    if prev == none { break }
    cur = prev
  }
  cur
}
