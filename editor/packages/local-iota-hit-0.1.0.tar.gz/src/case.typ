#import "@local/banshi:0.1.0" as banshi
#import banshi.content: plain-text
#import banshi.runs: has-cjk
#let title-case-state = state("iota-hit-title-case", none)

#let modes = (none, "sentence", "title")
#let slots = ("term", "heading", "caption")

#let _expected = "auto, none, \"sentence\", \"title\", or a dictionary with keys "
  + slots.map(repr).join(", ") + ", rest"

#let check-title-case(v) = {
  if v == auto or v in modes { return }
  if type(v) != dictionary {
    panic("title-case: expected " + _expected + "; found " + repr(v))
  }
  for (k, m) in v {
    if k not in slots + ("rest",) {
      panic("title-case: unknown key " + repr(k) + "; expected one of " + (slots + ("rest",)).map(repr).join(", "))
    }
    if m not in modes {
      panic("title-case." + k + ": expected none, \"sentence\", or \"title\", found " + repr(m))
    }
  }
}

#let mode-for(v, slot) = {
  if type(v) == dictionary { v.at(slot, default: v.at("rest", default: none)) } else { v }
}
#let _small = (
  "a", "an", "and", "as", "at", "but", "by", "down", "for", "from", "in", "into",
  "nor", "of", "on", "onto", "or", "over", "so", "the", "till", "to", "up", "via",
  "with", "yet",
)

#let _protected(w) = w.slice(1).match(regex("[A-Z]")) != none or w.match(regex("[0-9]")) != none
#let _unbraced(s) = s.replace("{{", "").replace("}}", "").replace(regex("\\{[^{}]*\\}"), "")
#let _all-caps(s) = {
  let t = _unbraced(s)
  t.match(regex("[A-Z]")) != none and t.match(regex("[a-z]")) == none
}

#let _cap(w) = upper(w.slice(0, 1)) + lower(w.slice(1))
// 花括号沿用 BibTeX 语义，使缩写在引文和标题中保持一致。
#let _segments(s) = {
  let cps = s.codepoints()
  let out = ()
  let i = 0
  let n = cps.len()
  let cur = ""
  while i < n {
    let ch = cps.at(i)
    if ch == "{" {
      if i + 1 < n and cps.at(i + 1) == "{" { cur += "{"; i += 2; continue }
      let close = cps.slice(i + 1).position(x => x == "}")
      if close == none { panic("title-case: unmatched \"{\" in English title: " + repr(s)) }
      if cur != "" { out.push((cur, "raw")); cur = "" }
      out.push((cps.slice(i + 1, i + 1 + close).join(), "keep"))
      i = i + 1 + close + 1
      continue
    }
    if ch == "}" {
      if i + 1 < n and cps.at(i + 1) == "}" { cur += "}"; i += 2; continue }
      panic("title-case: unmatched \"}\" in English title: " + repr(s))
    }
    cur += ch
    i += 1
  }
  if cur != "" { out.push((cur, "raw")) }
  let fine = ()
  for (t, kind) in out {
    if kind == "keep" { fine.push((t, "keep")); continue }
    for m in t.matches(regex("[A-Za-z0-9][A-Za-z0-9'’\\-\\.]*|[^A-Za-z0-9]+")) {
      fine.push((m.text, if m.text.match(regex("^[A-Za-z0-9]")) != none { "word" } else { "sep" }))
    }
  }
  fine
}
#let _walk(c, f, index, total, after-colon, count: false) = {
  if type(c) == str { return _walk(text(c), f, index, total, after-colon, count: count) }
  if type(c) != content { return (c, index, after-colon) }
  if c.func() == text {
    let segs = _segments(c.text)
    let out = ""
    let idx = index
    let ac = after-colon
    for (t, kind) in segs {
      if kind == "word" {
        if count { idx += 1 } else {
          out += f(t, idx, total, ac); idx += 1
        }
        ac = false
      } else {
        if not count { out += t }
        if kind == "sep" and t.match(regex("[:?!—–]\\s*$")) != none { ac = true }
        if kind == "keep" { idx += 1; ac = false }
      }
    }
    return (if count or out == c.text { c } else { text(out) }, idx, ac)
  }
  if c.has("children") {
    let kids = ()
    let idx = index
    let ac = after-colon
    let changed = false
    for k in c.children {
      let (nk, ni, na) = _walk(k, f, idx, total, ac, count: count)
      if nk != k { changed = true }
      kids.push(nk); idx = ni; ac = na
    }
    return (if count or not changed { c } else { kids.join() }, idx, ac)
  }
  if c.has("body") and c.func() in (emph, strong, sub, super, smallcaps, underline, strike, highlight, overline, link) {
    let (nb, ni, na) = _walk(c.body, f, index, total, after-colon, count: count)
    if count or nb == c.body { return (c, ni, na) }
    let rebuilt = if c.func() == link { link(c.dest, nb) } else { (c.func())(nb) }
    return (rebuilt, ni, na)
  }
  (c, index, after-colon)
}

#let _count-words(c) = _walk(c, none, 0, 0, false, count: true).at(1)

#let _convert(w, index, total, after-colon, mode, all-caps) = {
  let w = if all-caps { lower(w) } else if _protected(w) { return w } else { w }
  if mode == "sentence" {
    return if index == 0 or after-colon { _cap(w) } else { lower(w) }
  }
  let bare = lower(w)
  if index == 0 or index == total - 1 or after-colon { return _cap(w) }
  if bare in _small { bare } else { _cap(w) }
}
#let english-title(c, slot: "heading", mode: auto) = {
  if slot not in slots { panic("english-title: unknown slot " + repr(slot)) }
  let mode = if mode == auto { mode-for(title-case-state.get(), slot) } else { mode }
  if c == none { return none }
  if has-cjk(plain-text(c)) { return c }
  if mode == none {
    return _walk(c, (w, i, n, ac) => w, 0, 0, false).at(0)
  }
  let total = _count-words(c)
  let all-caps = _all-caps(plain-text(c))
  _walk(c, (w, i, n, ac) => _convert(w, i, n, ac, mode, all-caps), 0, total, false).at(0)
}
