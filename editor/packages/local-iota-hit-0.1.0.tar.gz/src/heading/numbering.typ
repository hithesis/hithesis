#import "../terms/lang.typ": doc-lang
#import "../terms/lookup.typ": term-of

#let hit-numbering(..nums) = {
  let n = nums.pos()
  if n.len() == 1 { "第" + str(n.at(0)) + "章" } else { n.map(str).join(".") }
}
#let hit-numbering-report(..nums) = nums.pos().map(str).join(".")
#let hit-numbering-en(..nums) = {
  let n = nums.pos()
  if n.len() == 1 { "Chapter " + str(n.at(0)) } else { n.map(str).join(".") }
}
#let hit-numbering-hass(..nums) = {
  let n = nums.pos()
  let last = n.last()
  if n.len() == 1 {
    "第" + numbering("一", last) + "章"
  } else if n.len() == 2 {
    numbering("一、", last)
  } else if n.len() == 3 {
    numbering("（一）", last)
  } else {
    numbering("1.", last)
  }
}
#let en-words = (
  "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
  "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
  "Eighteen", "Nineteen", "Twenty",
)
#let en-word(n) = if n >= 1 and n <= en-words.len() { en-words.at(n - 1) } else { str(n) }
#let appendix-mark(pat, n) = if pat == "One" { en-word(n) } else { numbering(pat, n) }
#let appendix-mark-en(pat, n) = if pat in ("一", "One") { en-word(n) } else {
  numbering(pat, n)
}
#let appendix-numeric(pat) = pat != none and pat not in ("A", "I")
#let hit-numbering-hass-en(..nums) = {
  let n = nums.pos()
  let last = n.last()
  if n.len() == 1 {
    "Chapter " + en-word(last)
  } else if n.len() == 2 {
    numbering("一、", last)
  } else if n.len() == 3 {
    numbering("（一）", last)
  } else {
    numbering("1.", last)
  }
}
#let resolve-numbering(value, lang: "zh", category: "stem", stage: "final") = {
  if value != auto { return value }
  if stage != "final" { return hit-numbering-report }
  if lang == "en" {
    return if category == "hass" { hit-numbering-hass-en } else { hit-numbering-en }
  }
  if category == "hass" { return hit-numbering-hass }
  hit-numbering
}
#let resolve-numbering-en(value, category: "stem", stage: "final") = {
  if value != auto { return value }
  if stage != "final" { return hit-numbering-report }
  if category == "hass" { hit-numbering-hass-en } else { hit-numbering-en }
}
#let appendix-numbering = state("iota-hit-appendix-numbering", none)
#let appendix-single = state("iota-hit-appendix-single", false)
#let _en-doc() = doc-lang.get() == "en"

#let appendix-prefixed(loc) = {
  let pat = appendix-numbering.at(loc)
  if pat == none or _en-doc() { return false }
  appendix-single.at(loc) or appendix-numeric(pat)
}
#let appendix-word(lang) = term-of(lang, "appendix", "prefix")

#let appendix-prefix(loc, lang, by-chapter: true) = if (
  by-chapter and appendix-prefixed(loc)
) {
  appendix-word(lang) + (if lang == "en" { " " })
}
#let chapter-mark(loc) = {
  let ch = counter(heading).at(loc)
  let n = if ch.len() > 0 { ch.first() } else { 0 }
  let pat = appendix-numbering.at(loc)
  if pat == none { return str(n) }
  if _en-doc() { return numbering(if pat == "I" { "I" } else { "A" }, n) }
  if appendix-single.at(loc) { return none }
  if appendix-numeric(pat) { return str(n) }
  numbering(pat, n)
}
#let chapter-numbered(loc, seq, open: "", sep: "-", close: "", prefix: none) = {
  let mark = chapter-mark(loc)
  let head = if mark == none { "" } else { mark + sep }
  let pre = if prefix == none { "" } else { prefix }
  open + pre + head + numbering("1", ..seq) + close
}
#let nonumber-rules(doc) = {
  show heading.where(label: <->): set heading(numbering: none, outlined: false)
  show figure.where(label: <->): set figure(numbering: none, outlined: false)
  show math.equation.where(label: <->): set math.equation(numbering: none)
  doc
}
