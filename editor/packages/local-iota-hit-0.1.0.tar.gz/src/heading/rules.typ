
#import "@local/banshi:0.1.0" as banshi
#import "../layout/matter.typ": clear-page, matter-openright
#import "./heading.typ": find-openright, find-leveled, heading-slot, levels, report-levels, heading-centered, two-hanzi-title, find-two-hanzi
#import "../terms/lang.typ": title-of, doc-lang
#import "../case.typ": english-title
#import "../settings/resolve.typ" as settings
#import "../info.typ": info-get
#import "./numbering.typ" as _numbering
#let heading-relation(levels: levels) = (
  link-level-to-style: it => if it.level == 1 and heading-slot(it) == "term" { "chapter" } else {
    levels.at(calc.min(it.level, levels.len()) - 1)
  },
  body-indent: level => settings.resolve-heading-body-indent(
    lang: doc-lang.get(), category: info-get().category, level: level,
  ),
  body: it => {
    let mine = it.numbering != none or find-leveled(it.body) != none
    if doc-lang.get() == "en" and mine {
      english-title(title-of(it.body, "en"))
    } else if mine {
      two-hanzi-title(title-of(it.body, "zh"), centered: heading-centered(it), local: find-two-hanzi(it.body))
    } else { it.body }
  },
)
#let heading-checks(numbering: none, chapter-pagebreak: true, doc) = {
  set heading(numbering: numbering)
  show heading: it => {
    context {
      if (
        it.numbering != none
          and it.numbering != numbering
          and _numbering.appendix-numbering.get() == none
      ) {
        panic(
          "heading numbering has no effect (the template numbers headings by the "
            + "guide's level table; write iota-hit(category: \"hass\") or "
            + "iota-hit(lang: \"en\") to switch schemes)",
        )
      }
    }
    if it.level == 1 and chapter-pagebreak {
      let mark = find-openright(it.body)
      context {
        let odd = if mark != none { mark } else { matter-openright.get() }
        clear-page(to: if odd { "odd" } else { none })
      }
    }
    it
  }
  doc
}
