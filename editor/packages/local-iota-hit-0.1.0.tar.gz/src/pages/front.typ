
#import "@local/banshi:0.1.0" as banshi
#import "../info.typ": final-only-wanted, info-get, value-of
#import "../once.typ": once
#import "../terms/lookup.typ": term-table, variant-of
#import "../layout/matter.typ": frontmatter-openright, cover-exit-odd, cover-exit, clear-page, frontmatter, mainmatter, backmatter, appendix
#import "../settings/resolve.typ": resolve-openright
#import banshi.layout: page-setup as msword-layout
#import "../layout/parts.typ": layout-for
#import banshi.styles: new-styles
#import "../terms/lang.typ": normalize as normalize-lang, doc-lang, split as split-lang, title-of
#import "./cover.typ" as _cover
#import "./titlepage.typ" as _titlepage
#import "./abstract.typ" as _abstract
#import "./outline.typ" as _toc
#import "./lists.typ" as _lists
#import "./report/cover.typ" as _report
#import "./report/shenzhen/cover.typ" as _report-shenzhen
#import "../layout/presets.typ": report-toc-headerless as _toc-headerless
#import "../axes.typ": campus-for
#let _toc-headerless-page(info, body) = {
  let bare = info.stage in _toc-headerless
    .at(campus-for(info.campus, info.degree-level), default: (:))
    .at(info.degree-level, default: ())
  if bare {
// set 规则只作用于同一内容块。
    set page(header: none)
    body
  } else { body }
}
#import "../axes.typ": report-stages as _report-stages

// 页级的 title / subtitle 也是一个键两种语言：英文那半写在 #en[] 里；没给就取元信息里的两格
// 页级只给了一半就只换那一半，另一半仍取元信息的；没标记就当文档语言那一半
#let _pair(v, k, i) = if v == auto {
  ((k, i.at(k)), (k + "-en", value-of(i, k, lang: "en")))
} else {
  let lang = doc-lang.get()
  let s = split-lang(v, lang: lang)
  if s.plain {
    if lang == "en" { ((k, i.at(k)), (k + "-en", v)) } else { ((k, v), (k + "-en", value-of(i, k, lang: "en"))) }
  } else {
    ((k, if s.zh == none { i.at(k) } else { s.zh }), (k + "-en", if s.en == none { value-of(i, k, lang: "en") } else { s.en }))
  }
}
#let cover(
  title: auto,
  title-en-xiaoer: auto,
  subtitle: auto,
  author: auto,
  institution: auto,
  date: auto,
  degree-level: auto,
  degree-type: auto,
  form: auto,
  practice-type: auto,
  warning: auto,
  annotated: auto,
  label: auto,
  layout: auto,
  overrides: (:),
) = context {
  once("cover")
  let i = info-get()
  if i.stage in _report-stages {
    if campus-for(i.campus, i.degree-level) == "shenzhen" and i.degree-level == "bachelor" {
      return _report-shenzhen.cover(
        stage: i.stage, info: i, overrides: overrides, layout: layout,
        lang: doc-lang.get(),
        ..(if title != auto { (title: title) } else { (:) }),
        ..(if warning != auto { (warning: warning) } else { (:) }),
      )
    }
    return _report.cover(
      stage: i.stage, info: i, overrides: overrides,
      ..(if title != auto { (title: title) } else { (:) }),
      ..(if warning != auto { (warning: warning) } else { (:) }),
      layout: layout,
    )
  }
  let pick(v, k) = if v != auto { (k, v) } else { (k, i.at(k)) }
  cover-exit-odd.update(resolve-openright(
    "titlepage", degree-level: i.degree-level, matter: frontmatter-openright.get(),
  ))
  _cover.cover(
    terms: term-table("zh", "cover", overrides: overrides),
    variant: variant-of(i),
    ..(
      (
        .._pair(title, "title", i),
        pick(title-en-xiaoer, "title-en-xiaoer"),
        .._pair(subtitle, "subtitle", i),
        pick(author, "author"),
        pick(institution, "institution"), pick(date, "date"),
        pick(degree-level, "degree-level"), pick(degree-type, "degree-type"),
        pick(form, "form"), pick(practice-type, "practice-type"),
      ).to-dict()
    ),
    ..(
      ((("warning", warning), ("annotated", annotated), ("label", label),
        ("layout", layout-for("cover", layout))).filter(((k, v)) => v != auto)).to-dict()
    ),
  )
}
#let titlepage(
  title: auto,
  title-en-xiaoer: auto,
  subtitle: auto,
  degree-attribute: auto,
  degree-level: auto,
  form: auto,
  secrecy: auto,
  classified-index: auto,
  udc: auto,
  fields: auto,
  school-code: auto,
  warning: auto,
  annotated: auto,
  label: auto,
  layout: auto,
  lang: auto,
  en: (:),
  openright: auto,
  overrides: (:),
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  once("titlepage")
  let i = info-get()
  let odd = resolve-openright(
    "titlepage",
    degree-level: i.degree-level,
    local: openright,
    matter: frontmatter-openright.get(),
  )
  let only(..kv) = kv.pos().filter(((k, v)) => v != auto).to-dict()
  let titles = _pair(title, "title", i)
  let subtitles = _pair(subtitle, "subtitle", i)
  let en = en + only(
    ("title-en", if title == auto { auto } else { titles.at(1).at(1) }),
    ("title-en-xiaoer", title-en-xiaoer),
    ("subtitle-en", if subtitle == auto { auto } else { subtitles.at(1).at(1) }),
    ("degree-attribute", degree-attribute),
  )
  let named = only(
    ("title", if title == auto { auto } else { titles.at(0).at(1) }),
    ("subtitle", if subtitle == auto { auto } else { subtitles.at(0).at(1) }),
    ("form", form), ("secrecy", secrecy),
    ("classified-index", classified-index), ("udc", udc),
    ("fields", fields),
    ("school-code", school-code),
  ) + only(("warning", warning), ("annotated", annotated), ("label", label)) + (layout: layout-for("titlepage", layout))

  let want = if lang == auto {
    if i.degree-level in ("master", "doctor") { ("zh", "en") } else { ("zh",) }
  } else {
    (normalize-lang(lang),)
  }

  if "zh" in want {
  clear-page(to: if odd { "odd" } else { none })
  _titlepage.titlepage(..((
    terms: term-table("zh", "titlepage", overrides: overrides),
    info: i,
    degree-level: i.degree-level,
    title: i.title,
    subtitle: i.subtitle,
    secrecy: i.secrecy,
    form: i.form,
    classified-index: i.classified-index,
    udc: i.udc,
    school-code: i.school-code,
  ) + named))
  }

  if "en" in want {
    clear-page(to: if odd { "odd" } else { none })
    _titlepage.titlepage-en(..((
      terms: term-table("en", "titlepage", overrides: overrides),
      info: i,
      degree-level: i.degree-level,
      title-en: value-of(i, "title", lang: "en"),
      title-en-xiaoer: i.title-en-xiaoer,
      subtitle-en: i.subtitle-en,
      form: i.form,
      classified-index: i.classified-index,
      udc: i.udc,
    ) + only(("warning", warning), ("annotated", annotated)) + (layout: layout-for("titlepage", layout)) + en))
  }
  cover-exit-odd.update(odd)
}
#let abstract(
  content,
  keywords: (),
  title: auto,
  lang: auto,
  overrides: (:),
  openright: auto,
  layout: auto,
  keywords-above: auto,
  keywords-hanging: auto,
  styles: auto,
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }
  let styles-of(l) = if type(styles) == dictionary and styles.keys().all(k => k in ("zh", "en")) and styles.len() > 0 {
    styles.at(l, default: auto)
  } else { styles }
  if type(keywords) != array {
    panic("abstract: keywords: expected an array of contents such as ([论文#en[thesis]], …), found " + repr(keywords))
  }

  once("abstract")
  cover-exit()
  context {
    let i = info-get()
    // 另一种语言写在 #en[] / #zh[] 里；只有一种语言就只排那一页（没标记＝文档语言），lang: 再挑
    let halves = split-lang(content, lang: doc-lang.get())
    let bodies = ("zh", "en").map(l => (l, halves.at(l))).filter(((l, b)) => b != none)
    if halves.plain { bodies = ((if lang == auto { doc-lang.get() } else { normalize-lang(lang) }, content),) }
    if lang != auto {
      bodies = bodies.filter(((l, b)) => l == normalize-lang(lang))
    }
    for (l, body) in bodies {
      let page = _abstract.abstract(
        lang: l,
        single: bodies.len() == 1,
        title: if title == auto { auto } else { title-of(title, l) },
        keywords: keywords.map(k => title-of(k, l)),
        overrides: overrides,
        openright: openright,
        layout: layout-for("abstract", layout),
        keywords-above: keywords-above,
        keywords-hanging: keywords-hanging,
        body,
      )
      let st = styles-of(l)
      if st == auto { page } else { new-styles(st, page) }
    }
  }
}
#let _set(..pairs) = {
  let out = (:)
  for (k, v) in pairs.named() {
    if v != auto { out.insert(k, v) }
  }
  out
}

// 目录、索引页的标题：一个键两种语言，英文那半写在 #en[] 里；没写英文就两页同名
#let _titles(v) = if v == auto { (title: auto, title-en: auto) } else {
  (title: title-of(v, "zh"), title-en: title-of(v, "en"))
}
#let table-of-contents(
  title: auto,
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  depth: auto,
  levels: auto,
  overrides: (:),
  heading-body-indent: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  fill: auto,
  layout: auto,
  lang: auto,
  warning: auto,
) = {
  cover-exit()
  context {
    let i = info-get()
    _toc-headerless-page(i, _toc.toc(
      degree-level: i.degree-level, stage: i.stage, doc-lang: doc-lang.get(), category: i.category,
      .._titles(title), two-hanzi: two-hanzi, openright: openright,
      overrides: overrides, heading-body-indent: heading-body-indent,
      outline-entry-right-margin: outline-entry-right-margin,
      outline-entry-number-align: outline-entry-number-align,
      lang: lang, once: true, outlined: outlined, warning: warning,
      .._set(
        depth: depth, levels: levels,
        fill: fill, layout: layout-for("toc", layout),
      ),
    ))
  }
}
#let _list-of(which) = (
  title: auto,
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  overrides: (:),
  levels: auto,
  heading-body-indent: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  fill: auto,
  layout: auto,
  lang: auto,
  warning: auto,
) => context {
  let i = info-get()
  which(
    degree-level: i.degree-level, stage: i.stage, doc-lang: doc-lang.get(), category: i.category,
    campus: campus-for(i.campus, i.degree-level),
    .._titles(title), two-hanzi: two-hanzi, openright: openright,
    overrides: overrides, heading-body-indent: heading-body-indent,
    outline-entry-right-margin: outline-entry-right-margin,
    outline-entry-number-align: outline-entry-number-align,
    outlined: outlined, lang: lang, once: true, warning: warning,
    .._set(levels: levels, fill: fill), layout: layout-for("toc", layout),
  )
}

#let list-of-figures = _list-of(_lists.lof)
#let list-of-tables = _list-of(_lists.lot)
#let list-of-equations(
  title: auto,
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  overrides: (:),
  levels: auto,
  heading-body-indent: auto,
  outline-entry-right-margin: auto,
  outline-entry-number-align: auto,
  fill: auto,
  layout: auto,
  lang: auto,
  form: auto,
) = context {
  let i = info-get()
  _lists.loe(
    degree-level: i.degree-level, stage: i.stage, doc-lang: doc-lang.get(), category: i.category,
    campus: campus-for(i.campus, i.degree-level),
    .._titles(title), two-hanzi: two-hanzi, openright: openright,
    overrides: overrides, heading-body-indent: heading-body-indent,
    outline-entry-right-margin: outline-entry-right-margin,
    outline-entry-number-align: outline-entry-number-align,
    outlined: outlined, lang: lang, once: true, form: form,
    .._set(levels: levels, fill: fill), layout: layout-for("toc", layout),
  )
}
