#let _label-width = 2.5cm
#let _label-sep = 0.5cm
#let label-sep = _label-sep
#let items(c) = {
  if c.func() == terms.item { (c,) }
  else if c.func() == terms { c.children.map(items).flatten() }
  else if c.has("children") { c.children.map(items).flatten() }
  else { () }
}

#let check-hanging-indent(name, value) = {
  if value != auto and type(value) != length {
    panic(name + ": hanging-indent: expected length or auto, found " + repr(value))
  }
  if value != auto and value <= _label-sep {
    panic(
      name + ": hanging-indent: must be larger than the gap between label and description ("
        + repr(_label-sep) + ")",
    )
  }
}
#let check-header(name, value) = {
  if value not in (auto, true, false) {
    panic(
      name + ": header: expected auto, true, or false (the column headings are terms; "
        + "change the words with overrides, as in list-of-symbols-column-symbol: [...]), found "
        + repr(value),
    )
  }
}

#let resolve-header(value, pair) = if value == true { pair } else { none }
// 首列多宽由整张表的高定：在候选宽度（各标签的宽，下限 thuthesis / bithesis 的 labelwidth 2.5cm）
// 里逐个试排，每行取两格里高的那个，总高最小的胜；标签比列宽的那几行只推自己的说明，每推一行
// 记一行的罚——第一列尽可能不折（不溢），除非为它加宽整列反而让别的行折得更多。同高取宽的。
#let _row-cells(label, description, width) = {
  let overflow = measure(label).width - width
  (box(label), if overflow > 0pt { h(overflow) + description } else { description })
}
#let auto-label-width(rows, size) = {
  let widths = rows.map(((label, _)) => measure(label).width)
  let candidates = (_label-width, ..widths.filter(w => w > _label-width and w <= size.width / 2))
    .map(w => calc.round(w / 1pt, digits: 2) * 1pt).dedup().sorted()
  let line = measure(block(width: size.width, [x])).height
  let cost(width) = {
    let rest = size.width - width - _label-sep
    let total = 0pt
    for ((label, description), lw) in rows.zip(widths) {
      let (a, b) = _row-cells(label, description, width)
      let h = calc.max(measure(a).height, measure(block(width: rest, b)).height)
      total += h + (if lw > width { line } else { 0pt })
    }
    total
  }
  let best = candidates.first()
  let best-cost = cost(best)
  for w in candidates.slice(1) {
    let c = cost(w)
    if c <= best-cost { best = w; best-cost = c }
  }
  best
}
#let term-list(rows, hanging-indent: auto, header: none) = {
  if header != none and (type(header) != array or header.len() != 2) {
    panic("term-list: header: expected none or an array of exactly two items, found " + repr(header))
  }
  let all = (if header == none { () } else { (header,) }) + rows
  std.layout(size => {
    let width = if hanging-indent != auto { hanging-indent - _label-sep } else { auto-label-width(all, size) }
    grid(
      columns: (width, 1fr), column-gutter: _label-sep, row-gutter: 0pt,
      align: left + top,
      ..all.map(((label, description)) => _row-cells(label, description, width)).flatten(),
    )
  })
}
