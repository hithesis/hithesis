#import "@local/banshi:0.1.0" as banshi
#import banshi.fonts: zihao
#import "../info.typ": final-only-wanted
#import "./abbreviations.typ" as _page
#import "../references/abbreviations.typ" as _abbr
#import "../heading/heading.typ": term-chapter
#import "./terms.typ": items, term-list, check-hanging-indent, check-header, auto-hanging-indent, resolve-header
#import "../terms/lookup.typ": term-table, lookup-key
#import "../terms/lang.typ": resolve-lang
#import "../layout/matter.typ": front-numbering-enter, cover-exit
#import banshi.styles: paragraph
#import banshi.layout: linebreaks-sets
#import "../layout/parts.typ": layout-for
#import "../styles/group-heading.typ": group-heading
#import "../once.typ": once, never-with
#let _subheading-style = (
  snap-to-grid: false,
  size: zihao.xiaosan, asian-font: "heiti", line-spacing: 1.25, first-line-indent: (chars: 0),
  align: center, above: (lines: 0.5), below: (lines: 0.5),
)
#let _subheading(body, layout, form, first: false) = {
  if form == "no-subheadings" { return }
  if form == "achievements" { return group-heading(body, layout) }
  paragraph(
    body,
    _subheading-style + (if first { (above: 0pt) } else { (:) }),
    layout: layout,
  )
}
#let _rows(body, verbatim, who) = {
  if verbatim { return none }
  let parsed = items(body).map(it => (it.term, it.description))
  if parsed.len() == 0 {
    panic(
      who + ": expected a term list, found " + repr(body.func())
        + " (write " + who + "[/ $x$: explanation], or verbatim: true to lay the body out yourself)",
    )
  }
  parsed
}

#let _check(who, verbatim, header, hanging-indent, outlined) = {
  check-hanging-indent(who, hanging-indent)
  if verbatim not in (auto, true, false) {
    panic(who + ": verbatim: expected boolean or auto, found " + repr(verbatim))
  }
  if outlined not in (auto, true, false) {
    panic(who + ": outlined: expected boolean or auto, found " + repr(outlined))
  }
  check-header(who, header)
  if header == true and verbatim == true {
    panic(who + ": header: only meaningful with a term list")
  }
}
#let list-of-symbols(
  lang: auto,
  title: auto,
  overrides: (:),
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  hanging-indent: auto,
  layout: auto,
  verbatim: auto,
  header: auto,
  body,
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  _check("list-of-symbols", verbatim, header, hanging-indent, outlined)
  let verbatim = verbatim == true
  let rows = _rows(body, verbatim, "list-of-symbols")
  once("list-of-symbols")
  never-with(
    "list-of-symbols", "nomenclature",
    "nomenclature prints the symbols and the abbreviations together; write either "
      + "#nomenclature[...] or #list-of-symbols[...] + #list-of-abbreviations(), not both",
  )
  cover-exit()
  front-numbering-enter(openright: openright)
  term-chapter(
    "list-of-symbols", lang: lang, title: title,
    overrides: overrides, two-hanzi: two-hanzi, openright: openright,
    outlined: outlined != false,
  )
  if verbatim { body } else {
    set par(first-line-indent: 0pt)
    context {
      let t = term-table(resolve-lang(lang), "list-of-symbols", overrides: overrides)
      term-list(
        rows, hanging-indent: hanging-indent,
        header: resolve-header(header, (strong(t.column-symbol), strong(t.column-description))),
      )
    }
  }
}
#let nomenclature(
  abbreviations: none,
  lang: auto,
  title: auto,
  overrides: (:),
  two-hanzi: auto,
  openright: auto,
  outlined: auto,
  hanging-indent: auto,
  layout: auto,
  verbatim: auto,
  header: auto,
  sort: auto,
  used-only: auto,
  form: auto,
  body,
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }

  _check("nomenclature", verbatim, header, hanging-indent, outlined)
  if abbreviations == none {
    panic("nomenclature: abbreviations: expected the abbreviation entries (a dictionary, "
      + "yaml(...), or an array of dictionaries); for symbols alone write #list-of-symbols[...]")
  }
  if form not in (auto, "achievements", "declarations", "no-subheadings", none) {
    panic("nomenclature: form: expected auto, \"achievements\", \"declarations\", \"no-subheadings\", or none, found " + repr(form))
  }
  let form = if form == auto { "achievements" } else { form }
  for (name, value) in (sort: sort, used-only: used-only) {
    if value not in (auto, true, false) {
      panic("nomenclature: " + name + ": expected boolean or auto, found " + repr(value))
    }
  }
  if form == none { return _abbr.declare(abbreviations) }
  let verbatim = verbatim == true
  let rows = _rows(body, verbatim, "nomenclature")
  once("nomenclature")
  let hint = (
    "nomenclature prints the symbols and the abbreviations together; write either "
      + "#nomenclature[...] or #list-of-symbols[...] + #list-of-abbreviations(), not both"
  )
  never-with("nomenclature", "list-of-symbols", hint)
  never-with("nomenclature", "list-of-abbreviations", hint)
  let bucket-of(k) = {
    let hit = lookup-key(k, lang: resolve-lang(lang))
    if hit == none { none } else { hit.at(1) }
  }
  let picked(bucket) = {
    let out = (:)
    for (k, v) in overrides {
      if bucket-of(k) == bucket { out.insert(k, v) }
    }
    out
  }
  let own = {
    let out = picked("nomenclature")
    for (k, v) in overrides {
      if bucket-of(k) == none { out.insert(k, v) }
    }
    out
  }
  _abbr.declare(abbreviations)
  _abbr.mark-printed()
  cover-exit()
  front-numbering-enter(openright: openright)
  term-chapter(
    "nomenclature", lang: lang, title: title,
    overrides: own, two-hanzi: two-hanzi, openright: openright,
    outlined: outlined != false,
  )
  _abbr.anchor()
  context {
    let l = resolve-lang(lang)
    let lay = layout-for("nomenclature", layout)
    show: linebreaks-sets.with(lay)
    let for-sym = picked("list-of-symbols")
    let for-abbr = picked("list-of-abbreviations")
    set par(first-line-indent: 0pt)
    std.layout(size => {
      let st = term-table(l, "list-of-symbols", overrides: for-sym)
      let at = term-table(l, "list-of-abbreviations", overrides: for-abbr)
      let heads = if header == true {
        (strong(st.column-symbol), strong(at.column-short))
      } else { () }
      let labels = (
        (if rows == none { () } else { rows.map(((label, _)) => label) })
          + _abbr.entries.final().values().map(e => e.short)
          + heads
      )
      let indent = if hanging-indent != auto { hanging-indent } else {
        auto-hanging-indent(labels, size)
      }
      _subheading(st.title, lay, form, first: true)
      if verbatim { body } else {
        term-list(
          rows, hanging-indent: indent,
          header: resolve-header(header, (strong(st.column-symbol), strong(st.column-description))),
        )
      }
      _subheading(at.title, lay, form)
      _page.listing(
        lang: l, overrides: for-abbr, header: header, hanging-indent: indent,
        sort: sort, used-only: used-only,
      )
    })
  }
}
