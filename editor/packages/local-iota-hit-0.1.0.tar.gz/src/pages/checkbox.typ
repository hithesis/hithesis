#let checkbox-advance = 0.891em

#let _box-empty = (height: 0.72266em, path: (
    curve.move((0.13281em, 0.67432em)),
    curve.line((0.75928em, 0.67432em)),
    curve.line((0.75928em, 0.04785em)),
    curve.line((0.13281em, 0.04785em)),
    curve.close(),
    curve.move((0.08447em, 0.72266em)),
    curve.line((0.08447em, 0.0em)),
    curve.line((0.80713em, 0.0em)),
    curve.line((0.80713em, 0.72266em)),
    curve.close(),
))

#let _box-checked = (height: 0.76562em, path: (
    curve.move((0.42188em, 0.58447em)),
    curve.line((0.40039em, 0.59863em)),
    curve.quad((0.37256em, 0.6167em), (0.35254em, 0.63477em)),
    curve.quad((0.34863em, 0.61719em), (0.33301em, 0.57812em)),
    curve.line((0.32227em, 0.55029em)),
    curve.quad((0.28564em, 0.45996em), (0.2605em, 0.42407em)),
    curve.quad((0.23535em, 0.38818em), (0.20605em, 0.38525em)),
    curve.quad((0.24561em, 0.34912em), (0.27539em, 0.34912em)),
    curve.quad((0.31543em, 0.34912em), (0.36377em, 0.45801em)),
    curve.line((0.38135em, 0.49707em)),
    curve.quad((0.50879em, 0.26855em), (0.72021em, 0.09082em)),
    curve.line((0.13232em, 0.09082em)),
    curve.line((0.13232em, 0.71729em)),
    curve.line((0.75879em, 0.71729em)),
    curve.line((0.75879em, 0.10791em)),
    curve.quad((0.64551em, 0.21143em), (0.55493em, 0.3396em)),
    curve.quad((0.46436em, 0.46777em), (0.42188em, 0.58447em)),
    curve.close(),
    curve.move((0.80713em, 0.06689em)),
    curve.line((0.80713em, 0.76562em)),
    curve.line((0.08447em, 0.76562em)),
    curve.line((0.08447em, 0.04297em)),
    curve.line((0.78271em, 0.04297em)),
    curve.quad((0.81934em, 0.01758em), (0.84863em, 0.0em)),
    curve.line((0.86279em, 0.02539em)),
    curve.quad((0.83887em, 0.04248em), (0.80713em, 0.06689em)),
    curve.close(),
))
#let checkbox(checked) = {
  let g = if checked { _box-checked } else { _box-empty }
  box(width: checkbox-advance, height: 0pt, place(
    top + left, dy: -g.height,
    curve(fill: black, fill-rule: "even-odd", stroke: none, ..g.path),
  ))
}

