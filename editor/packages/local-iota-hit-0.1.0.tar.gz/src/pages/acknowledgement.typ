#import "../heading/heading.typ": term-page

#let acknowledgement = term-page("acknowledgement")
