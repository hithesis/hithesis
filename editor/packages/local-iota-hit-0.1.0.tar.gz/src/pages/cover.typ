#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing
#import banshi.fonts: zihao
#import "../terms/lookup.typ": static-terms, term-apply, term-for
#import "../terms/date.typ" as _date
#import "../glyphs/cover.typ": cover-kaishu
#import banshi.fonts as fonts
#import banshi.paragraph: paragraph-mark as enter
#import "../axes.typ": axes, degree-type-for
#import banshi.errors as _errors
#import banshi.layout: linebreaks-sets
#import "../layout/parts.typ": standalone-layout
#import banshi.styles: paragraph
#import "./overflow.typ": overflow-note
#let _en-title-size(xiaoer) = {
  assert(
    xiaoer == auto or type(xiaoer) == bool,
    message: "expected auto, true, or false, found " + repr(xiaoer),
  )
  if xiaoer == auto { auto } else { if xiaoer { zihao.xiaoer } else { zihao.erhao } }
}
#let sample-title = [局部多孔质气体静压轴承关键技术的研究]
#let sample-title-en = [RESEARCH ON KEY TECHNOLOGIES OF PARTIAL POROUS
  EXTERNALLY PRESSURIZED GAS BEARING]
#let _quality-threshold = 10pt

#let cover(
  degree-level: "doctor",
  degree-type: auto,
  form: "dissertation",
  practice-type: [□□……□],
  terms: static-terms("zh", "cover"),
  label: auto,
  title: sample-title,
  title-en: sample-title-en,
  title-en-xiaoer: auto,
  subtitle: none,
  subtitle-en: none,
  author: [□□□],
  institution: static-terms("zh", "cover").university,
  date: "2022-06",
  institution-baseline: auto,
  layout: auto,
  warning: auto,
  annotated: auto,
  variant: auto,
) = {
  let variant = (if variant == auto { (:) } else { variant }) + (degree-level: degree-level, form: form)
  let warning = warning != false
  let annotated = annotated == true
  let layout = if layout == auto { standalone-layout("cover") } else { layout }
  show: linebreaks-sets.with(layout)
  assert(
    degree-level in axes.degree-level,
    message: _errors.expected-one-of(axes.degree-level, degree-level),
  )
  let label = if label == auto {
    term-for(terms, "document-type", variant)
  } else { label }
  let date = _date.render(date)
  assert(
    degree-type == auto or degree-type == none or degree-type in axes.degree-type,
    message: "expected "
      + _errors.one-of(("auto", "none") + axes.degree-type.map(repr))
      + ", found " + repr(degree-type),
  )
  let degree-type = degree-type-for(degree-level, degree-type, form)
  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin,
    ..(if layout.header.shown == false { (header: none) } else { (:) }),
    ..(if layout.footer.shown == false { (footer: none) } else { (:) }),
  )
  set text(size: zihao.xiaosi, lang: "zh", region: "cn")
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)
  let note(body) = if annotated {
    paragraph(body, (asian-font: "songti", size: zihao.xiaosi, align: center), layout: layout)
  } else {
    enter(size: zihao.xiaosi, font: "songti", line-spacing: 1)
  }
  let title-en-full = if subtitle-en == none { title-en } else {
    title-en + [：] + subtitle-en
  }
  let upto-en-block(en-size, squeeze, zh: title, sub: subtitle, en: title-en-full) = {
    enter(3, size: zihao.xiaosi, line-spacing: 1)
    paragraph(label, (asian-font: "songti", size: zihao.xiaoyi, bold: true, align: center), layout: layout)
    note[↑]
    note[（由 `degree-level: "bachelor"|"master"|"doctor"` 决定）]
    if degree-type != none {
      paragraph(
        term-apply(
          terms, "degree-type", variant + (degree-type: degree-type), practice-type,
        ),
        (asian-font: "songti", size: zihao.xiaoer, bold: true, align: center), layout: layout,
      )
      note[↑]
      note[（由 `degree-type: "academic"|"professional"|none` 决定）]
    }
    paragraph(
      zh, (asian-font: "heiti", size: zihao.erhao, snap-to-grid: true, latin-bold: true, align: center),
      layout: layout, above: 12pt,
    )
    if squeeze < 2 { note[↑] }
    if squeeze < 1 { note[（通过 `title: []` 键入）] }
    if sub != none {
      pad(left: 4 * zihao.xiaoer, paragraph(
        [——] + sub,
        (asian-font: "heiti", size: zihao.xiaoer, latin-bold: true, align: center), layout: layout,
      ))
    }
    paragraph(
      en, (latin-font: "serif", size: en-size, bold: true, line-spacing: 1.25, align: center),
      layout: layout, above: 12pt,
    )
  }
  let gap-en-author(n) = if annotated {
    note[↑]
    note[（通过 `title-en: []` 键入，太长时可用 `title-en-xiaoer: true` 转为小 2 号字）]
  } else if n > 0 {
    enter(n, size: zihao.xiaosi, font: "songti", line-spacing: 1)
  }
  let fixed-before-author(relax) = if relax < 2 {
    enter(size: zihao.erhao, font: "songti", line-spacing: if relax == 0 { 1.25 } else { 1 })
  }
  let gap-author-inst(blanks-below-author, blanks-before-inst, relax) = {
    if annotated {
      note[↑]
      note[（通过 `author: []` 键入）]
    } else if blanks-below-author > 0 {
      enter(blanks-below-author, size: zihao.xiaosi, font: "songti", line-spacing: 1)
    }
    if relax < 3 {
      enter(size: zihao.xiaoer, line-spacing: if relax == 0 { 1.25 } else { 1 })
    }
    if blanks-before-inst > 0 { enter(blanks-before-inst, size: zihao.xiaosi, line-spacing: 1) }
  }

  context {
    let author-metrics = spacing((size: zihao.xiaoer, asian-font: "songti"), layout: layout)
    let institution-metrics = spacing(
      (size: zihao.xiaoer, asian-font: "kaishu", line-spacing: 1.35), layout: layout,
    )
    let height-of(it) = measure(block(width: layout.text-width, it)).height

    let author-line = paragraph(author, (asian-font: "songti", size: zihao.xiaoer, bold: true, align: center), layout: layout)
    let inst-lines = {
      paragraph(
        cover-kaishu(institution),
        (asian-font: "kaishu", size: zihao.xiaoer, bold: true, line-spacing: 1.35, align: center),
        layout: layout,
      )
      paragraph(date, (asian-font: "songti", size: zihao.xiaoer, bold: true, align: center), layout: layout)
    }
    let cjk-blank = height-of(enter(1, size: zihao.xiaosi, font: "songti", line-spacing: 1))   // 15.5625
    let blanks-above-heights = (0, 1, 2, 3).map(relax => height-of(fixed-before-author(relax)))
    let author-height = height-of(author-line)
    let blanks-below-heights = (0, 1, 2, 3).map(relax => height-of(
      if relax < 3 {
        enter(size: zihao.xiaoer, line-spacing: if relax == 0 { 1.25 } else { 1 })
      },
    ))
    let latin-blank = height-of(enter(1, size: zihao.xiaosi, line-spacing: 1))    // 13.80
    let institution-height = height-of(inst-lines)
    let layout-at(
      upto-en-heights, squeeze,
      blanks-above-author, blanks-below-author, blanks-before-inst, relax,
    ) = {
      let en-bottom = layout.margin.top + upto-en-heights.at(squeeze)
      let author-top = en-bottom + blanks-above-author * cjk-blank + blanks-above-heights.at(relax)
      let inst-base = (
        author-top + author-height
          + blanks-below-author * cjk-blank + blanks-below-heights.at(relax)
          + blanks-before-inst * latin-blank
          + institution-metrics.ascent
      )
      let span = (inst-base - institution-metrics.ascent) - en-bottom
      (
        author: author-top + author-metrics.ascent,
        inst: inst-base,
        en-bottom: en-bottom,
        span: span,
        ratio: (author-top + author-metrics.line-height / 2 - en-bottom) / span,
        total: (inst-base - institution-metrics.ascent - layout.margin.top) + institution-height,
      )
    }
    let sample-heights = (0, 1, 2).map(squeeze => height-of(
      upto-en-block(zihao.xiaoer, squeeze, zh: sample-title, sub: none, en: sample-title-en),
    ))
    let sample = layout-at(sample-heights, 0, 2, 2, 6, 0)
    let institution-baseline = if institution-baseline == auto {
      sample.inst
    } else { institution-baseline }
    let ref-ratio = layout-at((0pt, 0pt, 0pt), 0, 2, 2, 6, 0).ratio
    let given = _en-title-size(title-en-xiaoer)
    let sizes = if given != auto {
      (given,)
    } else {
      (_en-title-size(false), _en-title-size(true))
    }
    let upto-en-heights-by-size = sizes.map(size => (0, 1, 2).map(
      squeeze => height-of(upto-en-block(size, squeeze)),
    ))
    let best-at-rung(upto-en-heights, squeeze, relax) = {
      let best-key = none
      let picked-so-far = none
      for blanks-above-author in range(0, 7) {
        for blanks-below-author in range(0, 3) {
          for blanks-before-inst in range(0, 13) {
            let result = layout-at(
              upto-en-heights, squeeze,
              blanks-above-author, blanks-below-author, blanks-before-inst, relax,
            )
            if result.total > layout.text-height { continue }
            let score = (
              3 * calc.abs(result.inst - institution-baseline)
                + calc.abs(result.ratio - ref-ratio) * result.span
            )
            let rank-key = (
              score,
              calc.abs(blanks-above-author - 2)
                + calc.abs(blanks-below-author - 2)
                + calc.abs(blanks-before-inst - 6),
            )
            if best-key == none or rank-key < best-key {
              best-key = rank-key
              picked-so-far = (
                blanks-above-author, blanks-below-author, blanks-before-inst, score,
              )
            }
          }
        }
      }
      picked-so-far
    }
    let rungs = ((0, 0), (1, 0), (2, 0), (2, 1), (2, 2), (2, 3))
    let size-index = none
    let base = none
    for i in range(0, sizes.len()) {
      if size-index == none {
        let picked = best-at-rung(upto-en-heights-by-size.at(i), 0, 0)
        if picked != none { size-index = i; base = picked }
      }
    }
    if size-index == none { size-index = sizes.len() - 1 }
    let upto-en-heights = upto-en-heights-by-size.at(size-index)
    let best = if annotated {
      (sizes.at(0), 0, 2, 2, 6, 0)
    } else if base != none and base.at(3) <= _quality-threshold {
      (sizes.at(size-index), 0, base.at(0), base.at(1), base.at(2), 0)
    } else {
      let best-key = none
      let got = none
      for (rung-index, rung) in rungs.enumerate() {
        let (squeeze, relax) = rung
        let picked = best-at-rung(upto-en-heights, squeeze, relax)
        if picked != none {
          let rank-key = (picked.at(3), rung-index)
          if best-key == none or rank-key < best-key {
            best-key = rank-key
            got = (sizes.at(size-index), squeeze, picked.at(0), picked.at(1), picked.at(2), relax)
          }
        }
      }
      got
    }
    let overflow = best == none
    if overflow {
      best = (sizes.last(), 2, 0, 0, 0, 3)
    }

    let (en-size, squeeze, blanks-above-author, blanks-below-author, blanks-before-inst, relax) = best

    let body = {
      upto-en-block(en-size, squeeze)
      gap-en-author(blanks-above-author)
      fixed-before-author(relax)
      author-line
      gap-author-inst(blanks-below-author, blanks-before-inst, relax)
      inst-lines
    }
    if overflow and warning {
      set page(foreground: overflow-note(terms.warning-overflow, terms.warning-false))
      body
    } else {
      body
    }
  }
}
