#import "@local/banshi:0.1.0" as banshi
#import "../info.typ": final-only-wanted, info-get
#import banshi.layout: half-width-space
#import banshi.content: plain-text, fold-linebreaks

#import banshi.fonts: zihao
#import banshi.paragraph: paragraph-mark as enter
#import "../heading/heading.typ": term-chapter
#import "../terms/lookup.typ": subject-of, term-apply, term-of, term-table, term-for, info-variant
#import "../terms/lang.typ": doc-lang
#import banshi.layout: linebreaks-sets
#import "../layout/parts.typ": layout-for
#import "../once.typ": once
#import banshi.styles: paragraph
#import "../styles/presets.typ": default-styles
#let declarations(
  degree-level: auto,
  form: auto,
  lang: auto,
  title: auto,
  overrides: (:),
  openright: auto,
  two-hanzi: auto,
  layout: auto,
  styles: (
    section: (
      snap-to-grid: false,
      size: zihao.xiaosan, asian-font: "heiti", line-spacing: 1.25, first-line-indent: (chars: 0),
      align: center, above: (lines: 0.5), below: (lines: 0.5),
    ),
    body: default-styles.body,
    authorization-text-lead: default-styles.body + (first-line-indent: 28.65pt),
    authorization-text-items: default-styles.body + (first-line-indent: (chars: 1.5)),
    signature-first: default-styles.body + (first-line-indent: (chars: 8)),
    signature: default-styles.body + (first-line-indent: (chars: 7.5)),
  ),
  shown: auto,
) = context {
  if not final-only-wanted(shown) { return }
  once("declarations")

  let degree-level = if degree-level == auto { info-get().degree-level } else { degree-level }
  let form = if form == auto { info-get().form } else { form }
  let lang = if lang == auto { doc-lang.get() } else { lang }
  let layout = layout-for(if degree-level == "bachelor" { "declarations" } else { "declarations-graduate" }, layout)
  show: linebreaks-sets.with(layout)
  let t = term-table("zh", "declarations", overrides: overrides)
  let variant = info-variant() + (degree-level: degree-level, form: form)
  let pick(name) = term-for(t, name, variant)
  let subject = subject-of(t, variant)
  let with-subject(name) = term-apply(t, name, variant, subject)
  let series = if degree-level == "bachelor" { "bachelor" } else { "graduate" }
  let graduate = series == "graduate"
  let practice = graduate and form == "practice"
  let filled = if title != auto { title } else { info-get().title }
  let words = if filled == none { none } else { plain-text(filled) }
  let slot = if words == none or words.trim() == "" { half-width-space(15, layout) } else { fold-linebreaks(filled) }
  let section = if graduate { styles.section + (above: 0pt, below: 0pt) } else { styles.section }
  let para(name, body) = paragraph(body, if name == "section" { section } else { styles.at(name) }, layout: layout)
  let sign(who, style) = paragraph({
    let label = term-apply(t, "signature", (:), pick(who))
    label
    half-width-space(28 - 2 * plain-text(label).clusters().len(), layout); t.date
    half-width-space(5, layout); t.year
    half-width-space(3, layout); t.month
    half-width-space(3, layout); t.day
  }, styles.at(style), layout: layout)
  let blanks = (
    gap: if graduate { 3 } else { 2 },        // 一
    auth: 2,                                   // 二、五
    stmt: if graduate { 1 } else { 2 },       // 三、五
    sub: if graduate { 2 } else { 0 },        // 四（694、702 各一）
  )
  let after(n) = {
    let steps = (
      ("gap", blanks.gap), ("auth", blanks.auth - 1), ("stmt", blanks.stmt - 1),
      ("sub", blanks.sub), ("auth", 1), ("stmt", 1),
    )
    let left = blanks
    for (k, room) in steps {
      let d = calc.min(n, room)
      n -= d
      left.insert(k, left.at(k) - d)
    }
    left
  }
  let total = blanks.gap + blanks.auth + blanks.stmt + blanks.sub
  let body(b) = {
    paragraph(with-subject("statement"), section + (above: 0pt), layout: layout)
    if b.sub > 1 { enter(1, size: zihao.xiaosi, line-spacing: 1.25) }   // 段 694
    para("body", term-apply(t, "statement-text", (degree-level: degree-level, form: form), slot))
    enter(b.stmt, size: zihao.xiaosi, line-spacing: 1.25)  // 段 517,518 / 696
    sign("signer-author", "signature-first")
    enter(b.gap, size: zihao.sihao, line-spacing: 1.25)
    para("section", with-subject("authorization"))
    if b.sub > 0 { enter(1, size: zihao.xiaosi, line-spacing: 1.25) }   // 段 702
    para("authorization-text-lead", pick("authorization-text-lead"))
    para("authorization-text-items", pick("authorization-text-items"))
    para("body", pick("authorization-text-secrecy"))
    para("body", with-subject("authorization-text-acknowledge"))
    enter(b.auth, size: zihao.xiaosi, line-spacing: 1.25)   // 段 527,528 / 707,708
    sign("signer-author", "signature")
    enter(1, size: zihao.xiaosi, line-spacing: 1.25)                   // 段 530 / 710
    sign("signer-supervisor", "signature")
    if practice {
      enter(1, size: zihao.xiaosi, line-spacing: 1.25)
      sign("signer-industry-supervisor", "signature")
    }
  }
  term-chapter(
    "declarations", lang: lang, overrides: overrides,
    openright: openright, two-hanzi: two-hanzi,
    title: pick("title"),
  )
  context {
    let room = layout.paper-height - layout.margin.bottom - here().position().y
    let fits(b) = measure(block(width: layout.text-width, body(b))).height <= room
    let chosen = range(total + 1).map(after).find(fits)
    body(if chosen == none { after(total) } else { chosen })
  }
}
