#import "@local/banshi:0.1.0" as banshi
#import banshi.paragraph: spacing
#import banshi.fonts: zihao
#import banshi.units: twips
#import banshi.runs: has-cjk
#import banshi.content: plain-text
#import banshi.styles as style-rules
#import banshi.layout: half-width-space
#import banshi.paragraph: paragraph-mark as enter
#import banshi.layout: linebreaks-sets
#import "../layout/parts.typ": standalone-layout
#import banshi.styles: paragraph
#import "./overflow.typ": overflow-note
#import "../axes.typ": axes
#import banshi.errors as _errors
#import "../terms/lookup.typ": static-terms, term-for, variant-of
#import "../terms/date.typ" as _date
#import "../info.typ": info-defaults, value-of
#let _field-columns = (90.3pt, 15.05pt, 147.55pt)
#let _distribute(body) = context {
  let s = if type(body) == str { body } else { plain-text(body) }
  if s == none { return align(center, body) }
  let cs = s.clusters()
  if cs.len() <= 1 { return align(center, body) }
  stack(dir: ltr, spacing: 1fr, ..cs)
}
#let _bachelor-rows = (
  "author",
  "student-id",
  "supervisor",
  "speciality",
  "affiliation",
  "defense-date",
  "institution",
)
#let _graduate-rows = (
  "author",
  "supervisor",
  "co-supervisor",
  "industry-supervisor",
  "degree-applied",
  "speciality",
  "affiliation",
  "defense-date",
  "institution",
)
#let _resolve-row(row, terms, info, variant, lang: "zh") = {
  let resolved(name) = value-of(info, name, lang: lang)
  let paired(term-name, info-name) = (
    label: [#term-for(terms, term-name, variant)],
    value: [#resolved(info-name)],
  )
  let extras = (line-spacing: none, tracking: none)
  if type(row) == str { return paired(row, row) + extras }
  if type(row) == array {
    if row.len() != 2 { panic("expected (label, value), found " + repr(row)) }
    return (label: row.at(0), value: row.at(1)) + extras
  }
  if type(row) == dictionary {
    for k in row.keys() {
      if k not in ("term", "info", "label", "value", "line-spacing", "tracking") {
        panic("unexpected key \"" + k + "\" in titlepage row " + repr(row))
      }
    }
    let extras = (
      line-spacing: row.at("line-spacing", default: none),
      tracking: row.at("tracking", default: none),
    )
    if "label" in row {
      return (label: [#row.label], value: [#row.at("value", default: [])]) + extras
    }
    return paired(row.term, row.at("info", default: row.term)) + extras
  }
  panic("expected string, array, or dictionary, found " + str(type(row)))
}
#let _drop-empty(rows) = rows.filter(row => row.value != none and row.value != [])
#import "./checkbox.typ": checkbox as _checkbox, checkbox-advance

#let titlepage(
  degree-level: "doctor",
  label: auto,
  title: [局部多孔质气体静压轴承关键技术的研究],
  terms: static-terms("zh", "titlepage"),
  info: info-defaults,
  form: "dissertation",
  subtitle: none,
  secrecy: [公开],
  classified-index: [××××],
  udc: [××××],
  school-code: [××××],
  fields: auto,
  layout: auto,
  warning: auto,
  annotated: false,
) = {
  let warning = warning != false
  assert(
    degree-level in axes.degree-level,
    message: _errors.expected-one-of(axes.degree-level, degree-level),
  )
  let variant = variant-of(info) + (degree-level: degree-level, form: form)
  let label = if label == auto {
    term-for(terms, "document-type", variant)
  } else { label }
  let rows = if fields != auto {
    fields
  } else if degree-level == "bachelor" {
    _bachelor-rows
  } else {
    _graduate-rows
  }
  let fields = _drop-empty(rows.map(row => _resolve-row(row, terms, info, variant)))

  let layout = if layout == auto { standalone-layout("titlepage") } else { layout }
  show: linebreaks-sets.with(layout)
  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin,
    ..(if layout.header.shown == false { (header: none) } else { (:) }),
    ..(if layout.footer.shown == false { (footer: none) } else { (:) }),
  )
  set text(size: zihao.xiaosi, lang: "zh", region: "cn")
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)
  let note(body, snap: false, line-spacing: 1, both: none) = {
    let style = (
      size: zihao.xiaosi, asian-font: "songti", line-spacing: line-spacing,
      snap-to-grid: snap,
    )
    if annotated and both != none {
      block(width: 100%, {
        show: style-rules.rules.with(style, layout: layout, set-font: true)
        show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
        body
        h(1fr)
        both
      })
    } else if annotated {
      paragraph(
        {
          show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
          body
        },
        (asian-font: "songti", size: zihao.xiaosi, line-spacing: line-spacing, snap-to-grid: snap, align: center),
        layout: layout,
      )
    } else {
      context block(height: spacing(style, layout: layout).line-height, spacing: 0pt, [])
    }
  }
  let head-line(left, right, snap: false, line-spacing: 1) = {
    block(width: 100%, {
      show: style-rules.rules.with(
        (
          size: zihao.xiaosi, asian-font: "songti", line-spacing: line-spacing,
          snap-to-grid: snap,
        ),
        layout: layout,
        set-font: true,
      )
      grid(
        columns: (1fr, 1fr),
        std.align(std.left, left),
        std.align(std.right, right),
      )
    })
  }
  let masthead = if degree-level == "bachelor" {
    context {
      let style = (
        size: zihao.xiaosi, asian-font: "songti",
        snap-to-grid: true,
      )
      let half-width-space = (n) => half-width-space(n, layout)
      let options = {
        _checkbox(form != "practice")
        terms.form-bachelor-dissertation
        half-width-space(2)
        _checkbox(form == "practice")
        terms.form-bachelor-practice
      }
      if annotated {
        let hung = (size: zihao.xiaosi, asian-font: "songti")
        let row(l, r) = block(width: 100%, spacing: 0pt, {
          show: style-rules.rules.with(hung, layout: layout, set-font: true)
          show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
          l
          h(1fr)
          r
        })
        place(top, dy: -1 * spacing(hung, layout: layout).line-height, {
          row([`form:`], [`secrecy:`])
          row([↓], [↓])
        })
      }
      block(width: 100%, {
        show: style-rules.rules.with(style, layout: layout, set-font: true)
        options
        box(width: 1fr)
        [#terms.secrecy：#secrecy]
      })
    }
    enter(size: zihao.xiaosi, line-spacing: 1)
    context {
      let h = spacing(
        (size: zihao.xiaosi, snap-to-grid: true),
        layout: layout, latin: true,
      ).line-height
      for _ in range(2) { block(height: h, spacing: 0pt, []) }
    }
  } else {
    if annotated {
      context {
        let hung = (size: zihao.xiaosi, asian-font: "songti")
        let row(l, r) = block(width: 100%, spacing: 0pt, {
          show: style-rules.rules.with(hung, layout: layout, set-font: true)
          show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
          l
          h(1fr)
          r
        })
        place(top, dy: -2 * spacing(hung, layout: layout).line-height, {
          row([`classified-index:`], [`school-code:`])
          row([↓], [↓])
        })
      }
    }
    head-line(
      [#terms.classified-index：#classified-index],
      [#terms.school-code：#school-code],
    )
    head-line(
      [#terms.udc：#udc], [#terms.secrecy：#secrecy],
      line-spacing: 1.25,
    )
    note([↑], snap: true, both: [↑])
    note([（`udc:`）], line-spacing: 1.25, both: [（`secrecy:`）])
    context {
      let h = spacing(
        (size: zihao.xiaosi, snap-to-grid: true),
        layout: layout, latin: true,
      ).line-height
      for _ in range(3) { block(height: h, spacing: 0pt, []) }
    }
  }
  let head = {
    paragraph(label, (asian-font: "songti", size: zihao.xiaoer, bold: true, align: center), layout: layout)
    note([↑], snap: true)
    note([（由 `degree-level: "bachelor"|"master"|"doctor"` 决定）], line-spacing: 1.25)
    paragraph(
      title, (asian-font: "heiti", size: zihao.erhao, snap-to-grid: true, latin-bold: true, align: center),
      layout: layout,
    )
    note([↑], snap: true)
    note([（通过 `title: []` 键入）], snap: true)
    if subtitle != none {
      pad(left: 4 * zihao.xiaoer, paragraph(
        [——] + subtitle,
        (asian-font: "heiti", size: zihao.xiaoer, latin-bold: true, align: center), layout: layout,
      ))
    }
  }
  let blanks(n) = for _ in range(n) { block(height: 39pt, spacing: 0pt, []) }
  let table = context {
    let metrics = spacing(
      (
        size: zihao.sihao, asian-font: "songti", line-spacing: 1.5,
        snap-to-grid: true,
      ),
      layout: layout,
    )
    let cell(body, font: "songti", spread: false) = {
      show: style-rules.rules.with(
        (
          size: zihao.sihao, asian-font: font, line-spacing: 1.5,
          snap-to-grid: true,
        ),
        layout: layout,
        set-font: true,
      )
      if spread { _distribute(body) } else { align(left, body) }
    }
    align(center, grid(
      columns: _field-columns,
      rows: auto,
      ..fields.map(f => (
        cell(f.label, font: "heiti", spread: true),
        cell([：]),
        cell(f.value),
      )).flatten(),
    ))
  }
  context {
    let fits(n) = measure(
      block(width: layout.text-width, masthead + head + blanks(n) + table),
    ).height <= layout.text-height
    let n = 3
    while n > 0 and not fits(n) { n -= 1 }
    let body = { masthead; head; blanks(n); table }
    if warning and not fits(n) {
      set page(foreground: overflow-note(terms.warning-overflow, terms.warning-false))
      body
    } else {
      body
    }
  }
}

#let _degree-attributes = (master: [Master's], doctor: [Doctoral])
#let _graduate-rows-en = (
  "author",
  "supervisor",
  "co-supervisor",
  "industry-supervisor",
  "degree-applied",
  "speciality",
  (term: "affiliation", tracking: -0.4pt),
  (term: "defense-date", tracking: -0.4pt),
  "institution",
)
#let _field-columns-en = (213.1pt, 220.3pt)
#let _cell-margin-en = twips(0.19cm)
#let sample-title-en = [RESEARCH ON KEY TECHNOLOGIES OF PARTIAL POROUS
  EXTERNALLY PRESSURIZED GAS BEARING]

#let en-only-keys = ("title-en", "title-en-xiaoer", "subtitle-en", "degree-attribute")

#let titlepage-en(
  degree-level: "doctor",
  degree-attribute: auto,
  terms: static-terms("en", "titlepage"),
  info: info-defaults,
  title-en: sample-title-en,
  subtitle-en: none,
  form: "dissertation",
  title-en-xiaoer: auto,
  classified-index: [××××],
  udc: [××××],
  fields: auto,
  layout: auto,
  warning: auto,
  annotated: false,
) = {
  let warning = warning != false
  if degree-level not in _degree-attributes { return }
  let attr = if degree-attribute == auto {
    _degree-attributes.at(degree-level)
  } else { degree-attribute }
  let rows = if fields == auto { _graduate-rows-en } else { fields }
  let fields = _drop-empty(rows.map(row =>
    _resolve-row(row, terms, info, variant-of(info) + (degree-level: degree-level, form: form), lang: "en")))

  let layout = if layout == auto { standalone-layout("titlepage") } else { layout }
  show: linebreaks-sets.with(layout)
  set page(
    width: layout.paper-width, height: layout.paper-height,
    margin: layout.margin,
    ..(if layout.header.shown == false { (header: none) } else { (:) }),
    ..(if layout.footer.shown == false { (footer: none) } else { (:) }),
  )
  set text(size: zihao.xiaosi, lang: "en")
  set par(leading: 0pt, spacing: 0pt, justify: false, first-line-indent: 0pt)
  let line-en(body, size: zihao.xiaosi, bold: false, snap: false, line-spacing: 1, centered: true) = {
    let zh = has-cjk(plain-text(body))
    block(width: 100%, {
      show: style-rules.rules.with(
        (size: size, bold: bold, line-spacing: line-spacing, snap-to-grid: snap),
        layout: layout, set-font: true, latin: not zh,
      )
      if centered { align(center, body) } else { body }
    })
  }
  let blank(snap: false, size: zihao.xiaosi) = context {
    let h = spacing(
      (size: size, snap-to-grid: snap),
      layout: layout, latin: true,
    ).line-height
    block(height: h, spacing: 0pt, [])
  }
  let head-en(left, note-body, snap: true) = {
    block(width: 100%, {
      show: style-rules.rules.with(
        (size: zihao.xiaosi, snap-to-grid: snap),
        layout: layout, set-font: true, latin: true,
      )
      show raw: set text(top-edge: 0pt, bottom-edge: 0pt)
      left
      h(1fr)
      if annotated { note-body }
    })
  }
  let note(body, snap: false) = {
    let style = (
      size: zihao.xiaosi, asian-font: "songti",
      snap-to-grid: snap,
    )
    if annotated {
      block(width: 100%, {
        show: style-rules.rules.with(style, layout: layout, set-font: true)
        align(center, body)
      })
    } else {
      context block(height: spacing(style, layout: layout).line-height, spacing: 0pt, [])
    }
  }
  let _row-style(exact) = (
    size: zihao.sihao,
    line-spacing: (exactly: exact),
    snap-to-grid: false,
  )
  let blanks = (after-head: 3, before-title: 1, before-table: 2)
  let give-up(n) = {
    let rest = calc.max(0, n - blanks.before-table)
    (
      after-head: calc.max(0, blanks.after-head - calc.max(0, rest - blanks.before-title)),
      before-title: calc.max(0, blanks.before-title - rest),
      before-table: calc.max(0, blanks.before-table - n),
    )
  }
  let max-squeeze = blanks.values().sum()
  let max-pad = 8
  let title-en-full = if subtitle-en == none { title-en } else {
    title-en + [：] + subtitle-en
  }
  let upto-table(en-size, squeeze, title: title-en-full) = {
    let b = give-up(squeeze)
      head-en([#terms.classified-index: #classified-index], [← `classified-index:`])
      head-en([#terms.udc: #udc], [← `udc:`])
      for _ in range(b.after-head) { blank(snap: true) }

      line-en([Dissertation for the #attr Degree], size: zihao.xiaoer, snap: true)
      note[↑]
      note[（由 `degree-level:` 与 `degree-attribute:` 决定）]
      for _ in range(b.before-title) { blank(snap: true, size: zihao.xiaoer) }
        line-en(title, size: en-size, bold: true, line-spacing: 1.25)
      note[↑]
      note[（通过 `title-en: []` 键入，太长时可用 `title-en-xiaoer: true` 转为小 2 号字）]
      for _ in range(b.before-table) { blank(snap: true, size: zihao.erhao) }

  }
  let table-and-tail = {
    context {
      let style = _row-style
      let cell(body, bold: false, exact: 22pt, squeeze: 0pt) = block(
        width: 100%, inset: (x: _cell-margin-en),
        {
          show: style-rules.rules.with(
            style(exact) + (bold: bold, tracking: squeeze),
            layout: layout, set-font: true, latin: true,
          )
          align(left, body)
        },
      )
      let total = _field-columns-en.sum()
      move(dx: (layout.text-width - total) / 2, grid(
        columns: _field-columns-en,
        ..fields.map(f => (
          cell([#f.label：], bold: true),
          cell(
            f.value,
            exact: if f.line-spacing == none { 22pt } else { f.line-spacing },
            squeeze: if f.tracking == none { 0pt } else { f.tracking },
          ),
        )).flatten(),
      ))
    }

    blank()
    note[↑（各行取自 `author-en:` 一类的参数，没写就退到不带 -en 的）]
  }
  context {
    let height-of-title(size, squeeze, title) = measure(
      block(width: layout.text-width, upto-table(size, squeeze, title: title)),
    ).height
    let height-of(size, squeeze) = height-of-title(size, squeeze, title-en-full)
    let sizes = if title-en-xiaoer == auto {
      (zihao.erhao, zihao.xiaoer)
    } else if title-en-xiaoer {
      (zihao.xiaoer,)
    } else {
      (zihao.erhao,)
    }
    let table-top = height-of-title(zihao.xiaoer, 0, sample-title-en)
    let tail = measure(block(width: layout.text-width, table-and-tail)).height
    let pick = none
    for size in sizes {
      let best = none
      for adjust in range(-max-pad, max-squeeze + 1) {
        let h = height-of(size, adjust)
        if h + tail > layout.text-height { continue }
        let off = calc.abs(h - table-top)
        if best == none or off < best.first() { best = (off, adjust) }
      }
      if best != none { pick = (size, best.last()); break }
    }
    let overflow = pick == none
    if overflow { pick = (sizes.last(), max-squeeze) }
    let body = { upto-table(pick.first(), pick.last()); table-and-tail }
    if warning and overflow {
      set page(foreground: overflow-note(terms.warning-overflow, terms.warning-false, lang: "en"))
      body
    } else {
      body
    }
  }
}
